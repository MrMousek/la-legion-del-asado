--[[
    La Legión del Asado - Ubicacion.lua
    "Compañeros cerca": compartir la ubicación (opcional), recibir la de los demás,
    distancias y avisos de cercanía.

    La posición vive SOLO en memoria (NS.locations): nunca se guarda en disco.
    Se comparte únicamente si el jugador lo activa, y nunca dentro de instancias.
]]
local ADDON, NS = ...
local C = NS.C
local Print = NS.Print
local ClassColored = NS.ClassColored

----------------------------------------------------------------
-- Ubicación de compañeros (opt-in) - "Compañeros cerca"
-- La posición vive SOLO en memoria: nunca se guarda en disco.
-- Solo se comparte si el jugador lo activa, y nunca dentro de instancias.
----------------------------------------------------------------
NS.locations = {}   -- [nombre] = { mapID, x, y, class, t }

local lastSent = { mapID = nil, x = 0, y = 0, t = -1000 }
local sentOff = true
local locTicker
local nearAlerted = {}
local lastNearToast = -1000

local DIRS = { "N", "NE", "E", "SE", "S", "SO", "O", "NO" }

-- Mi posición (mapID, x, y) o nil si no se puede leer (instancias, mapas sin coordenadas)
local function MyPosition()
    local ok, mapID, x, y = pcall(function()
        if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition) then return nil end
        local id = C_Map.GetBestMapForUnit("player")
        if not id then return nil end
        local pos = C_Map.GetPlayerMapPosition(id, "player")
        if not pos then return nil end
        local px, py = pos:GetXY()
        if not px or not py or (px == 0 and py == 0) then return nil end
        return id, px, py
    end)
    if ok and mapID then return mapID, x, y end
    return nil
end
NS.MyPosition = MyPosition

local function MapSize(mapID)
    if C_Map and C_Map.GetMapWorldSize then
        local ok, w, h = pcall(C_Map.GetMapWorldSize, mapID)
        if ok and w and h and w > 0 and h > 0 then return w, h end
    end
    return nil
end

-- Distancia (yardas) y rumbo de (x1,y1) hacia (x2,y2) dentro del MISMO mapa. Norte = arriba del mapa.
function NS.DistanceAndBearing(mapID, x1, y1, x2, y2)
    local w, h = MapSize(mapID)
    if not w then return nil end
    local dx, dy = (x2 - x1) * w, (y2 - y1) * h
    local angle = math.deg(math.atan2(dx, -dy)) % 360
    return math.sqrt(dx * dx + dy * dy), DIRS[math.floor((angle + 22.5) / 45) % 8 + 1]
end

local function SendLocation(force)
    local L = NS.db.location
    if not L.share or not IsInGuild() then return end

    if IsInInstance() then   -- nunca se comparte dentro de instancias
        if not sentOff then NS.Send("GUILD", "LOCOFF", nil, true); sentOff = true end
        return
    end

    local mapID, x, y = MyPosition()
    if not mapID then return end
    local now = GetTime()
    local moved = lastSent.mapID ~= mapID or math.abs(x - lastSent.x) > 0.002 or math.abs(y - lastSent.y) > 0.002
    if not (force or moved or now - lastSent.t > 30) then return end   -- sin movimiento: solo un latido cada 30 s

    local _, classFile = UnitClass("player")
    local msg = table.concat({ "LOC", mapID, string.format("%.4f", x), string.format("%.4f", y), classFile or "" }, "^")
    if NS.Send("GUILD", msg, nil, true) then
        lastSent.mapID, lastSent.x, lastSent.y, lastSent.t = mapID, x, y, now
        sentOff = false
    end
end

local function StartLocationTicker()
    if locTicker then locTicker:Cancel() end
    locTicker = C_Timer.NewTicker(C.LOC_INTERVAL, function() SendLocation(false) end)
end

-- Activa/desactiva el compartir mi ubicación
function NS.SetLocationSharing(on, silent)
    local L = NS.db.location
    L.share = on and true or false
    if locTicker then locTicker:Cancel(); locTicker = nil end
    if L.share then
        StartLocationTicker()
        C_Timer.After(1, function() SendLocation(true) end)
        if not silent then
            Print("Estás compartiendo tu ubicación con la guild (no en instancias, y nunca se guarda). Se apaga con /asado ubicacion off.")
        end
    else
        if IsInGuild() and not sentOff then NS.Send("GUILD", "LOCOFF", nil, true) end
        sentOff = true
        if not silent then Print("Dejaste de compartir tu ubicación.") end
    end
    NS.Fire("LOCATIONS_UPDATED")
end

-- Aviso "X está cerca": misma zona de mapa y dentro del radio. Con enfriamiento por persona y global.
local function CheckNear(name)
    local L = NS.db.location
    if not L.near or NS.inEncounter then return end
    local e = NS.locations[name]
    if not e then return end
    local mapID, mx, my = MyPosition()
    if not mapID or mapID ~= e.mapID then return end
    local dist, dir = NS.DistanceAndBearing(mapID, mx, my, e.x, e.y)
    if not dist or dist > C.NEAR_RADIUS then return end

    local now = GetTime()
    if nearAlerted[name] and now - nearAlerted[name] < C.NEAR_COOLDOWN then return end
    if now - lastNearToast < 20 then return end
    nearAlerted[name] = now
    lastNearToast = now
    NS.Toast(string.format("%s está cerca (%d yd al %s)", ClassColored(name, e.class), math.floor(dist + 0.5), dir), 4)
end

NS.Handle("LOC", function(sender, channel, mapID, x, y, classFile)
    if channel ~= "GUILD" then return end
    mapID, x, y = tonumber(mapID), tonumber(x), tonumber(y)
    if not (mapID and x and y) or mapID < 1 or mapID > 100000 or x < 0 or x > 1 or y < 0 or y > 1 then return end
    local now = GetTime()
    local old = NS.locations[sender]
    if old and now - old.t < 3 then return end   -- anti-flood
    if not (classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]) then classFile = nil end
    NS.locations[sender] = { mapID = mapID, x = x, y = y, class = classFile, t = now }
    CheckNear(sender)
    NS.Fire("LOCATIONS_UPDATED")
end)

NS.Handle("LOCOFF", function(sender)
    if NS.locations[sender] then
        NS.locations[sender] = nil
        NS.Fire("LOCATIONS_UPDATED")
    end
end)

-- Lista para la UI: { mismos en mi mapa (con distancia, ordenados) }, { los de otras zonas }
function NS.GetNearbyList()
    local now = GetTime()
    local mapID, mx, my = MyPosition()
    local same, other = {}, {}
    for name, e in pairs(NS.locations) do
        if now - e.t > C.LOC_EXPIRE then
            NS.locations[name] = nil   -- venció: dejó de reportar
        elseif mapID and e.mapID == mapID then
            local dist, dir = NS.DistanceAndBearing(mapID, mx, my, e.x, e.y)
            same[#same + 1] = { name = name, class = e.class, dist = dist, dir = dir }
        else
            other[#other + 1] = { name = name, class = e.class, mapID = e.mapID }
        end
    end
    table.sort(same, function(a, b) return (a.dist or 1e9) < (b.dist or 1e9) end)
    table.sort(other, function(a, b) return a.name < b.name end)
    return same, other
end

-- Prueba local: simula 3 compañeros (uno a 120 yd, uno a 900 yd y uno en otra zona). Duran 40 s.
function NS.TestLocations()
    local mapID, x, y = MyPosition()
    if not mapID then Print("No pude leer tu posición (¿estás en una instancia?)."); return end
    local w, h = MapSize(mapID)
    if not w then Print("Este mapa no informa su tamaño."); return end
    local now = GetTime()
    NS.locations["Pepito"]  = { mapID = mapID, x = math.min(1, x + 120 / w), y = y, class = "MAGE", t = now }
    NS.locations["Fulano"]  = { mapID = mapID, x = x, y = math.min(1, y + 900 / h), class = "WARRIOR", t = now }
    NS.locations["Mengano"] = { mapID = (mapID == 84) and 85 or 84, x = 0.5, y = 0.5, class = "HUNTER", t = now }
    nearAlerted["Pepito"] = nil
    lastNearToast = -1000
    CheckNear("Pepito")
    NS.Fire("LOCATIONS_UPDATED")
    Print("Compañeros de prueba cargados (duran 40 segundos). Abrí la Parrilla con /asado.")
end

NS:On("PLAYER_ENTERING_WORLD", function()
    if NS.db and NS.db.location.share then C_Timer.After(3, function() SendLocation(true) end) end
end)

NS.RegisterCallback("READY", function()
    if NS.db.location.share then StartLocationTicker() end
end)

