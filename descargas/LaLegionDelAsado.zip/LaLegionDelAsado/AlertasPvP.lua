--[[
    La Legión del Asado - AlertasPvP.lua
    Alertas para el PvP en mundo abierto (servidores JcJ), entre los miembros de la guild:

      /asado sos [mensaje]       "¡X pide ayuda a la Legión!"   -> aviso, alarma y marca roja en el mapa
      /asado reunion [mensaje]   "X armó una zona de reunión PvP" -> aviso, toque y marca dorada en el mapa
      /asado ir                  marca en tu mapa (waypoint) la última alerta

    También hay botones en la pestaña PvP. Las alertas solo viajan por el canal de la guild, vencen solas
    (el SOS a los 3 minutos, la reunión a los 10) y viven en memoria: no se guardan en el disco.

    Contra el spam: cada jugador espera unos segundos entre un aviso y el siguiente, y los demás ignoran
    lo que llegue muy seguido del mismo jugador. Cada uno puede apagar las alertas (y su sonido) en la pestaña PvP.
]]
local ADDON, NS = ...
local C = NS.C
local Print = NS.Print
local ClassColored = NS.ClassColored

-- Sonidos (si falta el archivo, se usa uno del juego). Podés reemplazar sos.ogg / reunion.ogg por una voz grabada.
local SND = "Interface\\AddOns\\" .. ADDON .. "\\Sounds\\"
NS.Sounds.sos     = { files = { SND .. "sos.ogg", SND .. "sos_2.ogg" },         kit = "RAID_WARNING", len = 3, lens = { 1.6 }, prio = 3, cd = 10 }
NS.Sounds.reunion = { files = { SND .. "reunion.ogg", SND .. "reunion_2.ogg" }, kit = "READY_CHECK",  len = 3, lens = { 1.1 }, prio = 2, cd = 10 }

NS.alerts = {}         -- alertas activas, la más nueva primero (solo memoria)
local lastSent = {}    -- [tipo] = cuándo mandé la última
local lastRecv = {}    -- ["tipo:nombre"] = cuándo recibí la última de ese jugador

local function ExpireAfter(kind)
    return kind == "sos" and C.SOS_EXPIRE or C.REUNION_EXPIRE
end

local function AddAlert(a)
    local now = GetTime()
    a.t = now
    a.expires = now + ExpireAfter(a.kind)
    -- sacar las vencidas y la anterior del mismo jugador y tipo
    for i = #NS.alerts, 1, -1 do
        local o = NS.alerts[i]
        if o.expires <= now or (o.kind == a.kind and o.name == a.name) then table.remove(NS.alerts, i) end
    end
    table.insert(NS.alerts, 1, a)
    while #NS.alerts > 12 do table.remove(NS.alerts) end
    NS.Fire("ALERTS_UPDATED")
end

-- Alertas que todavía no vencieron (la más nueva primero)
function NS.ActiveAlerts()
    local now, out = GetTime(), {}
    for i = #NS.alerts, 1, -1 do
        if NS.alerts[i].expires <= now then table.remove(NS.alerts, i) end
    end
    for _, a in ipairs(NS.alerts) do out[#out + 1] = a end
    return out
end

----------------------------------------------------------------
-- Recibir
----------------------------------------------------------------
local function Announce(a)
    local who = ClassColored(a.name, a.class)
    local coords = a.mapID > 0 and string.format("%.0f,%.0f", a.x * 100, a.y * 100) or nil
    local where = NS.WhereText(a.zone, a.sub, coords)

    -- Si estás en la misma zona, cuánto te separa del lugar
    local extra
    if a.mapID > 0 then
        local mapID, mx, my = NS.MyPosition()
        if mapID and mapID == a.mapID then
            local dist, dir = NS.DistanceAndBearing(mapID, mx, my, a.x, a.y)
            if dist then extra = string.format("a %d yd al %s", math.floor(dist + 0.5), dir) end
        end
    end

    local title, prefix
    if a.kind == "sos" then
        title, prefix = string.format("¡%s pide ayuda a la Legión!", who), "|cffff4040"
    else
        title, prefix = string.format("%s armó una zona de reunión PvP", who), "|cff74acdf"
    end
    local detail = where .. (extra and ("  ·  " .. extra) or "")
    local quote = (a.msg ~= "") and ('"' .. a.msg .. '"') or nil

    -- Siempre queda escrito en el chat (con el cómo llegar)
    print(string.format("%s[%s]|r %s - %s%s. Escribí |cffffd100/asado ir|r para marcarlo en el mapa.",
        prefix, C.SHORT_NAME, title, detail, quote and (" " .. quote) or ""))

    -- Aviso y sonido (no en medio de una pelea de jefe)
    if not NS.inEncounter then
        NS.Toast(title .. "\n" .. detail .. (quote and ("\n" .. quote) or ""), 8, a.kind)
        if NS.db.pvpAlerts.sound then NS.PlaySound(a.kind) end
    end
end

local function OnAlert(kind, sender, channel, mapID, x, y, classFile, zone, sub, msg)
    if channel ~= "GUILD" then return end
    mapID, x, y = tonumber(mapID) or 0, tonumber(x) or 0, tonumber(y) or 0
    if mapID < 0 or mapID > 100000 or x < 0 or x > 1 or y < 0 or y > 1 then return end

    local now = GetTime()
    local key = kind .. ":" .. sender
    if lastRecv[key] and now - lastRecv[key] < 10 then return end   -- anti-flood por jugador
    lastRecv[key] = now
    if not NS.db.pvpAlerts.enabled then return end

    if not (classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]) then classFile = nil end
    local a = { kind = kind, name = sender, class = classFile, mapID = mapID, x = x, y = y,
        zone = NS.Clean(zone, 40), sub = NS.Clean(sub, 40), msg = NS.Clean(msg, C.ALERT_MSG_MAX) }
    AddAlert(a)
    Announce(a)
end

NS.Handle("SOS", function(sender, channel, ...) OnAlert("sos", sender, channel, ...) end)
NS.Handle("REUNION", function(sender, channel, ...) OnAlert("reunion", sender, channel, ...) end)

----------------------------------------------------------------
-- Enviar
----------------------------------------------------------------
-- kind = "sos" | "reunion"
function NS.SendAlert(kind, text)
    if not IsInGuild() then Print("Necesitás estar en una guild."); return end
    local now = GetTime()
    local cd = (kind == "sos") and C.SOS_COOLDOWN or C.REUNION_COOLDOWN
    local wait = cd - (now - (lastSent[kind] or -1000))
    if wait > 0 then
        Print(string.format("Esperá %d segundos para volver a avisar.", math.ceil(wait)))
        return
    end

    local mapID, x, y = NS.MyPosition()      -- en instancias y campos de batalla no hay posición
    local _, classFile = UnitClass("player")
    local zone = (GetRealZoneText and GetRealZoneText()) or GetZoneText() or ""
    local sub = GetSubZoneText and GetSubZoneText() or ""
    local msg = NS.Clean(text or "", C.ALERT_MSG_MAX)

    local payload = table.concat({
        kind == "sos" and "SOS" or "REUNION", mapID or 0,
        x and string.format("%.4f", x) or 0, y and string.format("%.4f", y) or 0,
        classFile or "", NS.Clean(zone, 40), NS.Clean(sub, 40), msg,
    }, "^")
    if not NS.Send("GUILD", payload, nil, true) then
        Print("No se pudo avisar ahora (¿pelea de jefe?). Probá de nuevo en unos segundos.")
        return
    end
    lastSent[kind] = now

    -- Yo también lo veo en el mapa, pero sin alarma
    AddAlert({ kind = kind, name = NS.me, class = classFile, mapID = mapID or 0, x = x or 0, y = y or 0,
        zone = zone, sub = sub, msg = msg })
    if kind == "sos" then
        Print("¡Pedido de ayuda enviado a la guild! Los que tengan el addon reciben el aviso con tu ubicación.")
    else
        Print("Zona de reunión avisada a la guild. Dura " .. math.floor(C.REUNION_EXPIRE / 60) .. " minutos en el mapa.")
    end
end

----------------------------------------------------------------
-- Ir al lugar (marca en el mapa del juego)
----------------------------------------------------------------
function NS.GoToAlert()
    local list = NS.ActiveAlerts()
    local a = list[1]
    for _, o in ipairs(list) do          -- si hay un SOS activo, ese primero
        if o.kind == "sos" then a = o; break end
    end
    if not a then Print("No hay alertas activas."); return end
    if not a.mapID or a.mapID <= 0 then Print("Esa alerta no trae ubicación (estaba en una instancia)."); return end

    local ok = pcall(function()
        C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(a.mapID, a.x, a.y))
        if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
            C_SuperTrack.SetSuperTrackedUserWaypoint(true)
        end
    end)
    local where = NS.WhereText(a.zone, a.sub, string.format("%.0f,%.0f", a.x * 100, a.y * 100))
    if ok then
        Print("Marcado en el mapa: " .. where .. " (" .. ClassColored(a.name, a.class) .. ").")
    else
        Print("No pude marcar el mapa en este cliente. Andá a: " .. where .. ".")
    end
end

----------------------------------------------------------------
-- Comandos
----------------------------------------------------------------
NS.commands.sos = function(rest) NS.SendAlert("sos", rest) end
NS.commands.auxilio = NS.commands.sos
NS.commands.reunion = function(rest) NS.SendAlert("reunion", rest) end
NS.commands.juntada = NS.commands.reunion
NS.commands.ir = function() NS.GoToAlert() end
