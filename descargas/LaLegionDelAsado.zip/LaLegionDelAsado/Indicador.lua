--[[
    La Legión del Asado - Indicador.lua
    Indicador de proximidad: una pastillita chica con la bandera y un número
    ("3" = hay 3 compañeros a menos de NEAR_RADIUS yardas). Solo se ve cuando hay
    alguien cerca. Al pasar el mouse muestra quiénes son y a cuánto están.

      Click ............. abre la Parrilla
      Shift + arrastrar . mover (se recuerda)  ·  /asado cerca reset: vuelve a su lugar
]]
local ADDON, NS = ...
local C = NS.C

local pill, ticker
local near = {}   -- los que están cerca ahora

local function Place()
    local pos = NS.db.location.pos
    pill:ClearAllPoints()
    if pos then
        pill:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else
        pill:SetPoint("TOP", Minimap, "BOTTOM", 0, -6)   -- debajo del minimapa
    end
end

function NS.ResetNearPosition()
    NS.db.location.pos = nil
    if pill then Place() end
    NS.Print("El indicador volvió a su lugar, debajo del minimapa.")
end

local function Build()
    local f = CreateFrame("Button", "LegionAsadoNear", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    f:SetSize(48, 20)
    f:SetFrameStrata("MEDIUM")
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:RegisterForClicks("LeftButtonUp")
    f:RegisterForDrag("LeftButton")
    f:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    f:SetBackdropColor(0.05, 0.05, 0.07, 0.72)
    f:SetBackdropBorderColor(C.CELESTE[1], C.CELESTE[2], C.CELESTE[3], 0.9)

    f.flag = f:CreateTexture(nil, "ARTWORK")
    f.flag:SetSize(18, 10)
    f.flag:SetPoint("LEFT", 6, 0)
    f.flag:SetTexture(C.FLAG)

    f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.text:SetPoint("LEFT", f.flag, "RIGHT", 5, 0)

    f:SetScript("OnClick", function() if NS.UI and NS.UI.Toggle then NS.UI.Toggle(1) end end)
    f:SetScript("OnDragStart", function(self) if IsShiftKeyDown() then self:StartMoving() end end)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint()
        NS.db.location.pos = { point, relPoint, x, y }
    end)
    f:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:AddLine("Compañeros cerca", C.CELESTE[1], C.CELESTE[2], C.CELESTE[3])
        for i = 1, math.min(#near, 8) do
            local e = near[i]
            GameTooltip:AddDoubleLine(NS.ClassColored(e.name, e.class),
                string.format("%d yd al %s", math.floor(e.dist + 0.5), e.dir), 1, 1, 1, 1, 0.82, 0)
        end
        if #near > 8 then GameTooltip:AddLine("... y " .. (#near - 8) .. " más", 0.6, 0.6, 0.6) end
        GameTooltip:AddLine("Click: Parrilla  ·  Shift+arrastrar: mover", 0.5, 0.5, 0.5)
        GameTooltip:Show()
    end)
    f:SetScript("OnLeave", function() GameTooltip:Hide() end)

    f:Hide()
    pill = f
    Place()
end

local function Update()
    if not pill then return end
    if not NS.db.location.indicator then pill:Hide(); return end
    local same = NS.GetNearbyList()
    wipe(near)
    for _, e in ipairs(same) do
        if e.dist and e.dist <= C.NEAR_RADIUS then near[#near + 1] = e end
    end
    if #near == 0 then
        pill:Hide()
    else
        pill.text:SetText(#near)
        pill:SetWidth(36 + (#near >= 10 and 8 or 0))
        pill:Show()
    end
end

-- Mientras haya alguien reportando posición, se reevalúa cada 3 s (porque YO también me muevo).
-- Cuando nadie reporta, no corre nada.
local function EnsureTicker()
    if ticker then return end
    ticker = C_Timer.NewTicker(3, function(t)
        Update()
        if next(NS.locations) == nil then t:Cancel(); ticker = nil end
    end)
end

NS.RegisterCallback("LOCATIONS_UPDATED", function()
    if not pill then return end
    Update()
    if next(NS.locations) ~= nil then EnsureTicker() end
end)

NS.RegisterCallback("READY", function()
    Build()
    Update()
end)
