--[[
    La Legión del Asado - Core.lua
    Lógica principal: eventos, comunicación entre miembros, puntos, muertes,
    sonidos, ruleta y comandos.

    Pensado para WoW: Forever (Interface 16001, API moderna tipo Mainline).
    Todo lo que podría no existir en el cliente está protegido (pcall / chequeos),
    y /asado diag te dice qué APIs hay realmente.
]]
local ADDON, NS = ...
local C = NS.C

NS.version = (C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON, "Version"))
    or (GetAddOnMetadata and GetAddOnMetadata(ADDON, "Version")) or "?"
NS.inEncounter = false

----------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------
local function Print(...)
    print("|cffff7a1a[" .. C.SHORT_NAME .. "]|r", ...)
end
NS.Print = Print

local function Debug(...)
    if NS.db and NS.db.debug then
        print("|cff888888[LDA dbg]|r", ...)
    end
end
NS.Debug = Debug

-- Nombre "corto" de un jugador, igual en cualquier formato del cliente:
--   Retail: "Nombre-Reino"  ·  Forever: "Nombre Reino" (con espacio).
-- Los nombres de personaje nunca llevan espacios ni guiones, así que alcanza con la primera palabra.
local function Short(name)
    if not name then return "" end
    name = tostring(name)
    return name:match("^([^%s%-]+)") or name
end
NS.Short = Short

NS.me = Short(UnitName("player"))

-- En clientes con restricciones tipo Midnight, algunos strings pueden ser "secretos".
local function IsSecret(v)
    return issecretvalue and issecretvalue(v)
end

function NS.MonthKey(ts)
    return date("%Y-%m", ts or GetServerTime())
end

----------------------------------------------------------------
-- Callbacks internos (para que UI.lua se entere de cambios)
----------------------------------------------------------------
local callbacks = {}

function NS.RegisterCallback(name, fn)
    callbacks[name] = callbacks[name] or {}
    table.insert(callbacks[name], fn)
end

function NS.Fire(name, ...)
    local list = callbacks[name]
    if not list then return end
    for i = 1, #list do
        local ok, err = pcall(list[i], ...)
        if not ok then geterrorhandler()(err) end
    end
end

----------------------------------------------------------------
-- Despachador de eventos (un error en un handler no rompe a los demás)
----------------------------------------------------------------
local eventFrame = CreateFrame("Frame")
local eventHandlers = {}

function NS:On(event, fn)
    if not eventHandlers[event] then
        eventHandlers[event] = {}
        local ok = pcall(eventFrame.RegisterEvent, eventFrame, event)
        if not ok then Debug("Evento no disponible en este cliente:", event) end
    end
    table.insert(eventHandlers[event], fn)
end

eventFrame:SetScript("OnEvent", function(_, event, ...)
    local list = eventHandlers[event]
    if not list then return end
    for i = 1, #list do
        local ok, err = pcall(list[i], ...)
        if not ok then geterrorhandler()(err) end
    end
end)

----------------------------------------------------------------
-- Comunicación (AddonMessage)
----------------------------------------------------------------
local SendAddon = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
local RegisterPrefix = (C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix) or RegisterAddonMessagePrefix
local SendChat = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage

local outbox = {}

-- En peleas de jefe el cliente puede bloquear mensajes de addons. Si es así, los encolamos.
function NS.CanSend()
    if NS.inEncounter then return false end
    if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown then
        local ok, locked = pcall(C_ChatInfo.InChatMessagingLockdown)
        if ok and locked then return false end
    end
    return true
end

-- noQueue = true -> si no se puede mandar ahora, se descarta (ej: ruleta)
function NS.Send(channel, msg, target, noQueue)
    if not channel or not SendAddon then return false end
    if not NS.CanSend() then
        if not noQueue then
            table.insert(outbox, { channel, msg, target })
            if #outbox > 30 then table.remove(outbox, 1) end
        end
        return false
    end
    local ok, res = pcall(SendAddon, C.PREFIX, msg, channel, target)
    Debug("TX", channel, target or "", msg, ok, tostring(res))
    return ok
end

local function FlushOutbox()
    if #outbox == 0 or not NS.CanSend() then return end
    local item = table.remove(outbox, 1)
    NS.Send(item[1], item[2], item[3])
    if #outbox > 0 then C_Timer.After(0.4, FlushOutbox) end
end

function NS.GroupChannel()
    local inst = (Enum and Enum.PartyCategory and Enum.PartyCategory.Instance) or 2
    if IsInGroup(inst) then return "INSTANCE_CHAT" end
    if IsInRaid() then return "RAID" end
    if IsInGroup() then return "PARTY" end
    return nil
end

-- Router de mensajes: formato "COMANDO^campo1^campo2..."
local msgHandlers = {}

function NS.Handle(cmd, fn)
    msgHandlers[cmd] = fn
end

local rawNames = {}   -- nombre corto -> nombre tal como lo mandó el juego (para susurrar)

function NS.WhisperTarget(name)
    return rawNames[name] or name
end

NS:On("CHAT_MSG_ADDON", function(prefix, msg, channel, sender)
    if prefix ~= C.PREFIX then return end
    if IsSecret(msg) or IsSecret(sender) then return end
    local raw = sender
    sender = Short(sender)
    rawNames[sender] = raw
    if sender == NS.me then return end
    Debug("RX", channel, sender, msg)
    local parts = { strsplit("^", msg) }
    local cmd = table.remove(parts, 1)
    local fn = msgHandlers[cmd]
    if fn then fn(sender, channel, unpack(parts)) end
end)

local function Clean(s, maxLen)
    s = tostring(s or ""):gsub("[%^|]", " ")
    return s:sub(1, maxLen or 60)
end

----------------------------------------------------------------
-- Roster de la guild (para saber quién es oficial)
----------------------------------------------------------------
local rankByName = {}
NS.rosterLevels = {}

function NS.RequestRoster()
    if C_GuildInfo and C_GuildInfo.GuildRoster then
        C_GuildInfo.GuildRoster()
    elseif GuildRoster then
        GuildRoster()
    end
end

local function RebuildRoster()
    wipe(rankByName)
    wipe(NS.rosterLevels)
    local n = GetNumGuildMembers and GetNumGuildMembers() or 0
    for i = 1, n do
        local name, _, rankIndex, level = GetGuildRosterInfo(i)
        if name then
            local s = Short(name)
            rankByName[s] = rankIndex
            if level then NS.rosterLevels[s] = level end
        end
    end
    NS.rosterReady = n > 0
    NS.Fire("ROSTER_UPDATED")
end

-- El evento puede llegar decenas de veces por minuto: se procesa una sola vez cada 1,5 segundos.
local rosterPending = false
NS:On("GUILD_ROSTER_UPDATE", function()
    if rosterPending then return end
    rosterPending = true
    C_Timer.After(1.5, function()
        rosterPending = false
        RebuildRoster()
    end)
end)

function NS.IsOfficer(name)
    local r = rankByName[Short(name)]
    return r ~= nil and r <= NS.db.officerMaxRank
end

----------------------------------------------------------------
-- Libro de puntos (ledger) - "El Asador del Mes"
----------------------------------------------------------------
local ledgerIndex = {}
local counter = 0
local served = {}   -- a quién ya le estamos mandando sync

local function IndexLedger()
    wipe(ledgerIndex)
    for _, e in ipairs(NS.db.ledger) do ledgerIndex[e.id] = true end
end

local function AddLedger(e)
    if ledgerIndex[e.id] then return false end
    ledgerIndex[e.id] = true
    e.mk = e.mk or date("%Y-%m", e.ts)
    table.insert(NS.db.ledger, e)
    NS.totalsCache = nil   -- hay que recalcular
    NS.Fire("LEDGER_UPDATED")
    return true
end

local function EvtString(e)
    return table.concat({ "EVT", e.id, e.to, e.d, e.why, e.by, e.ts }, "^")
end

-- Devuelve: totalHistorico[nombre], totalDelMes[nombre]
function NS.ComputeTotals()
    local mk = NS.MonthKey()
    local c = NS.totalsCache
    if c and c.mk == mk then return c.all, c.month end

    local all, month = {}, {}
    for _, e in ipairs(NS.db.ledger) do
        local emk = e.mk
        if not emk then emk = date("%Y-%m", e.ts); e.mk = emk end   -- se calcula una sola vez por evento
        all[e.to] = (all[e.to] or 0) + e.d
        if emk == mk then month[e.to] = (month[e.to] or 0) + e.d end
    end
    NS.totalsCache = { mk = mk, all = all, month = month }
    return all, month
end

function NS.TopN(t, n)
    local arr = {}
    for name, v in pairs(t) do
        if v > 0 then arr[#arr + 1] = { name = name, v = v } end
    end
    table.sort(arr, function(a, b)
        if a.v ~= b.v then return a.v > b.v end
        return a.name < b.name
    end)
    while #arr > n do table.remove(arr) end
    return arr
end

-- opts.allowSelf: permite premiarse (asistencia). opts.quiet: no imprime en el chat.
function NS.Award(to, delta, why, opts)
    opts = opts or {}
    if not NS.IsOfficer(NS.me) then
        Print("Solo los oficiales pueden repartir puntos. (¿Cargó el roster? Probá de nuevo en unos segundos.)")
        return
    end
    to = Short(to or "")
    delta = tonumber(delta)
    if to == "" or not delta or delta == 0 or math.abs(delta) > 100 then
        Print("Uso: /asado puntos <nombre> <cantidad -100..100> [motivo]")
        return
    end
    if to == NS.me and not opts.allowSelf then
        Print("El asador no se premia solo, ¡que lo decida otro!")
        return
    end
    local ts = GetServerTime()
    counter = counter + 1
    local e = {
        id = NS.me .. ":" .. ts .. ":" .. counter,
        to = to, d = delta, why = Clean(why, 60), by = NS.me, ts = ts,
    }
    AddLedger(e)
    NS.Send("GUILD", EvtString(e))
    if not opts.quiet then
        Print(string.format("%s%d puntos para %s%s", delta > 0 and "+" or "", delta, to,
            e.why ~= "" and (" (" .. e.why .. ")") or ""))
    end
end

-- Pase de lista: suma puntos a todos los miembros de la guild que estén en el grupo/raid.
function NS.PaseDeLista(points, motivo)
    if not NS.IsOfficer(NS.me) then
        Print("Solo los oficiales pueden pasar lista. (¿Cargó el roster? Probá de nuevo en unos segundos.)")
        return
    end
    points = tonumber(points) or 5
    if points < 1 or points > 20 then
        Print("Los puntos de asistencia van de 1 a 20.")
        return
    end
    motivo = Clean((motivo and motivo ~= "") and motivo or "Evento", 40)

    local names = {}
    for _, n in ipairs(NS.GetGroupNames()) do
        n = Short(n)
        if rankByName[n] ~= nil then names[#names + 1] = n end
    end
    if #names == 0 then
        Print("No hay miembros de la guild en tu grupo.")
        return
    end

    local key = motivo .. ":" .. date("%Y-%m-%d")
    if NS.db.listas[key] then
        Print("Ya pasaste lista de '" .. motivo .. "' hoy. Si es otro evento, cambiá el motivo.")
        return
    end
    NS.db.listas[key] = true

    local i = 1
    local function step()
        local n = names[i]
        if not n then
            Print(string.format("Pase de lista listo: %d presentes, +%d puntos c/u (%s).", #names, points, motivo))
            return
        end
        NS.Award(n, points, "Asistencia: " .. motivo, { allowSelf = true, quiet = true })
        i = i + 1
        C_Timer.After(0.4, step)
    end
    step()
end

NS.Handle("EVT", function(sender, channel, id, to, d, why, by, ts)
    d, ts = tonumber(d), tonumber(ts)
    if not (id and to and d and by and ts) then return end
    if math.abs(d) > 100 then return end
    if not NS.IsOfficer(by) then Debug("EVT de alguien que no es oficial:", by); return end
    -- En vivo (GUILD) quien manda tiene que ser quien otorga. Por sync (WHISPER) puede ser un relay.
    if channel == "GUILD" and sender ~= by then return end
    local e = { id = id, to = Short(to), d = d, why = Clean(why, 60), by = Short(by), ts = ts }
    if AddLedger(e) and channel == "GUILD" and e.to == NS.me then
        NS.Toast(string.format("%s te dio %s%d puntos%s", e.by, e.d > 0 and "+" or "", e.d,
            e.why ~= "" and (": " .. e.why) or ""), 5, "puntos")
        NS.PlaySound("puntos")
    end
end)

-- Sync: un compañero que se conecta pide lo que le falta; alguien (al azar) le responde.
local function LatestTs()
    local t = 0
    for _, e in ipairs(NS.db.ledger) do
        if e.ts > t then t = e.ts end
    end
    return t
end

----------------------------------------------------------------
-- Reinicio de contadores (solo GM y oficiales). Se propaga a toda la guild.
-- Cada reinicio guarda su momento ("época"): los mensajes de quien todavía no se enteró se ignoran,
-- así los datos viejos no vuelven a aparecer.
----------------------------------------------------------------
local RESET_CATS = { muertes = true, historial = true, pvp = true, niveles = true }
local RESET_INFO = {
    muertes   = "el contador de muertes (Pollo del Mes)",
    historial = "el historial de muertes",
    pvp       = "las bajas PvP (Carnicero del Mes)",
    niveles   = "los niveles y Los Primeros",
}

local function MaxReset()
    local m = 0
    for cat in pairs(RESET_CATS) do
        if (NS.db.resets[cat] or 0) > m then m = NS.db.resets[cat] end
    end
    return m
end

function NS.ApplyReset(cat, ts, by)
    if not RESET_CATS[cat] then return false end
    if ts <= (NS.db.resets[cat] or 0) then return false end
    NS.db.resets[cat] = ts
    NS.db.resetBy[cat] = by
    if cat == "muertes" then
        wipe(NS.db.deaths); wipe(NS.db.myDeaths); NS.Fire("DEATHS_UPDATED")
    elseif cat == "historial" then
        wipe(NS.db.deathLog); NS.Fire("DEATHLOG_UPDATED")
    elseif cat == "pvp" then
        wipe(NS.db.pvp); NS.Fire("PVP_UPDATED")
    elseif cat == "niveles" then
        wipe(NS.db.levels); wipe(NS.db.firsts); NS.Fire("LEVELS_UPDATED")
    end
    return true
end

-- Llamado desde /asado reset (ya verificado que es oficial)
function NS.DoReset(cat, confirmed)
    if not RESET_CATS[cat] then
        Print("Uso: /asado reset muertes | historial | pvp | niveles")
        return
    end
    if not confirmed then
        Print("Esto borra " .. RESET_INFO[cat] .. " de TODA la guild. Para confirmar: |cffffd100/asado reset " .. cat .. " confirmar|r")
        return
    end
    local ts = math.max(GetServerTime(), (NS.db.resets[cat] or 0) + 1)
    NS.ApplyReset(cat, ts, NS.me)
    NS.Send("GUILD", table.concat({ "RESET", cat, ts, NS.me }, "^"))
    Print("Reiniciaste " .. RESET_INFO[cat] .. " para toda la guild.")
end

NS.Handle("RESET", function(sender, channel, cat, ts, by)
    ts = tonumber(ts)
    if not (cat and ts and by and by ~= "") then return end
    if ts > GetServerTime() + 60 then return end
    if not NS.IsOfficer(by) then return end                       -- solo vale si lo hizo un oficial
    if channel == "GUILD" and sender ~= Short(by) then return end -- en vivo, tiene que venir de quien lo hizo
    if NS.ApplyReset(cat, ts, Short(by)) then
        Print(Short(by) .. " reinició " .. (RESET_INFO[cat] or cat) .. ".")
    end
end)

-- Limpia los datos creados con /asado test (solo en tu PC, no afecta a la guild)
function NS.CleanTestData()
    local names = NS.db.testNames
    for name in pairs(names) do
        NS.db.levels[name] = nil
        for _, t in pairs(NS.db.deaths) do t[name] = nil end
        for _, t in pairs(NS.db.pvp) do t[name] = nil end
    end
    for lvl, f in pairs(NS.db.firsts) do
        if names[f.name] then NS.db.firsts[lvl] = nil end
    end
    local log = NS.db.deathLog
    for i = #log, 1, -1 do
        if names[log[i].name] then table.remove(log, i) end
    end
    wipe(names)
    NS.Fire("LEVELS_UPDATED"); NS.Fire("DEATHS_UPDATED"); NS.Fire("PVP_UPDATED"); NS.Fire("DEATHLOG_UPDATED")
    Print("Datos de prueba borrados (solo en tu PC).")
end

local function LatestDeathTs()
    local log = NS.db.deathLog
    return (#log > 0) and log[#log].ts or 0
end

local function CountFirsts()
    local c = 0
    for _ in pairs(NS.db.firsts) do c = c + 1 end
    return c
end

NS.Handle("HELLO", function(sender, channel, latest, fcount, dts, rmax)
    latest = tonumber(latest) or 0
    fcount = tonumber(fcount) or 0
    dts = tonumber(dts) or 0
    rmax = tonumber(rmax) or 0
    C_Timer.After(1 + math.random() * 5, function()
        if served[sender] and GetTime() - served[sender] < 30 then return end
        local pending = {}
        for _, e in ipairs(NS.db.ledger) do
            if e.ts > latest then pending[#pending + 1] = e end
        end
        table.sort(pending, function(a, b) return a.ts < b.ts end)

        local msgs = {}
        -- Primero los reinicios que al otro le faltan (así lo viejo se descarta enseguida)
        if MaxReset() > rmax then
            for cat in pairs(RESET_CATS) do
                local rts = NS.db.resets[cat] or 0
                if rts > 0 then msgs[#msgs + 1] = table.concat({ "RESET", cat, rts, NS.db.resetBy[cat] or "" }, "^") end
            end
        end
        for i = math.max(1, #pending - C.SYNC_MAX_EVENTS + 1), #pending do
            msgs[#msgs + 1] = EvtString(pending[i])
        end
        -- "Primeros de la guild": solo si yo sé de más niveles que el que pregunta (son pocos mensajes)
        if CountFirsts() > fcount then
            for _, lvl in ipairs(C.LEVEL_MILESTONES) do
                local f = NS.db.firsts[lvl]
                if f then msgs[#msgs + 1] = table.concat({ "FIRST", lvl, f.name, f.ts }, "^") end
            end
        end
        -- Historial de muertes: las más nuevas que las que tiene el que pregunta
        local dpending = {}
        for _, e in ipairs(NS.db.deathLog) do
            if e.ts > dts then dpending[#dpending + 1] = e end
        end
        for i = math.max(1, #dpending - 14), #dpending do
            msgs[#msgs + 1] = NS.DeathLogString(dpending[i])
        end
        if #msgs == 0 then return end

        served[sender] = GetTime()
        NS.Send("GUILD", "SERVING^" .. sender, nil, true)
        local i = 1
        local function step()
            local m = msgs[i]
            if not m then return end
            NS.Send("WHISPER", m, NS.WhisperTarget(sender), true)
            i = i + 1
            C_Timer.After(0.4, step)
        end
        step()
    end)
end)

NS.Handle("SERVING", function(sender, channel, who)
    if who then served[who] = GetTime() end
end)

----------------------------------------------------------------
-- Muertes - "El Pollo del Mes"
----------------------------------------------------------------
local SKULL = "|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8:14|t"

local function RandomOf(list)
    return list[math.random(#list)]
end

local function ClassColored(name, classFile)
    local c = classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]
    if c then
        return string.format("|cff%02x%02x%02x%s|r", c.r * 255, c.g * 255, c.b * 255, name)
    end
    return name
end

-- "Subzona, Zona (45, 32)"
local function WhereText(zone, sub, coords)
    local t = zone or ""
    if sub and sub ~= "" and sub ~= zone then
        t = (t ~= "") and (sub .. ", " .. t) or sub
    end
    if t == "" then t = "algún lado" end
    if coords and coords ~= "" then t = t .. " (" .. (coords:gsub(",", ", ")) .. ")" end
    return t
end

local function MyCoords()
    local coords = ""
    pcall(function()
        local mapID = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
        local pos = mapID and C_Map.GetPlayerMapPosition(mapID, "player")
        if pos then
            local x, y = pos:GetXY()
            if x and y and (x > 0 or y > 0) then coords = string.format("%.0f,%.0f", x * 100, y * 100) end
        end
    end)
    return coords
end

NS.ClassColored = ClassColored
NS.WhereText = WhereText

----------------------------------------------------------------
-- Historial de muertes de la guild
----------------------------------------------------------------
local DEATHLOG_MAX = 300

-- e = { name, class, lvl, zone, sub, coords, pvp (bool), ts }
function NS.AddDeathLog(e)
    if e.ts <= (NS.db.resets.historial or 0) then return false end   -- es de antes de un reinicio
    local log = NS.db.deathLog
    -- Duplicado: la misma persona con menos de 10 segundos de diferencia (llegó en vivo y por sync)
    for i = #log, math.max(1, #log - 60), -1 do
        if log[i].name == e.name and math.abs(log[i].ts - e.ts) <= 10 then return false end
    end
    local pos = #log + 1
    while pos > 1 and log[pos - 1].ts > e.ts do pos = pos - 1 end   -- mantener orden por fecha
    table.insert(log, pos, e)
    while #log > DEATHLOG_MAX do table.remove(log, 1) end
    NS.Fire("DEATHLOG_UPDATED")
    return true
end

function NS.DeathLogString(e)
    return table.concat({ "DLOG", e.ts, e.name, e.class or "", e.lvl or 0,
        e.zone or "", e.sub or "", e.coords or "", e.pvp and 1 or 0 }, "^")
end

-- Muertes que me pasa otro compañero al sincronizar
NS.Handle("DLOG", function(sender, channel, ts, name, classFile, lvl, zone, sub, coords, pvp)
    ts, lvl = tonumber(ts), tonumber(lvl)
    if not (ts and name and name ~= "") then return end
    local now = GetServerTime()
    if ts > now + 60 or ts < now - 60 * 86400 then return end   -- fechas imposibles
    if not (classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]) then classFile = nil end
    if lvl and (lvl < 1 or lvl > 100) then lvl = nil end
    NS.AddDeathLog({ name = Short(Clean(name, 30)), class = classFile, lvl = lvl,
        zone = Clean(zone, 40), sub = Clean(sub, 40), coords = Clean(coords, 10),
        pvp = (pvp == "1"), ts = ts })
end)

-- Arma los textos de una muerte. El aviso en pantalla y la línea del chat usan EXACTAMENTE lo mismo.
local function DeathTexts(name, classFile, lvl, zone, sub, coords, n, pvp)
    local who = ClassColored(name, classFile)
    local lvlTxt = lvl and (" (nv " .. lvl .. ")") or ""
    local where = WhereText(zone, sub, coords)
    local verb = pvp and "cayó en combate en" or "murió en"
    local extra
    if pvp then
        extra = RandomOf(C.DEATH_SUFFIX_PVP)
    else
        extra = (n and string.format("Muerte #%d del mes. ", n) or "") .. RandomOf(C.DEATH_SUFFIX)
    end
    local line  = string.format("%s%s %s %s. %s", who, lvlTxt, verb, where, extra)
    local toast = string.format("%s%s %s %s\n%s", who, lvlTxt, verb, where, extra)
    return line, toast
end

local function PrintDeath(line)
    print(SKULL .. " |cffff4040[" .. C.SHORT_NAME .. "]|r " .. line)
end

NS:On("PLAYER_DEAD", function()
    local mk = NS.MonthKey()
    local _, instType = GetInstanceInfo()
    local pvp = (instType == "pvp" or instType == "arena")   -- campo de batalla o arena

    -- Las muertes en PvP se avisan pero NO cuentan para el Pollo del Mes
    local n
    if not pvp then
        n = (NS.db.myDeaths[mk] or 0) + 1
        NS.db.myDeaths[mk] = n
        NS.db.deaths[mk] = NS.db.deaths[mk] or {}
        NS.db.deaths[mk][NS.me] = n
    end
    NS.PlaySound("muerte")

    local _, classFile = UnitClass("player")
    local lvl = UnitLevel("player")
    local zone = (GetRealZoneText and GetRealZoneText()) or GetZoneText() or ""
    local sub = GetSubZoneText and GetSubZoneText() or ""
    local coords = MyCoords()

    NS.AddDeathLog({ name = NS.me, class = classFile, lvl = lvl, zone = zone, sub = sub,
        coords = coords, pvp = pvp, ts = GetServerTime() })

    if NS.db.deathChat then
        PrintDeath((DeathTexts(NS.me, classFile, lvl, zone, sub, coords, n, pvp)))
    end
    if NS.db.broadcastDeaths and IsInGuild() then
        NS.Send("GUILD", table.concat({ "DEAD", mk, n or 0, Clean(zone, 40), Clean(sub, 40),
            lvl, classFile or "", Clean(coords, 10), pvp and 1 or 0, NS.db.resets.muertes }, "^"))
    end
    NS.Fire("DEATHS_UPDATED")
end)

local lastDeathShown = {}

-- Muerte de un compañero. Los campos nuevos son opcionales (compatibles con versiones anteriores).
NS.Handle("DEAD", function(sender, channel, mk, n, zone, sub, lvl, classFile, coords, pvpFlag, epoch)
    n, lvl = tonumber(n), tonumber(lvl)
    local pvp = (pvpFlag == "1")
    if n and n > 0 and mk and #mk == 7 and (tonumber(epoch) or 0) >= NS.db.resets.muertes then
        NS.db.deaths[mk] = NS.db.deaths[mk] or {}
        if (NS.db.deaths[mk][sender] or 0) < n then NS.db.deaths[mk][sender] = n end
        NS.Fire("DEATHS_UPDATED")
    end

    zone, sub, coords = Clean(zone, 40), Clean(sub, 40), Clean(coords, 10)
    if not (classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]) then classFile = nil end
    if lvl and (lvl < 1 or lvl > 100) then lvl = nil end

    -- Queda en el historial aunque no se muestre el aviso
    NS.AddDeathLog({ name = sender, class = classFile, lvl = lvl, zone = zone, sub = sub,
        coords = coords, pvp = pvp, ts = GetServerTime() })

    -- Anti-spam: un aviso por compañero cada 10 segundos
    local now = GetTime()
    if lastDeathShown[sender] and now - lastDeathShown[sender] < 10 then return end
    lastDeathShown[sender] = now

    local nShow = (n and n > 0 and mk == NS.MonthKey()) and n or nil
    local line, toast = DeathTexts(sender, classFile, lvl, zone, sub, coords, nShow, pvp)

    if NS.db.deathChat then PrintDeath(line) end
    if NS.db.toasts.deaths and not NS.inEncounter then
        NS.Toast(toast, 5, "muerte")
        if NS.db.sounds.guildDeaths then NS.PlaySound("muerte_guild") end
    end
end)

NS.Handle("DEATHS", function(sender, channel, mk, n, epoch)
    n = tonumber(n)
    if not (n and mk and #mk == 7) then return end
    if (tonumber(epoch) or 0) < NS.db.resets.muertes then return end   -- datos de antes de un reinicio
    NS.db.deaths[mk] = NS.db.deaths[mk] or {}
    if (NS.db.deaths[mk][sender] or 0) < n then
        NS.db.deaths[mk][sender] = n
        NS.Fire("DEATHS_UPDATED")
    end
end)

----------------------------------------------------------------
-- Niveles - "La Carrera" y "Los Primeros de la guild"
----------------------------------------------------------------
function NS.IsMilestone(level)
    for _, m in ipairs(C.LEVEL_MILESTONES) do
        if m == level then return true end
    end
    local max = (GetMaxPlayerLevel and GetMaxPlayerLevel())
        or (GetMaxLevelForPlayerExpansion and GetMaxLevelForPlayerExpansion())
    return max ~= nil and level == max
end

local function Pick(list)
    return list[math.random(#list)]
end

-- Registra que "name" alcanzó "level" en el momento "ts".
-- live = true -> es un aviso en vivo (puede disparar notificación).
-- noFirst = true -> no tocar la tabla de "primeros" (cuando no sabemos cuándo subió de verdad).
function NS.RecordLevel(name, level, ts, live, noFirst)
    local known = NS.db.levels[name]
    local already = known ~= nil and known.l >= level

    if not known or level > known.l then
        NS.db.levels[name] = { l = level, ts = ts }
    elseif level == known.l and ts < known.ts then
        known.ts = ts
    end

    local isFirst = false
    if not noFirst then
        local first = NS.db.firsts[level]
        if not first then
            NS.db.firsts[level] = { name = name, ts = ts }
            isFirst = true
        elseif ts < first.ts then
            NS.db.firsts[level] = { name = name, ts = ts }
        end
    end
    NS.Fire("LEVELS_UPDATED")

    if live and IsInGuild() and not already and NS.IsMilestone(level) and NS.db.toasts.levels then
        if isFirst then
            if name == NS.me then
                NS.Toast(string.format("¡Sos el PRIMERO de la guild en llegar a nivel %d!", level), 6, "nivel")
            else
                NS.Toast(string.format(Pick(C.LEVEL_FRASES_PRIMERO), name, level), 6, "nivel")
            end
            NS.PlaySound("primero")
        elseif name ~= NS.me then
            NS.Toast(string.format(Pick(C.LEVEL_FRASES_NORMAL), name, level), 4, "nivel")
            NS.PlaySound("nivel_guild")
        end
    end
end

-- Ranking combinado: nivel real del roster de la guild + lo que reportaron los addons.
function NS.LevelRanking(n)
    local merged = {}
    for name, lvl in pairs(NS.rosterLevels) do
        local rec = NS.db.levels[name]
        merged[name] = { name = name, l = lvl, ts = (rec and rec.l == lvl) and rec.ts or math.huge }
    end
    for name, rec in pairs(NS.db.levels) do
        if not merged[name] or rec.l > merged[name].l then
            merged[name] = { name = name, l = rec.l, ts = rec.ts }
        end
    end
    local arr = {}
    for _, e in pairs(merged) do arr[#arr + 1] = e end
    table.sort(arr, function(a, b)
        if a.l ~= b.l then return a.l > b.l end
        if a.ts ~= b.ts then return a.ts < b.ts end
        return a.name < b.name
    end)
    while #arr > n do table.remove(arr) end
    return arr
end

NS:On("PLAYER_LEVEL_UP", function(level)
    NS.PlaySound("nivel")
    level = tonumber(level) or UnitLevel("player")
    local ts = GetServerTime()
    NS.RecordLevel(NS.me, level, ts, true)
    if IsInGuild() then NS.Send("GUILD", "LVL^" .. level .. "^" .. ts) end
end)

-- Aviso en vivo de un compañero (GUILD) o dato de sincronización (WHISPER)
NS.Handle("LVL", function(sender, channel, level, ts)
    level, ts = tonumber(level), tonumber(ts)
    if not (level and ts) or level < 1 or level > 100 then return end
    local now = GetServerTime()
    if ts > now + 60 then ts = now end   -- no creerle a relojes del futuro
    local stale = ts <= NS.db.resets.niveles   -- de antes de un reinicio: se anota sin avisos ni "primeros"
    NS.RecordLevel(sender, level, ts, channel == "GUILD" and not stale, stale)
end)

-- "Estoy en nivel X" al conectarse (sin momento exacto): solo actualiza el ranking
NS.Handle("LVLS", function(sender, channel, level)
    level = tonumber(level)
    if not level or level < 1 or level > 100 then return end
    NS.RecordLevel(sender, level, GetServerTime(), false, true)
end)

NS.Handle("FIRST", function(sender, channel, level, name, ts)
    level, ts = tonumber(level), tonumber(ts)
    if not (level and name and ts) or level < 1 or level > 100 then return end
    if ts <= NS.db.resets.niveles then return end
    local first = NS.db.firsts[level]
    if not first or ts < first.ts then
        NS.db.firsts[level] = { name = Short(name), ts = ts }
        NS.Fire("LEVELS_UPDATED")
    end
end)

----------------------------------------------------------------
-- PvP - "El Carnicero del Mes" (bajas honorables; neutral a la facción)
----------------------------------------------------------------
-- Convierte un texto de GlobalStrings ("%s dies, honorable kill ...") en un patrón de Lua.
local function FormatToPattern(fmt)
    local p = (fmt:gsub("%%%d?%$?[sd]", "\001"))
    p = p:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
    p = p:gsub("\001", "(.-)")
    return "^" .. p .. "$"
end

local honorPatterns = {}
for _, g in ipairs({ "COMBATLOG_HONORGAIN", "COMBATLOG_HONORGAIN_NO_RANK" }) do
    if type(_G[g]) == "string" then honorPatterns[#honorPatterns + 1] = FormatToPattern(_G[g]) end
end

local function ReadLifetimeHK()
    if not GetPVPLifetimeStats then return nil end
    local ok, hk = pcall(GetPVPLifetimeStats)
    if ok and type(hk) == "number" then return hk end
    return nil
end

function NS.PvPSupported()
    return GetPVPLifetimeStats ~= nil or #honorPatterns > 0
end

-- Fija el total de bajas del mes de "name". live = true -> puede disparar avisos.
function NS.SetKills(name, mk, total, live)
    NS.db.pvp[mk] = NS.db.pvp[mk] or {}
    local t = NS.db.pvp[mk]
    local prev = t[name] or 0
    if total <= prev then return end
    local monthWasEmpty = next(t) == nil
    t[name] = total
    NS.Fire("PVP_UPDATED")

    if not (live and mk == NS.MonthKey() and IsInGuild() and NS.db.toasts.pvp) then return end
    if monthWasEmpty then
        NS.Toast(string.format("¡Primera sangre del mes! %s ya cobró su primera baja.", name), 5, "pvp")
        NS.PlaySound("primero")
        return
    end
    for _, m in ipairs(C.PVP_MILESTONES) do
        if prev < m and total >= m then
            if name == NS.me then
                NS.Toast(string.format("¡Llegaste a %d bajas este mes!", m), 5, "pvp")
            else
                NS.Toast(string.format(RandomOf(C.PVP_FRASES), name, m), 5, "pvp")
            end
            NS.PlaySound("nivel_guild")
            break
        end
    end
end

local function OnMyKills(delta)
    local mk = NS.MonthKey()
    NS.db.pvp[mk] = NS.db.pvp[mk] or {}
    local total = (NS.db.pvp[mk][NS.me] or 0) + delta
    NS.SetKills(NS.me, mk, total, true)
    if IsInGuild() then NS.Send("GUILD", "HK^" .. mk .. "^" .. total .. "^" .. NS.db.resets.pvp) end
end

local function CheckKills()
    local hk = ReadLifetimeHK()
    if not hk then return end
    local last = NS.db.pvpLifetime
    NS.db.pvpLifetime = hk
    if last and hk > last then
        if hk - last > 25 then
            Debug("Salto raro de bajas, se reinicia la base:", last, hk)   -- datos que llegaron tarde
        else
            OnMyKills(hk - last)
        end
    end
end

NS:On("PLAYER_PVP_KILLS_CHANGED", CheckKills)

-- Respaldo: si el cliente no tiene estadísticas de por vida, se cuenta por el mensaje de honor.
NS:On("CHAT_MSG_COMBAT_HONOR_GAIN", function(msg)
    if ReadLifetimeHK() then return end
    if not msg or IsSecret(msg) then return end
    for _, pat in ipairs(honorPatterns) do
        if msg:match(pat) then OnMyKills(1); return end
    end
end)

NS.Handle("HK", function(sender, channel, mk, total, epoch)
    total = tonumber(total)
    if not (total and mk and #mk == 7) or total < 1 or total > 100000 then return end
    if (tonumber(epoch) or 0) < NS.db.resets.pvp then return end
    NS.SetKills(sender, mk, total, channel == "GUILD")
end)

-- Igual que HK pero sin avisos (se manda al conectarse)
NS.Handle("HKS", function(sender, channel, mk, total, epoch)
    total = tonumber(total)
    if not (total and mk and #mk == 7) or total < 1 or total > 100000 then return end
    if (tonumber(epoch) or 0) < NS.db.resets.pvp then return end
    NS.SetKills(sender, mk, total, false)
end)

-- (Ubicación de compañeros: ver Ubicacion.lua)

----------------------------------------------------------------
-- Sonidos - "El Locutor del Barrio"
-- Si no hay archivo propio en Sounds/, usa un sonido del juego como reemplazo.
----------------------------------------------------------------
local SND = "Interface\\AddOns\\" .. ADDON .. "\\Sounds\\"

-- len = duración (s) · prio = importancia (3 más alta) · cd = segundos mínimos entre repeticiones
NS.Sounds = {
    muerte       = { file = SND .. "muerte.ogg",       kit = "RAID_WARNING",           len = 2.1, prio = 3 },
    muerte_guild = { file = SND .. "muerte_guild.ogg", kit = "IG_PLAYER_INVITE",       len = 3.2, prio = 1, cd = 8 },
    wipe         = { file = SND .. "wipe.ogg",         kit = "RAID_WARNING",           len = 5.0, prio = 3 },
    kill         = { file = SND .. "kill.ogg",         kit = "IG_QUEST_LIST_COMPLETE", len = 1.4, prio = 3 },
    epico        = { file = SND .. "epico.ogg",        kit = "UI_BNET_TOAST",          len = 5.1, prio = 2, cd = 2 },
    nivel        = { file = SND .. "nivel.ogg",        kit = "IG_QUEST_LIST_COMPLETE", len = 1.8, prio = 2 },
    nivel_guild  = { file = SND .. "nivel_guild.ogg",  kit = "UI_BNET_TOAST",          len = 5.4, prio = 1, cd = 3 },
    primero      = { file = SND .. "primero.ogg",      kit = "READY_CHECK",            len = 1.8, prio = 2 },
    puntos       = { file = SND .. "puntos.ogg",       kit = "UI_BNET_TOAST",          len = 1.5, prio = 2, cd = 2 },
    ruleta_tick  = { kit = "IG_MAINMENU_OPTION_CHECKBOX_ON" },
    ruleta_win   = { file = SND .. "ruleta.ogg",       kit = "IG_QUEST_LIST_COMPLETE", len = 3.8, prio = 2 },
}

local currentSound = { key = nil, prio = 0, untilT = 0, handle = nil }
local lastPlayed = {}

-- force = true ignora los toggles y las reglas anti-solapamiento (para probar con /asado sonido <clave>)
-- Reglas: un sonido no interrumpe a otro que está sonando, salvo que sea más importante (en ese caso lo corta).
function NS.PlaySound(key, force)
    local s = NS.Sounds[key]
    if not s then return end
    local now = GetTime()
    if not force then
        if not NS.db.sounds.enabled then return end
        if NS.inEncounter and NS.db.sounds.muteInEncounter then return end
        if s.cd and lastPlayed[key] and now - lastPlayed[key] < s.cd then return end
        if now < currentSound.untilT then
            if (s.prio or 1) <= currentSound.prio then return end
            if currentSound.handle and StopSound then pcall(StopSound, currentSound.handle) end
        end
    end

    local src, handle
    if s.file then
        local ok, willPlay, h = pcall(PlaySoundFile, s.file, "Master")
        if ok and willPlay then src, handle = "archivo", h end
    end
    if not src and s.kit and SOUNDKIT and SOUNDKIT[s.kit] then
        local ok, _, h = pcall(PlaySound, SOUNDKIT[s.kit], "Master")
        if ok then src, handle = "juego", h end
    end

    if src and not force then
        lastPlayed[key] = now
        if s.len then
            currentSound.key, currentSound.prio, currentSound.untilT, currentSound.handle = key, s.prio or 1, now + s.len, handle
        end
    end
    return src
end

-- Corta el sonido indicado si es el que está sonando (lo usa /asado himno stop)
function NS.StopSound(key)
    if currentSound.key ~= key then return end
    if currentSound.handle and StopSound then pcall(StopSound, currentSound.handle) end
    currentSound.key, currentSound.untilT, currentSound.handle = nil, 0, nil
end

-- /asado sonido todos: reproduce cada sonido en orden e informa si usa el archivo de la guild o el del juego
function NS.TestAllSounds()
    local keys = { "muerte", "muerte_guild", "wipe", "kill", "epico", "nivel", "nivel_guild", "primero", "puntos", "ruleta_win" }
    local i = 1
    local function step()
        local k = keys[i]
        if not k then Print("Prueba de sonidos terminada."); return end
        local src = NS.PlaySound(k, true)
        Print(string.format("%d/%d  %s  ->  %s", i, #keys, k,
            src == "archivo" and "|cff33ff33archivo de la guild|r" or "|cffffd100sonido del juego (falta el .ogg)|r"))
        i = i + 1
        C_Timer.After(6, step)
    end
    step()
end

NS:On("ENCOUNTER_START", function()
    NS.inEncounter = true
end)

NS:On("ENCOUNTER_END", function(id, name, difficulty, size, success)
    NS.inEncounter = false
    C_Timer.After(1.5, function()
        NS.PlaySound(success == 1 and "kill" or "wipe")
        FlushOutbox()
    end)
end)

NS:On("PLAYER_ENTERING_WORLD", function()
    NS.inEncounter = false
end)

NS:On("PLAYER_REGEN_ENABLED", function()
    C_Timer.After(1, FlushOutbox)
end)

-- Mensajes de "recibís botín" en el idioma del cliente (ej: "Recibes botín: %s.")
local selfLootPatterns = {}
for _, g in ipairs({ "LOOT_ITEM_SELF", "LOOT_ITEM_SELF_MULTIPLE", "LOOT_ITEM_PUSHED_SELF",
                     "LOOT_ITEM_PUSHED_SELF_MULTIPLE", "LOOT_ITEM_BONUS_ROLL_SELF",
                     "LOOT_ITEM_BONUS_ROLL_SELF_MULTIPLE" }) do
    if type(_G[g]) == "string" then selfLootPatterns[#selfLootPatterns + 1] = FormatToPattern(_G[g]) end
end

-- Calidad (0-8) de un objeto a partir del mensaje. Entiende los dos formatos de enlace:
--   moderno: |cnIQ4:|Hitem:...   (el número es la calidad)      clásico: |cffa335ee|Hitem:...  (color)
local function QualityFromLoot(msg)
    local q = msg:match("|cn[Ii][Qq](%d):|Hitem:")
    if q then return tonumber(q) end
    local color = msg:match("|cff(%x%x%x%x%x%x)|Hitem:")
    if color == "a335ee" then return 4 end   -- épico
    if color == "ff8000" then return 5 end   -- legendario
    -- Último recurso: preguntarle al juego por el objeto
    local id = tonumber(msg:match("|Hitem:(%d+)"))
    if id then
        if C_Item and C_Item.GetItemQualityByID then
            local ok, qual = pcall(C_Item.GetItemQualityByID, id)
            if ok and type(qual) == "number" then return qual end
        end
        if GetItemInfo then
            local _, _, qual = GetItemInfo(id)
            if qual then return qual end
        end
    end
    return nil
end

local lastEpicSound = 0

NS:On("CHAT_MSG_LOOT", function(msg, _, _, _, _, _, _, _, _, _, _, guid)
    if not msg or IsSecret(msg) then return end

    -- ¿Es mío? Por el texto del mensaje (no depende del idioma) o, si no, por el GUID.
    local mine = false
    for _, pat in ipairs(selfLootPatterns) do
        if msg:match(pat) then mine = true; break end
    end
    if not mine and guid and not IsSecret(guid) and guid == UnitGUID("player") then mine = true end

    local quality = mine and QualityFromLoot(msg) or nil
    Debug("LOOT", (msg:gsub("|", "||")), "| mío:", tostring(mine), "| calidad:", tostring(quality))

    if quality == 4 or quality == 5 then   -- épico o legendario
        local now = GetTime()
        if now - lastEpicSound > 3 then    -- no repetir si caen varios juntos
            lastEpicSound = now
            NS.PlaySound("epico")
        end
    end
end)

----------------------------------------------------------------
-- Ruleta del Fernet
----------------------------------------------------------------
function NS.GetGroupNames()
    local t = {}
    if IsInRaid() then
        for i = 1, GetNumGroupMembers() do
            local n = GetRaidRosterInfo(i)
            if n then t[#t + 1] = Short(n) end
        end
    elseif IsInGroup() then
        t[#t + 1] = NS.me
        for i = 1, GetNumSubgroupMembers() do
            local n = UnitName("party" .. i)
            if n then t[#t + 1] = Short(n) end
        end
    else
        t[1] = NS.me
    end
    return t
end

-- names: lista de candidatos. Sortea acá y avisa a los demás (el resultado va en el mensaje).
function NS.StartRuleta(names, title)
    if not names or #names < 2 then
        Print("Hacen falta al menos 2 participantes.")
        return
    end
    title = Clean(title ~= "" and title or "Fernet", 30)
    local winner = names[math.random(#names)]
    local id = NS.me .. ":" .. GetServerTime() .. ":" .. math.random(1000, 9999)
    local list = table.concat(names, ",")
    if #list > 150 then list = "" end   -- no entra en el mensaje: los demás animan con su propio grupo

    local ch = NS.GroupChannel()
    if ch then
        NS.Send(ch, table.concat({ "RULETA", id, winner, title, list }, "^"), nil, true)
    end
    NS.Fire("RULETA_START", { id = id, winner = winner, title = title, names = names, by = NS.me, mine = true })
end

NS.Handle("RULETA", function(sender, channel, id, winner, title, list)
    if not (id and winner and winner ~= "") then return end
    local names
    if list and list ~= "" then names = { strsplit(",", list) } end
    NS.Fire("RULETA_START", { id = id, winner = winner, title = title or "Fernet", names = names, by = sender, mine = false })
end)

-- Cuando termina la animación, quien tiró anuncia el resultado en el chat del grupo.
NS.RegisterCallback("RULETA_DONE", function(d)
    if not d.mine then return end
    local ch = NS.GroupChannel()
    if not ch or not NS.CanSend() then return end
    local frases = C.RULETA_FRASES
    pcall(SendChat, string.format(frases[math.random(#frases)], d.title, d.winner), ch)
end)

----------------------------------------------------------------
-- Inicialización
----------------------------------------------------------------
NS:On("ADDON_LOADED", function(name)
    if name ~= ADDON then return end
    NS.InitDB()
end)

-- Sincronización con la guild.
-- Se llama al conectarse y en cada pantalla de carga (cambio de zona, instancias).
--   * "Liviano" (máx. 1 vez por minuto): mi nivel, mis muertes y mis bajas del mes.
--   * "Completo" (máx. 1 vez cada 5 minutos): además pide lo que me falta (puntos, muertes, primeros).
local lastLight, lastFull = -1000, -1000
local publishedFirsts = false

function NS.SyncNow(force, tries)
    if not IsInGuild() then return end
    tries = tries or 0
    -- Esperar a que cargue el roster (hace falta para saber quién es oficial)
    if not NS.rosterReady and tries < 6 then
        NS.RequestRoster()
        C_Timer.After(5, function() NS.SyncNow(force, tries + 1) end)
        return
    end

    local now = GetTime()
    if not force and now - lastLight < 60 then return end
    lastLight = now

    NS.RecordLevel(NS.me, UnitLevel("player"), GetServerTime(), false, true)
    NS.Send("GUILD", "LVLS^" .. UnitLevel("player"))

    local mk = NS.MonthKey()
    local n = NS.db.myDeaths[mk]
    if n and n > 0 then NS.Send("GUILD", "DEATHS^" .. mk .. "^" .. n .. "^" .. NS.db.resets.muertes) end
    local hk = NS.db.pvp[mk] and NS.db.pvp[mk][NS.me]
    if hk and hk > 0 then NS.Send("GUILD", "HKS^" .. mk .. "^" .. hk .. "^" .. NS.db.resets.pvp) end

    if force or now - lastFull > 300 then
        lastFull = now
        NS.Send("GUILD", "HELLO^" .. LatestTs() .. "^" .. CountFirsts() .. "^" .. LatestDeathTs() .. "^" .. MaxReset())
    end

    -- Publicar mis "primeros" (hitos donde figuro yo) una vez por sesión
    if force or not publishedFirsts then
        publishedFirsts = true
        local mine = {}
        for _, lvl in ipairs(C.LEVEL_MILESTONES) do
            local f = NS.db.firsts[lvl]
            if f and f.name == NS.me then mine[#mine + 1] = lvl end
        end
        local i = 1
        local function step()
            local lvl = mine[i]
            if not lvl then return end
            local f = NS.db.firsts[lvl]
            NS.Send("GUILD", table.concat({ "FIRST", lvl, f.name, f.ts }, "^"), nil, true)
            i = i + 1
            C_Timer.After(0.5, step)
        end
        C_Timer.After(8, step)   -- después de que lleguen las respuestas al HELLO
    end
end

-- Compatibilidad: fundar/unirse a una guild con el juego abierto fuerza una sincronización completa
function NS.AnnounceToGuild() NS.SyncNow(true) end

-- Cada pantalla de carga (login, /reload, cambio de zona, entrar a una instancia)
NS:On("PLAYER_ENTERING_WORLD", function(isLogin, isReload)
    local first = isLogin or isReload
    if not first and not NS.db.syncOnZone then return end
    C_Timer.After(first and 10 or 5, function() NS.SyncNow(false) end)
end)

local MESES = { "enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
                "septiembre", "octubre", "noviembre", "diciembre" }

-- Al primer login de un mes nuevo: anuncia quién fue el Asador y el Pollo del mes anterior.
function NS.AnnounceMonthWinners()
    if not IsInGuild() then return end
    local mk = NS.MonthKey()
    if NS.db.lastMonthShown == mk then return end
    NS.db.lastMonthShown = mk

    local t = date("*t", GetServerTime())
    local prev = time({ year = t.year, month = t.month, day = 1, hour = 12 }) - 86400
    local pk = date("%Y-%m", prev)

    local pts = {}
    for _, e in ipairs(NS.db.ledger) do
        if date("%Y-%m", e.ts) == pk then pts[e.to] = (pts[e.to] or 0) + e.d end
    end
    local a = NS.TopN(pts, 1)[1]
    local p = NS.TopN(NS.db.deaths[pk] or {}, 1)[1]
    if not a and not p then return end

    local mes = MESES[tonumber(pk:sub(6, 7))] or pk
    local parts = {}
    if a then parts[#parts + 1] = string.format("Asador de %s: |cffffd100%s|r (%d pts)", mes, a.name, a.v) end
    if p then parts[#parts + 1] = string.format("Pollo de %s: |cffff6644%s|r (%d muertes)", mes, p.name, p.v) end
    NS.Toast(table.concat(parts, "\n"), 9, "nivel")
    NS.PlaySound("primero")
end

-- Cambió mi estado de guild (fundé o me uní con el juego abierto)
NS:On("PLAYER_GUILD_UPDATE", function(unit)
    if unit and unit ~= "player" then return end
    if IsInGuild() then C_Timer.After(5, NS.AnnounceToGuild) end
end)

-- Borra datos viejos: meses de hace más de 13 meses y pases de lista de hace más de 90 días.
function NS.Prune()
    local t = date("*t", GetServerTime())
    local cutoff = t.year * 12 + t.month - 13
    for _, tbl in ipairs({ NS.db.deaths, NS.db.myDeaths, NS.db.pvp }) do
        for mk in pairs(tbl) do
            local y, m = tostring(mk):match("^(%d+)-(%d+)$")
            if not y or (tonumber(y) * 12 + tonumber(m)) < cutoff then tbl[mk] = nil end
        end
    end
    local dayCutoff = GetServerTime() - 90 * 86400
    for key in pairs(NS.db.listas) do
        local y, m, d = tostring(key):match("(%d+)-(%d+)-(%d+)$")
        if y and time({ year = tonumber(y), month = tonumber(m), day = tonumber(d), hour = 12 }) < dayCutoff then
            NS.db.listas[key] = nil
        end
    end
end

-- Los datos guardados por versiones anteriores pueden tener el mismo jugador con dos nombres
-- ("Mouse" y "Mouse Asado"). Se unifican una sola vez.
function NS.MigrateNames()
    local db = NS.db
    if db.nameFix == 1 then return end

    local function mergeMax(t)   -- [nombre] = número  ->  se queda con el mayor de cada jugador
        local out = {}
        for name, v in pairs(t) do
            local s = Short(name)
            if (out[s] or -1) < v then out[s] = v end
        end
        return out
    end
    for mk, t in pairs(db.deaths) do db.deaths[mk] = mergeMax(t) end
    for mk, t in pairs(db.pvp) do db.pvp[mk] = mergeMax(t) end

    local levels = {}
    for name, rec in pairs(db.levels) do
        local s = Short(name)
        local cur = levels[s]
        if not cur or rec.l > cur.l or (rec.l == cur.l and rec.ts < cur.ts) then levels[s] = rec end
    end
    db.levels = levels
    for _, f in pairs(db.firsts) do f.name = Short(f.name) end

    for _, e in ipairs(db.ledger) do
        if e.to then e.to = Short(e.to) end
        if e.by then e.by = Short(e.by) end
    end
    NS.totalsCache = nil

    -- Historial de muertes: unificar nombres y sacar las repetidas (misma persona a menos de 10 s)
    local out = {}
    for _, e in ipairs(db.deathLog) do
        e.name = Short(e.name)
        local dup = false
        for i = #out, math.max(1, #out - 40), -1 do
            if out[i].name == e.name and math.abs(out[i].ts - e.ts) <= 10 then dup = true; break end
        end
        if not dup then out[#out + 1] = e end
    end
    db.deathLog = out

    db.nameFix = 1
end

NS:On("PLAYER_LOGIN", function()
    NS.me = Short(UnitName("player"))
    NS.MigrateNames()
    if RegisterPrefix then RegisterPrefix(C.PREFIX) end
    IndexLedger()
    NS.Prune()
    NS.RequestRoster()
    NS.Fire("READY")

    -- Base para detectar bajas honorables nuevas (sin contar las anteriores)
    C_Timer.After(5, function()
        local hk = ReadLifetimeHK()
        if hk then NS.db.pvpLifetime = hk end
    end)

    -- Primera vez que se usa el addon
    if not NS.db.welcomed then
        NS.db.welcomed = true
        C_Timer.After(6, function()
            Print("¡Bienvenido a |cffffd100" .. C.GUILD_NAME .. "|r! Escribí |cffffd100/asado|r para abrir la Parrilla.")
            Print("Web: " .. C.WEB_URL .. "  |  Discord: " .. C.DISCORD_URL)
        end)
    end
    C_Timer.After(35, NS.AnnounceMonthWinners)   -- después de la sincronización

    Print("cargado. Escribí |cffffd100/asado|r para abrir la Parrilla.")
end)

----------------------------------------------------------------
-- Comandos
----------------------------------------------------------------
local function Diag()
    local version, build, _, toc = GetBuildInfo()
    Print("Cliente:", version, "build", build, "| interface", toc)
    Print("WOW_PROJECT_ID =", tostring(WOW_PROJECT_ID), "(MAINLINE =", tostring(WOW_PROJECT_MAINLINE) .. ")")

    local checks = {
        { "C_ChatInfo.SendAddonMessage",        C_ChatInfo and C_ChatInfo.SendAddonMessage },
        { "C_ChatInfo.InChatMessagingLockdown", C_ChatInfo and C_ChatInfo.InChatMessagingLockdown },
        { "C_ChatInfo.SendChatMessage",         C_ChatInfo and C_ChatInfo.SendChatMessage },
        { "C_GuildInfo.GuildRoster",            C_GuildInfo and C_GuildInfo.GuildRoster },
        { "C_Timer.After",                      C_Timer and C_Timer.After },
        { "BackdropTemplateMixin",              BackdropTemplateMixin },
        { "issecretvalue",                      issecretvalue },
        { "SOUNDKIT",                           SOUNDKIT },
        { "Ambiguate",                          Ambiguate },
        { "GetServerTime",                      GetServerTime },
        { "GetGuildRosterMOTD",                 GetGuildRosterMOTD },
        { "GetPVPLifetimeStats (bajas PvP)",    GetPVPLifetimeStats },
        { "C_Map.GetMapWorldSize (cerca)",      C_Map and C_Map.GetMapWorldSize },
        { "WorldMapFrame (marcas en el mapa)",  _G.WorldMapFrame },
        { "WorldMapFrame:GetCanvas",            _G.WorldMapFrame and _G.WorldMapFrame.GetCanvas },
        { "C_Map.GetMapInfo (nombres de zona)", C_Map and C_Map.GetMapInfo },
        { "C_Texture.GetAtlasInfo (dragón)",    C_Texture and C_Texture.GetAtlasInfo },
    }
    for _, c in ipairs(checks) do
        print(string.format("   %-36s %s", c[1], c[2] and "|cff33ff33OK|r" or "|cffff3333NO|r"))
    end

    if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown then
        local ok, locked = pcall(C_ChatInfo.InChatMessagingLockdown)
        Print("Mensajería bloqueada ahora:", tostring(ok and locked))
    end
    if C_ChatInfo and C_ChatInfo.IsAddonMessagePrefixRegistered then
        Print("Prefijo", C.PREFIX, "registrado:", tostring(C_ChatInfo.IsAddonMessagePrefixRegistered(C.PREFIX)))
    end
    -- Cómo se ven los nombres en este cliente (en Forever podrían tener otro formato)
    local n1, n2 = UnitName("player")
    local u1, u2 = UnitName("player", true)
    Print("Nombres: UnitName =", tostring(n1), "|", tostring(n2), "| con realm =", tostring(u1), "|", tostring(u2),
        "| GetUnitName =", tostring(GetUnitName and GetUnitName("player", true)), "| NS.me =", tostring(NS.me))
    if GetNumGuildMembers and GetNumGuildMembers() > 0 then
        local sample = GetGuildRosterInfo(1)
        Print("Ejemplo del roster:", tostring(sample), "->", tostring(sample and Short(sample)))
    end
    Print("Bajas PvP soportadas:", tostring(NS.PvPSupported()))
    if NS.UI and NS.UI.DragonDiag then NS.UI.DragonDiag() end
    Print("En guild:", tostring(IsInGuild()), "| roster cargado:", tostring(NS.rosterReady),
        "| sos oficial:", tostring(NS.IsOfficer(NS.me)),
        "| tu rankIndex:", tostring(rankByName[NS.me]), "(límite oficial:", tostring(NS.db.officerMaxRank) .. ")")
end

-- Medición de rendimiento (para comprobar que el addon no pesa)
local function Perf()
    local mem
    pcall(function()
        if UpdateAddOnMemoryUsage then UpdateAddOnMemoryUsage() end
        local f = GetAddOnMemoryUsage or (C_AddOns and C_AddOns.GetAddOnMemoryUsage)
        if f then mem = f(ADDON) end
    end)
    Print("Memoria: " .. (mem and string.format("%.0f KB", mem) or "no disponible en este cliente"))

    local P = C_AddOnProfiler
    if P and P.GetAddOnMetric and Enum and Enum.AddOnProfilerMetric then
        local M = Enum.AddOnProfilerMetric
        local any = false
        for _, m in ipairs({ { "RecentAverageTime", "Tiempo promedio reciente (ms)" },
                             { "SessionAverageTime", "Tiempo promedio de la sesión (ms)" },
                             { "PeakTime", "Pico más alto (ms)" } }) do
            local id = M[m[1]]
            if id then
                local ok, v = pcall(P.GetAddOnMetric, ADDON, id)
                if ok and v then Print(string.format("%s: %.3f", m[2], v)); any = true end
            end
        end
        if not any then Print("El perfilador no devolvió datos. Si todo da 0, puede estar desactivado en el cliente.") end
    else
        Print("Este cliente no trae el perfilador de addons (C_AddOnProfiler).")
    end
    Print(string.format("Datos guardados: %d movimientos de puntos, %d muertes en el historial.", #NS.db.ledger, #NS.db.deathLog))
end

local function Help()
    Print("Comandos:")
    print("  /asado                  abre la Parrilla")
    print("  /asado ruleta           abre la ruleta")
    print("  /asado ranking          abre el ranking")
    print("  /asado niveles          abre la carrera de niveles")
    print("  /asado pvp              abre el ranking PvP")
    print("  /asado muertes          abre el historial de muertes de la guild")
    print("  /asado ubicacion on|off compartir tu ubicación con la guild (apagado de fábrica)")
    print("  /asado cerca            abre la Parrilla con la lista de compañeros cerca (cerca reset: reubica el indicador)")
    print("  /asado himno            (GM y oficiales) reproduce el Himno Nacional para toda la guild")
    print("  /asado himno stop       corta el himno (solo para vos)")
    print("  /asado dragon [oro|plata|off|escala N|x N|y N|invertir|reset]   dragón del retrato")
    print("  /asado sonido <clave>|todos   prueba los sonidos (lo puede usar cualquiera)")
    print("  /asado reset muertes|historial|pvp|niveles confirmar   (oficiales) reinicia el contador de TODA la guild")
    print("  /asado test nivel|muerte|pvp|limpiar   (oficiales) simula datos para probar")
    print("  /asado puntos <nombre> <n> [motivo]   (oficiales)")
    print("  /asado lista [puntos] [motivo]        (oficiales) pase de lista al grupo, 5 pts por defecto")
    print("  /asado sync             sincroniza con la guild ahora mismo")
    print("  /asado diag             chequea qué APIs tiene tu cliente")
    print("  /asado perf             mide memoria y uso de CPU del addon")
    print("  /asado debug            activa/desactiva mensajes de depuración")
end

-- Acciones que cambian datos de la guild: solo GM y oficiales
local function RequireOfficer(what)
    if NS.IsOfficer(NS.me) then return true end
    if not NS.rosterReady then
        Print("Todavía estoy cargando el roster de la guild. Probá de nuevo en unos segundos.")
    else
        Print("Solo el GM y los oficiales pueden " .. what .. ".")
    end
    return false
end

NS.RequireOfficer = RequireOfficer

-- Los módulos registran sus propios subcomandos: NS.commands.himno = function(rest) ... end
NS.commands = NS.commands or {}

SLASH_LEGIONASADO1 = "/asado"
SLASH_LEGIONASADO2 = "/lda"
SlashCmdList["LEGIONASADO"] = function(input)
    input = (input or ""):match("^%s*(.-)%s*$")
    local cmd, rest = input:match("^(%S+)%s*(.*)$")
    cmd = cmd and cmd:lower() or ""
    local UI = NS.UI

    if cmd == "" then
        if UI and UI.frame then UI.Toggle() end
    elseif cmd == "ruleta" then
        if UI and UI.frame then UI.Toggle(3) end
    elseif cmd == "ranking" then
        if UI and UI.frame then UI.Toggle(2) end
    elseif cmd == "puntos" then
        local who, n, why = rest:match("^(%S+)%s+([+-]?%d+)%s*(.*)$")
        if who then NS.Award(who, n, why) else Print("Uso: /asado puntos <nombre> <n> [motivo]") end
    elseif cmd == "lista" then
        -- /asado lista [puntos] [motivo]
        local pts, why = rest:match("^(%d+)%s*(.*)$")
        if not pts then pts, why = nil, rest end
        NS.PaseDeLista(pts, why)
    elseif cmd == "sonido" then
        -- Lo puede usar cualquiera
        if rest == "todos" then NS.TestAllSounds()
        elseif NS.Sounds[rest] then NS.PlaySound(rest, true)
        else Print("Uso: /asado sonido <clave> | todos.  Claves: muerte, muerte_guild, wipe, kill, epico, nivel, nivel_guild, primero, puntos, ruleta_win") end
    elseif cmd == "sync" then
        if IsInGuild() then NS.SyncNow(true); Print("Sincronizando con la guild...") end
    elseif cmd == "ubicacion" or cmd == "ubicación" then
        local v = rest:lower()
        if v == "on" or v == "si" or v == "sí" then NS.SetLocationSharing(true)
        elseif v == "off" or v == "no" then NS.SetLocationSharing(false)
        else Print("Compartir ubicación: " .. (NS.db.location.share and "ACTIVADO" or "apagado") .. ". Uso: /asado ubicacion on | off") end
    elseif cmd == "cerca" then
        if rest == "reset" and NS.ResetNearPosition then NS.ResetNearPosition()
        elseif UI and UI.frame then UI.Toggle(1) end
    elseif cmd == "muertes" then
        if UI and UI.frame then UI.Toggle(6) end
    elseif cmd == "pvp" then
        if UI and UI.frame then UI.Toggle(5) end
    elseif cmd == "dragon" or cmd == "dragón" then
        if UI and UI.DragonCommand then UI.DragonCommand(rest) end
    elseif cmd == "niveles" then
        if UI and UI.frame then UI.Toggle(4) end
    elseif cmd == "test" then
        if not RequireOfficer("usar los comandos de prueba") then return end
        local what, a, b = rest:match("^(%S+)%s*(%S*)%s*(%S*)$")
        local function TestName(n)
            n = (n and n ~= "") and n or "Pepito"
            NS.db.testNames[n] = true
            return n
        end
        if what == "nivel" then
            -- /asado test nivel [nivel] [nombre]   (simula que un compañero sube de nivel)
            NS.RecordLevel(TestName(b), tonumber(a) or 30, GetServerTime(), true)
        elseif what == "muerte" then
            -- /asado test muerte [nombre] [pvp]
            local isPvp = (b == "pvp")
            msgHandlers["DEAD"](TestName(a), "GUILD", NS.MonthKey(), isPvp and 0 or math.random(1, 5),
                isPvp and "Cuenca de Arathi" or "Bosque de Elwynn", isPvp and "" or "Valle de Piedranorte",
                12, "MAGE", isPvp and "" or "45,32", isPvp and "1" or "0", NS.db.resets.muertes)
        elseif what == "ubicacion" then
            NS.TestLocations()
        elseif what == "pvp" then
            -- /asado test pvp [total] [nombre]   (usá un total mayor cada vez: 1, 10, 25...)
            NS.SetKills(TestName(b), NS.MonthKey(), tonumber(a) or 10, true)
        elseif what == "limpiar" then
            NS.CleanTestData()
        else
            Print("Uso: /asado test nivel [nivel] [nombre] | muerte [nombre] [pvp] | pvp [total] [nombre] | limpiar")
        end
    elseif cmd == "reset" then
        if not RequireOfficer("reiniciar contadores") then return end
        local cat, confirm = rest:match("^(%S*)%s*(%S*)$")
        NS.DoReset(cat, confirm == "confirmar")
    elseif cmd == "diag" then
        Diag()
    elseif cmd == "perf" then
        Perf()
    elseif cmd == "debug" then
        NS.db.debug = not NS.db.debug
        Print("Debug:", NS.db.debug and "ON" or "OFF")
    else
        local extra = NS.commands[cmd]
        if extra then extra(rest) else Help() end
    end
end
