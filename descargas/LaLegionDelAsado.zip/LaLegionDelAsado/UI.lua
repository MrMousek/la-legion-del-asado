--[[
    La Legión del Asado - UI.lua
    Interfaz: panel "La Parrilla" (4 pestañas), botón de minimapa,
    avisos (toasts) y popup animado de la ruleta.

    Todo se construye por código (sin XML) para tener un solo lugar donde tocar.
]]
local ADDON, NS = ...
local C = NS.C

local UI = {}
NS.UI = UI

local ORANGE = { 1, 0.48, 0.10 }
local GOLD   = { 1, 0.82, 0 }

local BACKDROP = {
    bgFile   = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 },
}

----------------------------------------------------------------
-- Helpers de construcción
----------------------------------------------------------------
local function NewBackdropFrame(name, parent)
    return CreateFrame("Frame", name, parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
end

local function StyleFrame(f)
    f:SetBackdrop(BACKDROP)
    f:SetBackdropColor(0.16, 0.08, 0.04, 0.96)   -- marrón "madera"
    f:SetBackdropBorderColor(ORANGE[1], ORANGE[2], ORANGE[3], 1)   -- borde "brasa"
end

local function MakeLabel(parent, text, font, x, y)
    local fs = parent:CreateFontString(nil, "ARTWORK", font or "GameFontNormal")
    fs:SetPoint("TOPLEFT", x, y)
    fs:SetJustifyH("LEFT")
    fs:SetText(text)
    return fs
end

local function MakeEdit(parent, width, x, y, maxLetters)
    local eb = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    eb:SetSize(width, 20)
    eb:SetPoint("TOPLEFT", x + 6, y)
    eb:SetAutoFocus(false)
    eb:SetMaxLetters(maxLetters or 60)
    eb:SetScript("OnEscapePressed", eb.ClearFocus)
    eb:SetScript("OnEnterPressed", eb.ClearFocus)
    return eb
end

local function MakeButton(parent, text, width, x, y, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width, 24)
    b:SetPoint("TOPLEFT", x, y)
    b:SetText(text)
    b:SetScript("OnClick", onClick)
    return b
end

local function MakeCheck(parent, label, getter, setter, x, y)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", x, y)
    local fs = cb:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    fs:SetPoint("LEFT", cb, "RIGHT", 4, 1)
    fs:SetText(label)
    cb:SetScript("OnClick", function(self) setter(self:GetChecked() and true or false) end)
    cb.Refresh = function() cb:SetChecked(getter()) end
    return cb
end

----------------------------------------------------------------
-- Toasts (avisos que aparecen arriba)
----------------------------------------------------------------
local toastQueue, toastShowing = {}, false

local TOAST_STYLES = {
    default = { icon = C.LOGO, border = ORANGE },
    muerte  = { icon = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_8", border = { 0.85, 0.15, 0.10 } },
    nivel   = { icon = C.LOGO, border = GOLD },
    puntos  = { icon = C.LOGO, border = { 0.30, 0.85, 0.30 } },
    pvp     = { icon = C.LOGO, border = { 0.70, 0.30, 0.90 } },
    himno   = { icon = C.FLAG, border = C.CELESTE, w = 58, h = 29 },
    sos     = { icon = C.LOGO, border = { 0.95, 0.15, 0.10 } },   -- pedido de ayuda
    reunion = { icon = C.LOGO, border = C.SOL },                  -- zona de reunión   -- la bandera no es cuadrada
}

local function NextToast()
    local item = table.remove(toastQueue, 1)
    if not item then
        toastShowing = false
        UI.toast:Hide()
        return
    end
    toastShowing = true
    local st = TOAST_STYLES[item.kind] or TOAST_STYLES.default
    UI.toast.icon:SetTexture(st.icon)
    UI.toast.icon:SetSize(st.w or 46, st.h or 46)
    UI.toast:SetBackdropBorderColor(st.border[1], st.border[2], st.border[3], 1)
    UI.toast.text:SetText(item.text)
    UI.toast:Show()
    C_Timer.After(item.dur or 4, NextToast)
end

function UI.Toast(text, dur, kind)
    if not UI.toast or not NS.db.toasts.enabled then return end
    toastQueue[#toastQueue + 1] = { text = text, dur = dur, kind = kind }
    while #toastQueue > 5 do table.remove(toastQueue, 1) end
    if not toastShowing then NextToast() end
end
NS.Toast = UI.Toast

local function BuildToast()
    local t = NewBackdropFrame("LegionAsadoToast", UIParent)
    t:SetSize(400, 66)
    t:SetPoint("TOP", UIParent, "TOP", 0, -130)
    t:SetFrameStrata("DIALOG")
    StyleFrame(t)
    t:Hide()

    t.icon = t:CreateTexture(nil, "ARTWORK")
    t.icon:SetSize(46, 46)
    t.icon:SetPoint("LEFT", 10, 0)
    t.icon:SetTexture(C.LOGO)

    t.text = t:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    t.text:SetPoint("LEFT", t.icon, "RIGHT", 10, 0)
    t.text:SetPoint("RIGHT", t, "RIGHT", -10, 0)
    t.text:SetJustifyH("LEFT")

    UI.toast = t
end

----------------------------------------------------------------
-- Botón de minimapa (propio, sin librerías)
----------------------------------------------------------------
local function BuildMinimapButton()
    local btn = CreateFrame("Button", "LegionAsadoMinimapButton", Minimap)
    btn:SetSize(31, 31)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(8)
    btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    btn:RegisterForDrag("LeftButton")
    btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local icon = btn:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(22, 22)
    icon:SetPoint("TOPLEFT", 6, -5)
    icon:SetTexture(C.LOGO)
    icon:SetTexCoord(0, 1, 0, 1)

    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

    local function UpdatePosition()
        local angle = math.rad(NS.db.minimap.angle or 200)
        local radius = (Minimap:GetWidth() / 2) + 5
        btn:ClearAllPoints()
        btn:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
    end

    btn:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local px, py = GetCursorPosition()
            local s = Minimap:GetEffectiveScale()
            NS.db.minimap.angle = math.deg(math.atan2(py / s - my, px / s - mx)) % 360
            UpdatePosition()
        end)
    end)
    btn:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)

    btn:SetScript("OnClick", function(_, button)
        if button == "RightButton" then UI.Toggle(3) else UI.Toggle() end
    end)

    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine(C.GUILD_NAME, ORANGE[1], ORANGE[2], ORANGE[3])
        GameTooltip:AddLine("Click: abrir la Parrilla", 1, 1, 1)
        GameTooltip:AddLine("Click derecho: Ruleta del Fernet", 1, 1, 1)
        GameTooltip:AddLine("Arrastrar: mover el botón", 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)

    UpdatePosition()
    btn:SetShown(not NS.db.minimap.hide)
    UI.minimapButton = btn
end

----------------------------------------------------------------
-- Pestaña 1: La Parrilla (links, mensaje del día, tu rango)
----------------------------------------------------------------
local function MakeLinkRow(parent, label, url, y)
    MakeLabel(parent, label, "GameFontNormal", 0, y)
    local eb = MakeEdit(parent, 320, 70, y + 4, 200)
    eb:SetText(url)
    eb:SetCursorPosition(0)
    eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    eb:SetScript("OnTextChanged", function(self, user)
        if user then self:SetText(url); self:HighlightText() end
    end)
end

local function BuildParrilla(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints()

    local logo = p:CreateTexture(nil, "ARTWORK")
    logo:SetSize(100, 100)
    logo:SetPoint("TOPRIGHT", p, "TOPRIGHT", 0, 0)
    logo:SetTexture(C.LOGO)

    local welcome = MakeLabel(p, "¡Bienvenido a la Parrilla!", "GameFontNormalLarge", 0, -4)
    local flag = p:CreateTexture(nil, "ARTWORK")
    flag:SetSize(28, 14)
    flag:SetPoint("LEFT", welcome, "RIGHT", 8, 0)
    flag:SetTexture(C.FLAG)
    MakeLabel(p, "Mensaje del día de la guild:", "GameFontNormal", 0, -34)

    p.motd = p:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    p.motd:SetPoint("TOPLEFT", 0, -54)
    p.motd:SetSize(300, 44)
    p.motd:SetJustifyH("LEFT")
    p.motd:SetJustifyV("TOP")

    MakeLinkRow(p, "Web", C.WEB_URL, -110)
    MakeLinkRow(p, "Discord", C.DISCORD_URL, -144)
    MakeLabel(p, "Click en el cuadro, Ctrl+C y pegalo en el navegador.", "GameFontHighlightSmall", 0, -172)

    p.rank = p:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    p.rank:SetPoint("TOPLEFT", 0, -204)
    p.rank:SetSize(410, 40)
    p.rank:SetJustifyH("LEFT")
    p.rank:SetJustifyV("TOP")

    -- Compañeros cerca (ubicación compartida por los que la activaron)
    p.nearLabel = MakeLabel(p, "Compañeros cerca", "GameFontNormal", 0, -252)
    p.near = {}
    for i = 1, 5 do
        local fs = p:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        fs:SetPoint("TOPLEFT", 0, -272 - (i - 1) * 16)
        fs:SetSize(470, 16)
        fs:SetJustifyH("LEFT")
        fs:SetWordWrap(false)
        p.near[i] = fs
    end
    p.shareCheck = MakeCheck(p, "Compartir mi ubicación",
        function() return NS.db.location.share end,
        function(v) NS.SetLocationSharing(v) end, -4, -352)
    p.nearCheck = MakeCheck(p, "Avisar si hay alguien cerca",
        function() return NS.db.location.near end,
        function(v) NS.db.location.near = v end, -4, -376)
    p.indicatorCheck = MakeCheck(p, "Indicador de cercanía",
        function() return NS.db.location.indicator end,
        function(v) NS.db.location.indicator = v; NS.Fire("LOCATIONS_UPDATED") end, 236, -352)
    p.mapCheck = MakeCheck(p, "Marcas en el mapa del mundo (beta)",
        function() return NS.db.location.map end,
        function(v) NS.db.location.map = v; NS.Fire("LOCATIONS_UPDATED") end, 236, -376)
    MakeLabel(p, "Tu ubicación solo la ven los de tu guild. No se guarda ni se envía dentro de instancias.", "GameFontHighlightSmall", 4, -402)

    local foot = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    foot:SetPoint("BOTTOMRIGHT", 0, 0)
    foot:SetText("|cff888888v" .. NS.version .. "  ·  " .. C.WEB_URL:gsub("^https?://", ""):gsub("/$", "") .. "|r")

    function p.Refresh()
        local motd = GetGuildRosterMOTD and GetGuildRosterMOTD() or ""
        if motd == "" then motd = "(Sin mensaje. Pedile al GM que lo ponga: ¡la guild no se maneja sola!)" end
        p.motd:SetText(motd)

        local all = NS.ComputeTotals()
        local pts = all[NS.me] or 0
        local rank, nextRank, missing = NS.GetRank(pts)
        local txt = string.format("Tu rango: |cffffd100%s|r  (%d puntos)", rank, pts)
        if nextRank then
            txt = txt .. string.format("\nTe faltan %d para ser |cffffd100%s|r.", missing, nextRank)
        else
            txt = txt .. "\n¡Llegaste a lo más alto del quincho!"
        end
        p.rank:SetText(txt)

        -- Compañeros cerca
        local same, other = NS.GetNearbyList()
        for i = 1, 5 do p.near[i]:SetText("") end
        local n = 0
        local function Row(text)
            n = n + 1
            if p.near[n] then p.near[n]:SetText(text) end
        end
        for _, e in ipairs(same) do
            Row(string.format("%s  %s", NS.ClassColored(e.name, e.class),
                e.dist and string.format("|cffffd100%d yd al %s|r", math.floor(e.dist + 0.5), e.dir) or "|cffffd100en tu zona|r"))
        end
        for _, e in ipairs(other) do
            local info = C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(e.mapID)
            Row(string.format("%s  |cff888888en %s|r", NS.ClassColored(e.name, e.class), info and info.name or "otra zona"))
        end
        local total = #same + #other
        p.nearLabel:SetText(total > 0 and string.format("Compañeros cerca (%d)", total) or "Compañeros cerca")
        if total == 0 then
            p.near[1]:SetText(NS.db.location.share
                and "|cff888888Nadie más está compartiendo su ubicación.|r"
                or "|cff888888Nadie comparte su ubicación. Activá la tuya para animar a los demás.|r")
        end
        p.shareCheck.Refresh()
        p.nearCheck.Refresh()
        p.indicatorCheck.Refresh()
        p.mapCheck.Refresh()
    end

    -- Mientras la pestaña está a la vista, se actualiza sola cada 5 s (las posiciones vencen)
    p:SetScript("OnShow", function()
        if p.ticker then return end
        p.ticker = C_Timer.NewTicker(5, function(t)
            if p:IsVisible() then p.Refresh() else t:Cancel(); p.ticker = nil end
        end)
    end)
    p:SetScript("OnHide", function()
        if p.ticker then p.ticker:Cancel(); p.ticker = nil end
    end)
    return p
end

----------------------------------------------------------------
-- Pestaña 2: Ranking (Asador del Mes / Pollo del Mes / panel de oficiales)
----------------------------------------------------------------
local function BuildRanking(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints()

    local function Column(x, title)
        MakeLabel(p, title, "GameFontNormalLarge", x, -4)
        local rows = {}
        for i = 1, 8 do
            local fs = p:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
            fs:SetPoint("TOPLEFT", x, -30 - (i - 1) * 17)
            fs:SetSize(195, 16)
            fs:SetJustifyH("LEFT")
            rows[i] = fs
        end
        return rows
    end
    p.asador = Column(0, "El Asador del Mes")
    p.pollo  = Column(215, "El Pollo del Mes")

    -- Panel de oficiales
    local off = CreateFrame("Frame", nil, p)
    off:SetPoint("TOPLEFT", 0, -176)
    off:SetSize(410, 110)
    MakeLabel(off, "Panel de oficiales: dar puntos", "GameFontNormal", 0, 0)
    MakeLabel(off, "Nombre", "GameFontHighlightSmall", 4, -20)
    MakeLabel(off, "Pts", "GameFontHighlightSmall", 128, -20)
    MakeLabel(off, "Motivo", "GameFontHighlightSmall", 176, -20)
    local nameEB   = MakeEdit(off, 110, 0, -32, 30)
    local deltaEB  = MakeEdit(off, 40, 124, -32, 4)
    local reasonEB = MakeEdit(off, 140, 172, -32, 60)
    MakeButton(off, "Dar puntos", 90, 326, -30, function()
        NS.Award(nameEB:GetText(), deltaEB:GetText(), reasonEB:GetText())
        nameEB:SetText(""); deltaEB:SetText(""); reasonEB:SetText("")
    end)

    MakeLabel(off, "Pase de lista (suma a todos los de la guild en tu grupo):", "GameFontNormal", 0, -64)
    local eventEB = MakeEdit(off, 200, 0, -80, 40)
    local ptsEB   = MakeEdit(off, 40, 214, -80, 2)
    ptsEB:SetText("5")
    MakeButton(off, "Pasar lista", 100, 262, -78, function()
        NS.PaseDeLista(ptsEB:GetText(), eventEB:GetText())
    end)
    MakeLabel(off, "Evento", "GameFontHighlightSmall", 4, -104)
    p.officer = off

    function p.Refresh()
        local _, month = NS.ComputeTotals()
        local top = NS.TopN(month, 8)
        for i = 1, 8 do
            local e = top[i]
            p.asador[i]:SetText(e and string.format("%d. %s  |cffffd100%d pts|r", i, e.name, e.v) or "")
        end
        local pollos = NS.TopN(NS.db.deaths[NS.MonthKey()] or {}, 8)
        for i = 1, 8 do
            local e = pollos[i]
            p.pollo[i]:SetText(e and string.format("%d. %s  |cffff6644%d muertes|r", i, e.name, e.v) or "")
        end
        if #top == 0 then p.asador[1]:SetText("|cff888888Todavía nadie. ¡A laburar!|r") end
        if #pollos == 0 then p.pollo[1]:SetText("|cff888888Todos vivitos y coleando.|r") end
        off:SetShown(NS.IsOfficer(NS.me))
    end
    return p
end

----------------------------------------------------------------
-- Pestaña 3: Ruleta del Fernet (controles)
----------------------------------------------------------------
local function ParseNames(text)
    local names, seen = {}, {}
    for n in string.gmatch(text or "", "[^,]+") do
        n = n:match("^%s*(.-)%s*$")
        if n ~= "" and not seen[n] then
            seen[n] = true
            names[#names + 1] = n
        end
    end
    return names
end

local function BuildRuleta(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints()

    MakeLabel(p, "La Ruleta del Fernet", "GameFontNormalLarge", 0, -4)
    MakeLabel(p, "¿Qué se reparte?", "GameFontNormal", 0, -34)
    local titleEB = MakeEdit(p, 200, 0, -52, 30)
    titleEB:SetText(NS.db.ruleta.title or "Fernet")

    MakeLabel(p, "Participantes (separados por coma):", "GameFontNormal", 0, -84)
    local namesEB = MakeEdit(p, 400, 0, -102, 250)
    namesEB:SetText(NS.db.ruleta.names or "")
    namesEB:SetCursorPosition(0)

    MakeButton(p, "Cargar grupo/raid", 140, 0, -136, function()
        namesEB:SetText(table.concat(NS.GetGroupNames(), ", "))
        namesEB:SetCursorPosition(0)
    end)

    MakeButton(p, "¡A GIRAR!", 140, 150, -136, function()
        NS.db.ruleta.title = titleEB:GetText()
        NS.db.ruleta.names = namesEB:GetText()
        local names = ParseNames(namesEB:GetText())
        if #names == 0 then names = NS.GetGroupNames() end
        NS.StartRuleta(names, titleEB:GetText())
    end)

    local hint = MakeLabel(p, "Si dejás los participantes vacíos, usa el grupo o raid actual.\n" ..
        "Todos los de tu grupo que tengan el addon ven la ruleta girar.",
        "GameFontHighlightSmall", 0, -176)
    hint:SetWidth(410)

    function p.Refresh() end
    return p
end

----------------------------------------------------------------
-- Pestaña 4: Niveles (La Carrera + Los Primeros de la guild)
----------------------------------------------------------------
local function BuildLevels(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints()

    local function Column(x, title, count)
        MakeLabel(p, title, "GameFontNormalLarge", x, -4)
        local rows = {}
        for i = 1, count do
            local fs = p:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
            fs:SetPoint("TOPLEFT", x, -30 - (i - 1) * 17)
            fs:SetSize(195, 16)
            fs:SetJustifyH("LEFT")
            rows[i] = fs
        end
        return rows
    end
    p.carrera = Column(0, "La Carrera", 10)
    p.primeros = Column(215, "Los Primeros", #C.LEVEL_MILESTONES)

    p.note = MakeLabel(p, "", "GameFontHighlightSmall", 0, -212)
    p.note:SetWidth(410)

    function p.Refresh()
        local top = NS.LevelRanking(10)
        for i = 1, 10 do
            local e = top[i]
            p.carrera[i]:SetText(e and string.format("%d. %s  |cffffd100Nv %d|r", i, e.name, e.l) or "")
        end
        if #top == 0 then p.carrera[1]:SetText("|cff888888Sin datos todavía (¿estás en una guild?).|r") end

        for i, lvl in ipairs(C.LEVEL_MILESTONES) do
            local f = NS.db.firsts[lvl]
            p.primeros[i]:SetText(string.format("Nv %d: %s", lvl,
                f and ("|cffffd100" .. f.name .. "|r") or "|cff888888—|r"))
        end
        p.note:SetText("La carrera usa el nivel real de la guild. Los \"Primeros\" se anotan cuando un\n" ..
            "compañero con el addon sube de nivel.")
    end
    return p
end

----------------------------------------------------------------
-- Pestaña 5: PvP (El Carnicero del Mes)
----------------------------------------------------------------
local function BuildPvP(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints()

    MakeLabel(p, "El Carnicero del Mes", "GameFontNormalLarge", 0, -4)
    p.rows = {}
    for i = 1, 8 do
        local fs = p:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        fs:SetPoint("TOPLEFT", 0, -30 - (i - 1) * 17)
        fs:SetSize(195, 16)
        fs:SetJustifyH("LEFT")
        p.rows[i] = fs
    end

    MakeLabel(p, "Resumen del mes", "GameFontNormalLarge", 215, -4)
    p.sum = p:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    p.sum:SetPoint("TOPLEFT", 215, -30)
    p.sum:SetSize(195, 90)
    p.sum:SetJustifyH("LEFT")
    p.sum:SetJustifyV("TOP")

    p.note = MakeLabel(p, "", "GameFontHighlightSmall", 0, -180)
    p.note:SetWidth(410)

    -- Pedir ayuda a la Legión (servidores JcJ: ganks, refuerzos, juntadas en mundo abierto)
    MakeLabel(p, "Pedir ayuda a la Legión", "GameFontNormalLarge", 0, -216)
    MakeLabel(p, "Mensaje (opcional)", "GameFontHighlightSmall", 4, -244)
    local msgEB = MakeEdit(p, 340, 0, -256, C.ALERT_MSG_MAX)
    MakeButton(p, "¡SOS! Pedir ayuda", 160, 0, -286, function() NS.SendAlert("sos", msgEB:GetText()) end)
    MakeButton(p, "Zona de reunión", 160, 170, -286, function() NS.SendAlert("reunion", msgEB:GetText()) end)
    p.alertsCheck = MakeCheck(p, "Recibir alertas de ayuda y reunión",
        function() return NS.db.pvpAlerts.enabled end,
        function(v) NS.db.pvpAlerts.enabled = v; NS.Fire("ALERTS_UPDATED") end, -4, -320)
    p.alertSoundCheck = MakeCheck(p, "Sonido de las alertas",
        function() return NS.db.pvpAlerts.sound end,
        function(v) NS.db.pvpAlerts.sound = v end, 280, -320)
    p.lastAlert = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    p.lastAlert:SetPoint("TOPLEFT", 4, -354)
    p.lastAlert:SetSize(370, 14)
    p.lastAlert:SetJustifyH("LEFT")
    p.lastAlert:SetWordWrap(false)
    p.goBtn = MakeButton(p, "Marcar en el mapa", 130, 380, -348, function() NS.GoToAlert() end)

    function p.Refresh()
        local t = NS.db.pvp[NS.MonthKey()] or {}
        local top = NS.TopN(t, 8)
        for i = 1, 8 do
            local e = top[i]
            p.rows[i]:SetText(e and string.format("%d. %s  |cffb34de6%d bajas|r", i, e.name, e.v) or "")
        end
        if #top == 0 then p.rows[1]:SetText("|cff888888Sin bajas todavía este mes.|r") end

        local total, mine, pos = 0, t[NS.me] or 0, nil
        for _, v in pairs(t) do total = total + v end
        for i, e in ipairs(NS.TopN(t, 1000)) do
            if e.name == NS.me then pos = i; break end
        end
        p.sum:SetText(string.format("Bajas de la guild: |cffffd100%d|r\nTus bajas: |cffffd100%d|r\nTu puesto: |cffffd100%s|r",
            total, mine, pos and ("#" .. pos) or "-"))

        if NS.PvPSupported() then
            p.note:SetText("Cuentan las bajas honorables, sin importar la facción.\n" ..
                "Las muertes en campos de batalla y arenas no suman al Pollo del Mes.")
        else
            p.note:SetText("|cffff6644Este cliente no informa bajas honorables: el ranking PvP no va a registrar datos.|r")
        end

        -- Alertas de ayuda / reunión
        p.alertsCheck.Refresh()
        p.alertSoundCheck.Refresh()
        local a = NS.ActiveAlerts()[1]
        if a then
            local mins = math.floor((GetTime() - a.t) / 60)
            p.lastAlert:SetText(string.format("Última alerta: %s de %s en %s (hace %s)",
                a.kind == "sos" and "|cffff4040SOS|r" or "|cff74acdfreunión|r",
                NS.ClassColored(a.name, a.class), NS.WhereText(a.zone, a.sub, nil),
                mins <= 0 and "instantes" or (mins .. " min")))
            p.goBtn:Show()
        else
            p.lastAlert:SetText("|cff888888Sin alertas activas.|r")
            p.goBtn:Hide()
        end
    end
    return p
end

----------------------------------------------------------------
-- Pestaña 6: Muertes (historial de la guild)
----------------------------------------------------------------
local function BuildDeaths(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints()
    local ROWS = 16
    p.offset = 0

    MakeLabel(p, "Muertes de la guild", "GameFontNormalLarge", 0, -4)
    p.count = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    p.count:SetPoint("TOPRIGHT", p, "TOPRIGHT", 0, -10)
    p.count:SetJustifyH("RIGHT")

    p.rows = {}
    for i = 1, ROWS do
        local fs = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
        fs:SetPoint("TOPLEFT", 0, -32 - (i - 1) * 18)
        fs:SetSize(470, 16)
        fs:SetJustifyH("LEFT")
        fs:SetWordWrap(false)
        p.rows[i] = fs
    end

    p.newer = MakeButton(p, "Más nuevas", 90, 0, -330, function()
        p.offset = math.max(0, p.offset - ROWS)
        p.Refresh()
    end)
    p.older = MakeButton(p, "Más viejas", 90, 96, -330, function()
        p.offset = p.offset + ROWS
        p.Refresh()
    end)
    p.page = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    p.page:SetPoint("TOPLEFT", 200, -336)

    MakeLabel(p, "Rueda del mouse para desplazarte. Se guardan las últimas 300 muertes.", "GameFontHighlightSmall", 0, -360)

    p:EnableMouseWheel(true)
    p:SetScript("OnMouseWheel", function(_, delta)
        p.offset = math.max(0, p.offset - delta * 3)
        p.Refresh()
    end)

    local skull = "|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8:12|t"

    function p.Refresh()
        local log = NS.db.deathLog
        local total = #log
        p.offset = math.max(0, math.min(p.offset, math.max(0, total - ROWS)))

        local mk, month = NS.MonthKey(), 0
        for _, e in ipairs(log) do
            if date("%Y-%m", e.ts) == mk then month = month + 1 end
        end
        p.count:SetText(string.format("Total: |cffffd100%d|r  ·  Este mes: |cffffd100%d|r", total, month))

        for i = 1, ROWS do
            local e = log[total - p.offset - (i - 1)]
            if e then
                local lvl = e.lvl and (" nv " .. e.lvl) or ""
                local tag = e.pvp and "  |cffb34de6[PvP]|r" or ""
                p.rows[i]:SetText(string.format("%s |cff888888%s|r  %s%s  -  %s%s", skull,
                    date("%d/%m %H:%M", e.ts), NS.ClassColored(e.name, e.class), lvl,
                    NS.WhereText(e.zone, e.sub, e.coords), tag))
            else
                p.rows[i]:SetText("")
            end
        end
        if total == 0 then p.rows[1]:SetText("|cff888888Todavía no se murió nadie. ¡Raro!|r") end

        local pages = math.max(1, math.ceil(total / ROWS))
        p.page:SetText(string.format("%d / %d", math.floor(p.offset / ROWS) + 1, pages))
        p.newer:SetEnabled(p.offset > 0)
        p.older:SetEnabled(p.offset + ROWS < total)
    end
    return p
end

----------------------------------------------------------------
-- Pestaña 7: Addon (quién lo tiene y con qué versión)
----------------------------------------------------------------
local function BuildMembers(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints()
    local ROWS = 13
    p.offset, p.filter, p.onlineOnly = 0, "all", true
    local TEX_ON = "Interface\\FriendsFrame\\StatusIcon-Online"
    local TEX_OFF = "Interface\\FriendsFrame\\StatusIcon-Offline"

    MakeLabel(p, "Quién tiene el addon", "GameFontNormalLarge", 0, -4)
    p.summary = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    p.summary:SetPoint("TOPLEFT", 0, -30)
    p.summary:SetWidth(510)
    p.summary:SetJustifyH("LEFT")

    local function Filter(text, key, width, x)
        return MakeButton(p, text, width, x, -48, function() p.filter = key; p.offset = 0; p.Refresh() end)
    end
    p.fAll  = Filter("Todos", "all", 70, 0)
    p.fOld  = Filter("Desactualizados", "old", 120, 74)
    p.fNone = Filter("Sin addon", "none", 90, 198)
    p.onlineCheck = MakeCheck(p, "Solo en línea",
        function() return p.onlineOnly end,
        function(v) p.onlineOnly = v; p.offset = 0; p.Refresh() end, 300, -46)
    MakeButton(p, "Actualizar", 90, 420, -48, function() NS.RequestVersions(); NS.RequestRoster() end)

    p.rows = {}
    for i = 1, ROWS do
        local b = CreateFrame("Button", nil, p)
        b:SetSize(510, 18)
        b:SetPoint("TOPLEFT", 0, -80 - (i - 1) * 19)
        local hl = b:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetTexture("Interface\\Buttons\\WHITE8X8")
        hl:SetVertexColor(C.CELESTE[1], C.CELESTE[2], C.CELESTE[3], 0.18)

        b.dot = b:CreateTexture(nil, "ARTWORK")
        b.dot:SetSize(12, 12)
        b.dot:SetPoint("LEFT", 2, 0)
        local function Col(x, w)
            local fs = b:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
            fs:SetPoint("LEFT", x, 0)
            fs:SetSize(w, 16)
            fs:SetJustifyH("LEFT")
            fs:SetWordWrap(false)
            return fs
        end
        b.name, b.ver, b.state = Col(20, 170), Col(196, 150), Col(352, 150)

        b:SetScript("OnClick", function(self) if self.row then NS.SuggestWhisper(self.row) end end)
        b:SetScript("OnEnter", function(self)
            local r = self.row
            if not r then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(NS.ClassColored(r.name, r.class))
            if r.seen and not r.online then
                GameTooltip:AddLine("Visto con el addon: " .. date("%d/%m %H:%M", r.seen), 0.7, 0.7, 0.7)
            end
            if r.name ~= NS.me then
                GameTooltip:AddLine("Click: abrir un susurro con un mensaje sugerido", C.CELESTE[1], C.CELESTE[2], C.CELESTE[3])
            end
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        p.rows[i] = b
    end

    p.empty = p:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    p.empty:SetPoint("TOPLEFT", 4, -84)

    p.newer = MakeButton(p, "Anteriores", 90, 0, -336, function() p.offset = math.max(0, p.offset - ROWS); p.Refresh() end)
    p.older = MakeButton(p, "Siguientes", 90, 96, -336, function() p.offset = p.offset + ROWS; p.Refresh() end)
    p.page = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    p.page:SetPoint("TOPLEFT", 200, -342)
    MakeLabel(p, "Click en un nombre: se abre un susurro con un mensaje sugerido (vos decidís si lo mandás).",
        "GameFontHighlightSmall", 0, -366)

    p:EnableMouseWheel(true)
    p:SetScript("OnMouseWheel", function(_, delta) p.offset = math.max(0, p.offset - delta * 3); p.Refresh() end)
    p:SetScript("OnShow", function() NS.RequestVersions(); NS.RequestRoster() end)

    local STATE = {
        ok   = "|cff33ff33al día|r",
        old  = "|cffff6644desactualizada|r",
        none = "|cff888888sin addon|r",
    }

    function p.Refresh()
        p.fAll:SetEnabled(p.filter ~= "all")
        p.fOld:SetEnabled(p.filter ~= "old")
        p.fNone:SetEnabled(p.filter ~= "none")
        p.onlineCheck.Refresh()

        for i = 1, ROWS do p.rows[i].row = nil; p.rows[i]:Hide() end
        p.empty:SetText("")
        if not IsInGuild() then
            p.summary:SetText("")
            p.empty:SetText("|cff888888No estás en una guild.|r")
            p.page:SetText("")
            return
        end
        if not NS.rosterReady then
            p.summary:SetText("")
            p.empty:SetText("|cff888888Cargando la lista de la guild...|r")
            NS.RequestRoster()
            return
        end

        local rows, stats, latest = NS.GetMemberList(p.filter, p.onlineOnly)
        p.summary:SetText(string.format(
            "Con addon: |cffffd100%d|r  ·  Desactualizados: |cffff6644%d|r  ·  Sin addon: |cff888888%d|r (%d en línea)  ·  Última versión vista: |cffffd100%s|r",
            stats.addon, stats.old, stats.none, stats.noneOnline, latest))

        local total = #rows
        p.offset = math.max(0, math.min(p.offset, math.max(0, total - ROWS)))
        for i = 1, ROWS do
            local r = rows[p.offset + i]
            local b = p.rows[i]
            if r then
                b.row = r
                b.dot:SetTexture(r.online and TEX_ON or TEX_OFF)
                b.name:SetText(NS.ClassColored(r.name, r.class))
                local flavor = r.ver and NS.FlavorOf(r.toc)
                b.ver:SetText(r.ver and (r.ver .. (flavor and ("  ·  " .. flavor) or "")) or "")
                b.state:SetText(STATE[r.status])
                b:Show()
            end
        end
        if total == 0 then p.empty:SetText("|cff888888Nadie coincide con el filtro.|r") end

        p.page:SetText(string.format("%d / %d", math.floor(p.offset / ROWS) + 1, math.max(1, math.ceil(total / ROWS))))
        p.newer:SetEnabled(p.offset > 0)
        p.older:SetEnabled(p.offset + ROWS < total)
    end
    return p
end

----------------------------------------------------------------
-- Pestaña 8: Opciones
----------------------------------------------------------------
local function BuildOptions(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints()
    MakeLabel(p, "Opciones", "GameFontNormalLarge", 0, -4)

    local checks = {}
    local function Add(label, getter, setter)
        checks[#checks + 1] = MakeCheck(p, label, getter, setter, -4, -30 - (#checks) * 22)
    end

    Add("Sonidos del Locutor del Barrio",
        function() return NS.db.sounds.enabled end,
        function(v) NS.db.sounds.enabled = v end)
    Add("No molestar: silenciar durante peleas de jefe",
        function() return NS.db.sounds.muteInEncounter end,
        function(v) NS.db.sounds.muteInEncounter = v end)
    Add("Mostrar avisos (toasts) de la guild",
        function() return NS.db.toasts.enabled end,
        function(v) NS.db.toasts.enabled = v end)
    Add("Avisar a la guild cuando me muero",
        function() return NS.db.broadcastDeaths end,
        function(v) NS.db.broadcastDeaths = v end)
    Add("Ver aviso en pantalla cuando muere un compañero",
        function() return NS.db.toasts.deaths end,
        function(v) NS.db.toasts.deaths = v end)
    Add("Ver línea en el chat cuando muere un compañero",
        function() return NS.db.deathChat end,
        function(v) NS.db.deathChat = v end)
    Add("Sonido cuando muere un compañero",
        function() return NS.db.sounds.guildDeaths end,
        function(v) NS.db.sounds.guildDeaths = v end)
    Add("Sonido al comerciar con otro jugador",
        function() return NS.db.sounds.trade end,
        function(v) NS.db.sounds.trade = v end)
    Add("Himno de la guild (cuando lo pone el GM u oficiales)",
        function() return NS.db.himno.enabled end,
        function(v) NS.db.himno.enabled = v end)
    Add("Himno automático a las 00:00 (hora argentina)",
        function() return NS.db.himno.auto end,
        function(v) NS.db.himno.auto = v; if v then NS.db.himno.noAudio = false end end)
    Add("Avisos de niveles importantes de la guild",
        function() return NS.db.toasts.levels end,
        function(v) NS.db.toasts.levels = v end)
    Add("Avisos de PvP de la guild (primera sangre, hitos)",
        function() return NS.db.toasts.pvp end,
        function(v) NS.db.toasts.pvp = v end)
    Add("Sincronizar con la guild al cambiar de zona",
        function() return NS.db.syncOnZone end,
        function(v) NS.db.syncOnZone = v end)
    Add("Mostrar botón en el minimapa",
        function() return not NS.db.minimap.hide end,
        function(v)
            NS.db.minimap.hide = not v
            if UI.minimapButton then UI.minimapButton:SetShown(v) end
        end)

    MakeLabel(p, "Dragón del retrato (señal de que el addon está activo):", "GameFontNormal", 0, -354)
    UI.dragonButton = MakeButton(p, "", 120, 0, -374, function() UI.CycleDragon() end)
    MakeButton(p, "-", 28, 126, -374, function() UI.NudgeDragonScale(-0.1) end)
    MakeButton(p, "+", 28, 158, -374, function() UI.NudgeDragonScale(0.1) end)
    MakeButton(p, "Invertir", 70, 192, -374, function() UI.FlipDragon() end)
    MakeLabel(p, "Ajuste fino: /asado dragon x 5  |  y -3", "GameFontHighlightSmall", 272, -380)

    local info = MakeLabel(p, "Sonidos propios: archivos .ogg en Interface\\AddOns\\LaLegionDelAsado\\Sounds\\ (ver LEEME.txt).\n" ..
        "Probalos con /asado sonido todos.",
        "GameFontHighlightSmall", 0, -414)
    info:SetWidth(470)

    function p.Refresh()
        for _, cb in ipairs(checks) do cb.Refresh() end
        UI.RefreshDragonButton()
    end
    return p
end

----------------------------------------------------------------
-- Ventana principal con pestañas
----------------------------------------------------------------
local TAB_NAMES = { "Parrilla", "Ranking", "Ruleta", "Niveles", "PvP", "Muertes", "Addon", "Opciones" }

local function BuildMain()
    local f = NewBackdropFrame("LegionAsadoFrame", UIParent)
    f:SetSize(560, 540)
    f:SetPoint("CENTER")
    f:SetFrameStrata("HIGH")
    StyleFrame(f)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:Hide()
    table.insert(UISpecialFrames, "LegionAsadoFrame")   -- se cierra con ESC

    local title = f:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("|cffff7a1a" .. C.GUILD_NAME .. "|r")

    -- Detalle sutil: franja celeste y blanca (los colores de la bandera) bajo el título
    for i, col in ipairs({ C.CELESTE, { 1, 1, 1 }, C.CELESTE }) do
        local band = f:CreateTexture(nil, "ARTWORK")
        band:SetColorTexture(col[1], col[2], col[3], 1)
        band:SetSize(110, 2)
        band:SetPoint("TOP", 0, -30 - (i - 1) * 2)
    end

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -2, -2)

    local content = CreateFrame("Frame", nil, f)
    content:SetPoint("TOPLEFT", 24, -78)
    content:SetPoint("BOTTOMRIGHT", -24, 16)

    UI.pages = {
        BuildParrilla(content),
        BuildRanking(content),
        BuildRuleta(content),
        BuildLevels(content),
        BuildPvP(content),
        BuildDeaths(content),
        BuildMembers(content),
        BuildOptions(content),
    }

    UI.tabs = {}
    for i, name in ipairs(TAB_NAMES) do
        UI.tabs[i] = MakeButton(f, name, 62, 22 + (i - 1) * 66, -42, function() UI.ShowTab(i) end)
    end

    f:SetScript("OnShow", function() UI.ShowTab(UI.current or 1) end)
    UI.frame = f
end

function UI.ShowTab(i)
    UI.current = i
    for idx, page in ipairs(UI.pages) do
        page:SetShown(idx == i)
        UI.tabs[idx]:SetEnabled(idx ~= i)
    end
    UI.pages[i].Refresh()
end

function UI.Toggle(tab)
    if not UI.frame then return end
    if tab then
        UI.current = tab
        if UI.frame:IsShown() then UI.ShowTab(tab) else UI.frame:Show() end
    elseif UI.frame:IsShown() then
        UI.frame:Hide()
    else
        UI.frame:Show()
    end
end

-- Varios eventos seguidos (ej: una sincronización) provocan un solo redibujado.
local refreshQueued = false
local function RefreshIfVisible()
    if refreshQueued or not (UI.frame and UI.frame:IsShown() and UI.pages) then return end
    refreshQueued = true
    C_Timer.After(0.25, function()
        refreshQueued = false
        if UI.frame and UI.frame:IsShown() and UI.pages then
            UI.pages[UI.current or 1].Refresh()
        end
    end)
end

----------------------------------------------------------------
-- Popup animado de la ruleta
----------------------------------------------------------------
local function BuildRuletaPopup()
    local pop = NewBackdropFrame("LegionAsadoRuleta", UIParent)
    pop:SetSize(360, 130)
    pop:SetPoint("TOP", UIParent, "TOP", 0, -200)
    pop:SetFrameStrata("DIALOG")
    StyleFrame(pop)
    pop:Hide()

    pop.title = pop:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    pop.title:SetPoint("TOP", 0, -14)

    pop.name = pop:CreateFontString(nil, "ARTWORK")
    pop.name:SetFont(STANDARD_TEXT_FONT, 30, "OUTLINE")
    pop.name:SetPoint("CENTER", 0, -2)

    pop.sub = pop:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    pop.sub:SetPoint("BOTTOM", 0, 12)

    UI.ruletaPopup = pop
end

local function RunRuleta(d)
    local pop = UI.ruletaPopup
    if not pop then return end

    -- Candidatos a mostrar mientras gira (el ganador ya viene decidido en el mensaje)
    local src = d.names
    if not src or #src < 2 then src = NS.GetGroupNames() end
    local pool, found = {}, false
    for _, n in ipairs(src) do
        pool[#pool + 1] = n
        if n == d.winner then found = true end
    end
    if not found then pool[#pool + 1] = d.winner end

    pop.runId = d.id
    pop.title:SetText("Ruleta del Asado: |cffffd100" .. d.title .. "|r")
    pop.sub:SetText("Tirada por " .. d.by)
    pop.name:SetTextColor(1, 1, 1)
    pop:Show()

    local elapsed, acc, duration = 0, 0, 4.5
    pop:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + dt
        acc = acc + dt
        if elapsed >= duration then
            self:SetScript("OnUpdate", nil)
            self.name:SetText(d.winner)
            self.name:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
            NS.PlaySound("ruleta_win")
            NS.Fire("RULETA_DONE", d)
            C_Timer.After(8, function()
                if self.runId == d.id then self:Hide() end
            end)
            return
        end
        -- Cada vez más lento, como una ruleta de verdad
        local interval = 0.05 + 0.40 * (elapsed / duration) ^ 3
        if acc >= interval then
            acc = 0
            self.name:SetText(pool[math.random(#pool)])
            NS.PlaySound("ruleta_tick")
        end
    end)
end

----------------------------------------------------------------
-- Dragón del retrato (dorado = élite, plateado = raro)
-- Usa el arte del propio juego (atlas del marco del objetivo): no se distribuye ningún dibujo de Blizzard.
----------------------------------------------------------------
local DRAGON_LABELS = { gold = "Dorado (élite)", silver = "Plateado (raro)", off = "Sin dragón" }

local dragonAtlasCache = {}
local dragonAtlasMiss = {}   -- estilos que ya se buscaron y no existen (la búsqueda por lista completa es pesada)

-- Si los nombres conocidos no existen, busca en TODOS los atlas del juego uno que parezca el dragón.
local function DiscoverDragonAtlas(style)
    if not (C_Texture and C_Texture.GetAtlasElements) then return nil end
    local ok, list = pcall(C_Texture.GetAtlasElements)
    if not ok or type(list) ~= "table" then return nil end
    local word = (style == "gold") and "Gold" or "Silver"
    local best
    for _, name in ipairs(list) do
        if type(name) == "string"
            and name:find("UnitFrame", 1, true) and name:find("PortraitOn", 1, true)
            and name:find("Boss", 1, true) and name:find(word, 1, true)
            and not name:find("Flash", 1, true) and not name:find("Glow", 1, true)
            and not name:find("2x", 1, true) then
            if not best or #name < #best then best = name end   -- el más corto suele ser la versión base
        end
    end
    return best
end

local function FindDragonAtlas(style)
    local cached = dragonAtlasCache[style]
    if cached then return cached.name, cached.info end
    if dragonAtlasMiss[style] then return nil end
    if not (C_Texture and C_Texture.GetAtlasInfo) then return nil end
    for _, name in ipairs(C.DRAGON_ATLAS[style] or {}) do
        local info = C_Texture.GetAtlasInfo(name)
        if info then
            dragonAtlasCache[style] = { name = name, info = info }
            return name, info
        end
    end
    local found = DiscoverDragonAtlas(style)
    local info = found and C_Texture.GetAtlasInfo(found)
    if info then
        dragonAtlasCache[style] = { name = found, info = info }
        return found, info
    end
    dragonAtlasMiss[style] = true
end

function UI.ApplyDragon()
    local cfg = NS.db and NS.db.dragon
    if not cfg or not PlayerFrame then return end

    if cfg.style == "off" then
        if UI.dragon then UI.dragon:Hide() end
        return
    end

    if not UI.dragon then
        local holder = CreateFrame("Frame", nil, PlayerFrame)
        holder:SetSize(1, 1)
        holder:SetPoint("CENTER", PlayerFrame, "CENTER")
        holder:SetFrameStrata("MEDIUM")
        holder:SetFrameLevel(PlayerFrame:GetFrameLevel() + 50)
        holder.tex = holder:CreateTexture(nil, "OVERLAY", nil, 7)
        UI.dragon = holder
    end

    local name, info = FindDragonAtlas(cfg.style)
    if not info then
        UI.dragon:Hide()
        if not UI.dragonWarned then
            UI.dragonWarned = true
            NS.Print("No encontré el arte del dragón en este cliente. Probá /asado dragon atlas.")
        end
        return
    end

    local tex = UI.dragon.tex
    local file = info.file or info.filename
    local mirrored = not cfg.flip   -- el dragón del jugador va espejado respecto al del objetivo
    if file then
        tex:SetTexture(file)
        local l, r, t, b = info.leftTexCoord, info.rightTexCoord, info.topTexCoord, info.bottomTexCoord
        if mirrored then tex:SetTexCoord(r, l, t, b) else tex:SetTexCoord(l, r, t, b) end
    else
        tex:SetAtlas(name, false)   -- sin espejado, pero se ve
    end

    local portrait = (PlayerFrame.PlayerFrameContainer and PlayerFrame.PlayerFrameContainer.PlayerPortrait)
        or _G.PlayerPortrait or PlayerFrame
    local pw = portrait:GetWidth()
    if not pw or pw < 10 then pw = 58 end
    local scale = (pw / 58) * (cfg.scale or 1)

    tex:SetSize((info.width or 64) * scale, (info.height or 64) * scale)
    tex:ClearAllPoints()
    if mirrored then
        tex:SetPoint("TOPLEFT", portrait, "TOPLEFT", -15 * scale + (cfg.x or 0), 11 * scale + (cfg.y or 0))
    else
        tex:SetPoint("TOPRIGHT", portrait, "TOPRIGHT", 15 * scale + (cfg.x or 0), 11 * scale + (cfg.y or 0))
    end
    UI.dragon:Show()
end

function UI.RefreshDragonButton()
    if UI.dragonButton and NS.db then
        UI.dragonButton:SetText(DRAGON_LABELS[NS.db.dragon.style] or "?")
    end
end

local function DragonChanged()
    wipe(dragonAtlasMiss)
    UI.dragonWarned = false
    UI.ApplyDragon()
    UI.RefreshDragonButton()
end

function UI.CycleDragon()
    local order = { gold = "silver", silver = "off", off = "gold" }
    NS.db.dragon.style = order[NS.db.dragon.style] or "gold"
    DragonChanged()
end

function UI.NudgeDragonScale(delta)
    local cfg = NS.db.dragon
    cfg.scale = math.max(0.5, math.min(2, (cfg.scale or 1) + delta))
    DragonChanged()
end

function UI.FlipDragon()
    NS.db.dragon.flip = not NS.db.dragon.flip
    DragonChanged()
end

function UI.DragonDiag()
    wipe(dragonAtlasMiss)
    if not (C_Texture and C_Texture.GetAtlasInfo) then
        NS.Print("Dragón: este cliente no tiene C_Texture.GetAtlasInfo.")
        return
    end
    for _, style in ipairs({ "gold", "silver" }) do
        for _, name in ipairs(C.DRAGON_ATLAS[style]) do
            local ok = C_Texture.GetAtlasInfo(name) ~= nil
            print((ok and "|cff33ff33OK|r " or "|cffff3333NO|r ") .. style .. ": " .. name)
        end
    end
    for _, style in ipairs({ "gold", "silver" }) do
        local name = FindDragonAtlas(style)
        NS.Print("Dragón " .. style .. " usa: " .. (name or "|cffff3333ninguno|r"))
    end
    -- Si algo falla, muestra qué atlas parecidos existen en este cliente
    if C_Texture.GetAtlasElements and not (FindDragonAtlas("gold") and FindDragonAtlas("silver")) then
        local ok, list = pcall(C_Texture.GetAtlasElements)
        if ok and type(list) == "table" then
            local shown = 0
            for _, name in ipairs(list) do
                if type(name) == "string" and name:find("PortraitOn", 1, true) and name:find("Boss", 1, true) then
                    print("   parecido: " .. name)
                    shown = shown + 1
                    if shown >= 15 then break end
                end
            end
            if shown == 0 then print("   (no hay atlas parecidos)") end
        end
    end
end

function UI.DragonCommand(rest)
    local cfg = NS.db.dragon
    local cmd, arg = (rest or ""):match("^(%S*)%s*(%S*)$")
    cmd = (cmd or ""):lower()

    if cmd == "oro" or cmd == "dorado" or cmd == "gold" then cfg.style = "gold"
    elseif cmd == "plata" or cmd == "plateado" or cmd == "silver" then cfg.style = "silver"
    elseif cmd == "off" or cmd == "no" then cfg.style = "off"
    elseif cmd == "escala" then cfg.scale = math.max(0.5, math.min(2, tonumber(arg) or 1))
    elseif cmd == "x" then cfg.x = tonumber(arg) or 0
    elseif cmd == "y" then cfg.y = tonumber(arg) or 0
    elseif cmd == "invertir" then cfg.flip = not cfg.flip
    elseif cmd == "reset" then cfg.scale, cfg.x, cfg.y, cfg.flip = 1, 0, 0, false
    elseif cmd == "atlas" then UI.DragonDiag(); return
    else
        NS.Print(string.format("Dragón: %s (escala %.1f, x %d, y %d). Uso: /asado dragon oro | plata | off | escala N | x N | y N | invertir | reset | atlas",
            DRAGON_LABELS[cfg.style] or "?", cfg.scale or 1, cfg.x or 0, cfg.y or 0))
        return
    end
    DragonChanged()
end

NS:On("PLAYER_ENTERING_WORLD", function()
    C_Timer.After(1, UI.ApplyDragon)
end)

----------------------------------------------------------------
-- Inicialización (se dispara desde Core en PLAYER_LOGIN)
----------------------------------------------------------------
NS.RegisterCallback("READY", function()
    BuildToast()
    BuildMinimapButton()
    BuildMain()
    BuildRuletaPopup()
    C_Timer.After(1, UI.ApplyDragon)
end)

NS.RegisterCallback("LEDGER_UPDATED", RefreshIfVisible)
NS.RegisterCallback("DEATHS_UPDATED", RefreshIfVisible)
NS.RegisterCallback("LEVELS_UPDATED", RefreshIfVisible)
NS.RegisterCallback("PVP_UPDATED", RefreshIfVisible)
NS.RegisterCallback("DEATHLOG_UPDATED", RefreshIfVisible)
NS.RegisterCallback("LOCATIONS_UPDATED", RefreshIfVisible)
NS.RegisterCallback("ALERTS_UPDATED", RefreshIfVisible)
NS.RegisterCallback("MEMBERS_UPDATED", RefreshIfVisible)
NS.RegisterCallback("ROSTER_UPDATED", RefreshIfVisible)
NS.RegisterCallback("RULETA_START", RunRuleta)
NS:On("GUILD_MOTD", RefreshIfVisible)
