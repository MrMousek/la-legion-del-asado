--[[
    La Legión del Asado - Himno.lua
    El Himno Nacional Argentino, de dos maneras:

      1) A mano:       /asado himno   -> el GM o un oficial lo pone para toda la guild.
      2) Automático:   todos los días a las 00:00 (hora argentina), como las radios.
                       Avisa unos minutos antes y suena en cada PC por su cuenta: no depende de nadie.

    En los dos casos suena por encima de cualquier otro sonido, aparece un botón "Detener himno"
    y también se corta con  /asado himno stop  (solo para uno mismo).

    HORARIO: se calcula con el reloj absoluto del servidor (GetServerTime) pasado a UTC-3, que es la hora de
    Argentina todo el año (no tiene horario de verano). Por eso es igual para todos, sin importar la hora de la
    PC de cada uno ni la del reino (que sí cambia con el horario de verano de EE.UU.).

    El audio NO viene incluido: copiá tu archivo como Sounds\himno.ogg
    (versión abreviada, ~1 a 2 minutos) y ajustá HIMNO_SECONDS en Config.lua.
]]
local ADDON, NS = ...
local C = NS.C
local Print = NS.Print

-- Prioridad 4: más importante que cualquier otro sonido (corta a los demás y no lo pisan)
NS.Sounds.himno = {
    file = "Interface\\AddOns\\" .. ADDON .. "\\Sounds\\himno.ogg",
    len = C.HIMNO_SECONDS, prio = 4,
}

local lastRun = -1000   -- cuándo empezó el último himno (enfriamiento del manual)
local pending           -- id del himno en cuenta regresiva (para poder cortarlo antes de que arranque)
local playingId         -- id del himno que está sonando (para esconder el botón al terminar)

----------------------------------------------------------------
-- Botón "Detener himno" (visible solo mientras suena)
----------------------------------------------------------------
local stopBtn

local function ShowStopButton()
    if not stopBtn then
        stopBtn = CreateFrame("Button", "LegionAsadoHimnoStop", UIParent, "UIPanelButtonTemplate")
        stopBtn:SetSize(130, 24)
        stopBtn:SetPoint("TOP", UIParent, "TOP", 0, -205)
        stopBtn:SetFrameStrata("DIALOG")
        stopBtn:SetText("Detener himno")
        stopBtn:SetScript("OnClick", function() NS.commands.himno("stop") end)
    end
    stopBtn:Show()
end

local function StopHimno()
    pending, playingId = nil, nil
    NS.StopSound("himno")
    if stopBtn then stopBtn:Hide() end
end

----------------------------------------------------------------
-- Reproducción
----------------------------------------------------------------
local function Begin(id)
    if pending ~= id then return end                       -- se cortó durante la cuenta regresiva
    pending = nil
    if NS.inEncounter and NS.db.sounds.muteInEncounter then return end
    local H = NS.db.himno
    if not NS.PlaySound("himno") then
        if not H.noAudio then   -- se avisa una sola vez; después el himno automático queda en pausa, sin molestar
            Print("No encuentro el audio del himno (Sounds\\himno.ogg), así que el himno automático queda en pausa. " ..
                "Bajá el pack de sonidos en " .. C.ADDON_PAGE .. " y probalo con /asado himno probar.")
        end
        H.noAudio = true
        return
    end
    H.noAudio = false
    playingId = id
    ShowStopButton()
    C_Timer.After(C.HIMNO_SECONDS + 1, function()          -- al terminar, el botón se esconde solo
        if playingId == id then
            playingId = nil
            if stopBtn then stopBtn:Hide() end
        end
    end)
end

-- Cuenta regresiva + sonido. Se llama en todos los clientes, incluido el del que lo pone.
-- auto = true: himno de las 00:00 (empieza ya, el aviso fue antes y no depende del permiso "himno del GM")
function NS.RunHimno(id, auto)
    local H = NS.db.himno
    if not NS.db.sounds.enabled then return end
    if auto then
        if not H.auto then return end
    elseif not H.enabled then
        return
    end
    pending = id
    lastRun = GetTime()
    local delay = 0
    if auto then
        NS.Toast(string.format("Son las %02d:00 en Argentina\n¡De pie, Legión!", C.HIMNO_AUTO_HOUR), 7, "himno")
    else
        delay = C.HIMNO_COUNTDOWN
        NS.Toast("¡De pie, Legión!\nHimno Nacional Argentino", C.HIMNO_COUNTDOWN + 3, "himno")
    end
    Print("Himno Nacional Argentino. Con |cffffd100/asado himno stop|r (o el botón) lo cortás, solo para vos.")
    C_Timer.After(delay, function() Begin(id) end)
end

----------------------------------------------------------------
-- A mano (GM y oficiales)
----------------------------------------------------------------
function NS.StartHimno()
    if not NS.RequireOfficer("poner el himno") then return end
    if not IsInGuild() then Print("Necesitás estar en una guild."); return end
    if GetTime() - lastRun < C.HIMNO_COOLDOWN then
        Print("El himno ya sonó hace poco. Esperá unos minutos.")
        return
    end
    local ts = GetServerTime()
    local id = NS.me .. ":" .. ts
    local msg = table.concat({ "HIMNO", id, ts, NS.me }, "^")
    if not NS.Send("GUILD", msg, nil, true) then
        Print("No se pudo avisar a la guild ahora (¿pelea de jefe?). Probá de nuevo en unos segundos.")
        return
    end
    NS.RunHimno(id)
end

-- Llega el aviso de un compañero: solo se acepta si lo mandó, en vivo, el GM o un oficial
NS.Handle("HIMNO", function(sender, channel, id, ts, by)
    if channel ~= "GUILD" or not id or not by then return end
    by = NS.Short(by)
    if sender ~= by or not NS.IsOfficer(by) then return end
    ts = tonumber(ts)
    if not ts or math.abs(GetServerTime() - ts) > 20 then return end   -- nunca reproducir un aviso viejo
    if GetTime() - lastRun < C.HIMNO_COOLDOWN then return end
    if NS.inEncounter and NS.db.sounds.muteInEncounter then return end
    NS.RunHimno(id)
end)

----------------------------------------------------------------
-- Automático: todos los días a la hora de HIMNO_AUTO_HOUR (hora argentina)
----------------------------------------------------------------
local function SecondOfDayARG()
    return (GetServerTime() + C.HIMNO_UTC_OFFSET) % 86400   -- segundos desde las 00:00 en Argentina
end

-- since: segundos desde la última vez que fue la hora del himno · remain: segundos hasta la próxima
local function SinceAndRemain()
    local since = (SecondOfDayARG() - C.HIMNO_AUTO_HOUR * 3600) % 86400
    return since, (86400 - since) % 86400
end

local armedFor        -- medianoche para la que ya hay un temporizador exacto
local noticed = {}    -- [minutos] = medianoche ya avisada

local function Fire(target)
    local H = NS.db.himno
    if H.lastAuto == target then return end                -- ya sonó (o se salteó) para esta medianoche
    H.lastAuto = target
    if not (H.auto and NS.db.sounds.enabled) or H.noAudio then return end   -- sin audio: en silencio, sin carteles
    if GetTime() - lastRun < C.HIMNO_SECONDS then return end   -- ya hay uno sonando
    if NS.inEncounter and NS.db.sounds.muteInEncounter then
        Print("Se salteó el himno de las 00:00 porque estabas en una pelea de jefe.")
        return
    end
    NS.RunHimno("auto:" .. target, true)
end

local function AutoTick()
    local H = NS.db and NS.db.himno
    if not H or not H.auto or H.noAudio then return end
    local now = GetServerTime()
    local since, remain = SinceAndRemain()

    -- Justo pasó la hora (hasta 15 s): arrancar. Cubre a quien recién se conecta o tuvo un tirón.
    if since < 15 then Fire(now - since); return end

    -- Avisos previos ("faltan 5 minutos")
    for _, m in ipairs(C.HIMNO_AVISOS) do
        local limit = m * 60
        if remain <= limit and remain > limit - 40 and noticed[m] ~= now + remain then
            noticed[m] = now + remain
            NS.Toast(string.format("El himno suena a las %02d:00 (hora argentina)\nFaltan %d minutos.", C.HIMNO_AUTO_HOUR, m), 8, "himno")
        end
    end

    -- Falta muy poco: se arma un temporizador exacto para que arranque en el segundo justo
    if remain <= 12 and armedFor ~= now + remain then
        local target = now + remain
        armedFor = target
        C_Timer.After(remain, function() Fire(target) end)
    end
end

NS.RegisterCallback("READY", function()
    -- Con cada versión nueva se vuelve a comprobar si ya está el audio (por si bajaron el pack de sonidos)
    local H = NS.db.himno
    if H.checkedVersion ~= NS.version then
        H.noAudio = false
        H.checkedVersion = NS.version
    end
    C_Timer.NewTicker(10, AutoTick)   -- una cuenta muy liviana cada 10 segundos
end)

----------------------------------------------------------------
-- Comandos
--   /asado himno         (GM/oficiales) lo pone para toda la guild
--   /asado himno stop    (cualquiera)   lo corta solo para vos
--   /asado himno hora    (cualquiera)   muestra las horas para comprobar el horario
--   /asado himno aviso   (cualquiera)   muestra cómo se ve el aviso previo
--   /asado himno probar  (cualquiera)   lo reproduce solo para vos (comprueba que esté el audio)
----------------------------------------------------------------
local function ShowTimes()
    local sod = SecondOfDayARG()
    local _, remain = SinceAndRemain()
    local gh, gm = GetGameTime()
    Print(string.format("Hora argentina (UTC-3): |cffffd100%02d:%02d|r  |  hora del reino: %02d:%02d  |  hora de tu PC: %s",
        math.floor(sod / 3600), math.floor(sod % 3600 / 60), gh or 0, gm or 0, date("%H:%M")))
    Print(string.format("Próximo himno automático (%02d:00 hora argentina): dentro de %dh %dm %ds  |  %s",
        C.HIMNO_AUTO_HOUR, math.floor(remain / 3600), math.floor(remain % 3600 / 60), remain % 60,
        NS.db.himno.noAudio and "|cffff6644EN PAUSA: falta Sounds\\himno.ogg|r (probalo con /asado himno probar)"
            or NS.db.himno.auto and "|cff33ff33activado|r" or "|cffff6644DESACTIVADO|r (se prende en Opciones)"))
end

NS.commands.himno = function(rest)
    rest = (rest or ""):lower()
    if rest == "stop" or rest == "parar" then
        StopHimno()
        Print("Himno detenido (solo para vos).")
    elseif rest == "hora" then
        ShowTimes()
    elseif rest == "probar" then
        -- Reproduce el himno ahora, solo para vos: sirve para comprobar que el audio está bien instalado
        if not NS.db.sounds.enabled then Print("Tenés los sonidos apagados en Opciones."); return end
        local H = NS.db.himno
        local was = H.enabled
        H.noAudio = false
        H.enabled = true
        NS.RunHimno("probar:" .. GetServerTime())
        H.enabled = was
    elseif rest == "aviso" then
        NS.Toast(string.format("El himno suena a las %02d:00 (hora argentina)\nFaltan %d minutos.",
            C.HIMNO_AUTO_HOUR, C.HIMNO_AVISOS[1] or 5), 8, "himno")
    else
        NS.StartHimno()
    end
end
