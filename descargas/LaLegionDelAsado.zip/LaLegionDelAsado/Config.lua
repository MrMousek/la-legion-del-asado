--[[
    La Legión del Asado - Config.lua
    Constantes de la guild, valores por defecto y SavedVariables.
    ESTE ES EL ARCHIVO QUE TENÉS QUE EDITAR para personalizar el addon.
]]
local ADDON, NS = ...

----------------------------------------------------------------
-- Constantes de la guild (editá libremente)
----------------------------------------------------------------
NS.C = {
    GUILD_NAME  = "La Legión del Asado",
    SHORT_NAME  = "Legión del Asado",

    WEB_URL     = "https://lalegiondelasado.com/",
    DISCORD_URL = "https://discord.com/invite/RsEyM5frhT",

    -- Prefijo de AddonMessage (máx. 16 caracteres). Si cambiás el protocolo, subí el número.
    PREFIX      = "LDA1",

    -- Quién puede dar puntos: rankIndex del roster de la guild (0 = GM, 1 = segundo rango, etc.)
    OFFICER_MAX_RANK_INDEX = 1,

    -- Máximo de eventos de puntos que se mandan a un compañero que recién se conecta
    SYNC_MAX_EVENTS = 40,

    -- Rangos propios: { puntos_necesarios, nombre }  (orden ascendente)
    RANKS = {
        {   0, "Pinche" },
        {  20, "Carbonero" },
        {  60, "Parrillero" },
        { 120, "Asador" },
        { 250, "Maestro Asador" },
        { 500, "Leyenda del Quincho" },
    },

    -- Logo de la guild (Media/logo.tga: 256x256, 32 bits, transparente)
    LOGO = "Interface\\AddOns\\LaLegionDelAsado\\Media\\logo.tga",
    FLAG = "Interface\\AddOns\\LaLegionDelAsado\\Media\\bandera.tga",   -- bandera argentina (128x64)

    -- Colores de la bandera (celeste, blanco, sol) para los detalles de la interfaz
    CELESTE = { 0.455, 0.675, 0.875 },
    SOL     = { 0.965, 0.706, 0.055 },

    -- Himno Nacional: lo pone el GM o un oficial; lo escuchan todos los que tengan el addon
    HIMNO_SECONDS   = 242,   -- duración del himno.ogg en segundos (el completo dura 4:00; ajustalo si cambiás el archivo)
    HIMNO_COUNTDOWN = 3,     -- segundos entre el aviso "¡De pie, Legión!" y el comienzo
    HIMNO_COOLDOWN  = 300,   -- segundos mínimos entre un himno y el siguiente

    -- Himno automático (todos los días, como las radios). Hora ARGENTINA fija: UTC-3, sin horario de verano.
    -- Se calcula con el reloj absoluto del servidor, así que es igual para todos sin importar la hora de su PC ni la del reino.
    HIMNO_UTC_OFFSET = -3 * 3600,
    HIMNO_AUTO_HOUR  = 0,        -- 0 = medianoche
    HIMNO_AVISOS     = { 5 },    -- avisos previos, en minutos (por ejemplo { 10, 5 } para avisar dos veces)

    -- Alertas PvP (/asado sos y /asado reunion)
    SOS_COOLDOWN     = 60,    -- segundos que espera un jugador entre un SOS y el siguiente
    REUNION_COOLDOWN = 80,    -- ídem para las zonas de reunión
    SOS_EXPIRE       = 180,   -- cuánto dura el SOS en el mapa (segundos)
    REUNION_EXPIRE   = 600,   -- cuánto dura la zona de reunión en el mapa (segundos)
    ALERT_MSG_MAX    = 60,    -- largo máximo del mensaje

    -- Dónde bajar el addon (para los mensajes sugeridos a los que no lo tienen o lo tienen viejo)
    ADDON_PAGE = "CurseForge: La Legión del Asado - Guild Addon",

    -- Cierres para los avisos de muerte de compañeros
    DEATH_SUFFIX = {
        "¡Que traiga el fernet!",
        "Pasen el chorizo, que se nos fue.",
        "F en el chat.",
        "Otro voto para el Pollo del Mes.",
        "Sin drama, que el asado espera.",
    },

    -- PvP (neutral a la facción: se habla de "enemigos")
    DEATH_SUFFIX_PVP = {
        "¡Que no quede sin respuesta!",
        "La guild lo vengará.",
        "Hay que cobrar revancha.",
        "Así es el PvP, che.",
    },
    PVP_MILESTONES = { 10, 25, 50, 100, 250, 500, 1000 },
    PVP_FRASES = {
        "¡%s ya lleva %d bajas este mes!",
        "%s suma %d bajas en el mes. ¡A la parrilla con ellos!",
        "Se está haciendo un festín: %s con %d bajas este mes.",
    },

    -- Dragón del retrato: nombres de atlas de Blizzard (se prueban en orden, usa el primero que exista)
    DRAGON_ATLAS = {
        gold   = { "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Gold",   "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Gold-Winged" },
        silver = { "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Rare-Silver", "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Silver", "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Silver-Winged" },
    },

    -- Ubicación de compañeros (opt-in)
    NEAR_RADIUS   = 300,   -- yardas: "está cerca"
    LOC_INTERVAL  = 8,     -- segundos entre envíos de mi posición (solo si me muevo)
    LOC_EXPIRE    = 40,    -- segundos sin noticias y el compañero desaparece de la lista
    NEAR_COOLDOWN = 600,   -- segundos antes de volver a avisar que el mismo compañero está cerca

    -- Niveles que disparan aviso a la guild (además del nivel máximo, que se detecta solo)
    LEVEL_MILESTONES = { 10, 20, 30, 40, 50, 55, 60 },

    -- Frases de nivel: (nombre, nivel)
    LEVEL_FRASES_PRIMERO = {
        "¡%s llegó a nivel %d y es el PRIMERO de la guild!",
        "¡Primero en la parrilla! %s ya está en nivel %d.",
        "¡%s llegó a nivel %d antes que todos! Que alguien le pase el chorizo.",
    },
    LEVEL_FRASES_NORMAL = {
        "%s llegó a nivel %d. ¡Salud!",
        "%s ya es nivel %d. La carne se cocina sola.",
        "%s subió a nivel %d. ¡Que no falte el fernet!",
    },

    -- Frases de la ruleta (título, ganador)
    RULETA_FRASES = {
        "[Ruleta del Asado] %s: ¡le tocó a %s! Sin chistar, che.",
        "[Ruleta del Asado] %s: ¡salió %s! Que no se diga que no hay justicia.",
        "[Ruleta del Asado] %s: %s, es tu momento, loco.",
    },
}

----------------------------------------------------------------
-- Opciones por defecto (se completan sobre LegionDelAsadoDB)
----------------------------------------------------------------
NS.defaults = {
    debug = false,
    officerMaxRank = NS.C.OFFICER_MAX_RANK_INDEX,
    broadcastDeaths = true,   -- avisar a la guild cuando YO me muero
    deathChat = true,         -- línea en el chat cuando muere alguien de la guild

    minimap = { angle = 200, hide = false },

    sounds = {
        enabled = true,
        muteInEncounter = true,   -- "no molestar" durante pelea de jefe
        guildDeaths = true,       -- sonido cuando muere un compañero
        trade = true,             -- sonido al completar un comercio
    },

    toasts = {
        enabled = true,
        deaths = true,   -- aviso en pantalla cuando muere un compañero
        levels = true,
        pvp = true,
    },

    ruleta = { title = "Fernet", names = "" },

    dragon = { style = "off", scale = 1, x = 0, y = 0, flip = false },   -- off | gold | silver (apagado de fábrica)
    welcomed = false,
    -- Ubicación de compañeros. share: compartir MI ubicación (activado de fábrica) · near: aviso en pantalla
    -- cuando alguien está cerca · indicator: pastillita junto al minimapa · map: marcas en el mapa del mundo
    location = { share = true, near = false, indicator = true, map = true },   -- share: viene ACTIVADO (se apaga con /asado ubicacion off)
    himno = { enabled = true, auto = true, lastAuto = 0, noAudio = false, checkedVersion = "" },   -- enabled: escuchar el himno del GM/oficiales · auto: el de las 00:00
    pvpAlerts = { enabled = true, sound = true },   -- recibir las alertas de ayuda / reunión PvP y su sonido
    members = {},   -- members[nombre] = { v = versión del addon, f = interfaz del cliente, t = última vez visto }
    resets = { muertes = 0, historial = 0, pvp = 0, niveles = 0 },  -- momento del último reinicio de cada contador
    resetBy = {},        -- quién lo reinició
    testNames = {},      -- nombres usados en /asado test (para poder limpiarlos)
    syncOnZone = true,   -- sincronizar con la guild en cada pantalla de carga (cada 60 s como máximo)
    deathLog = {},       -- historial de muertes de la guild: { name, class, lvl, zone, sub, coords, pvp, ts }
    pvp = {},           -- pvp[ "2026-10" ][ "Nombre" ] = bajas honorables del mes
    pvpLifetime = false, -- bajas honorables totales vistas por última vez (para detectar las nuevas)

    ledger = {},    -- historial de puntos (lista de eventos)
    deaths = {},    -- deaths[ "2026-10" ][ "Nombre" ] = cantidad
    myDeaths = {},  -- myDeaths[ "2026-10" ] = cantidad
    levels = {},    -- levels[ "Nombre" ] = { l = nivel, ts = momento en que lo alcanzó }
    listas = {},    -- pases de lista ya hechos (evita duplicados el mismo día)
    lastMonthShown = "",
    firsts = {},    -- firsts[ nivel ] = { name = "Nombre", ts = momento }  (primero de la guild)
}

----------------------------------------------------------------
-- Manejo de la base de datos
----------------------------------------------------------------
local function MergeDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            MergeDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

function NS.InitDB()
    LegionDelAsadoDB = LegionDelAsadoDB or {}
    NS.db = LegionDelAsadoDB
    MergeDefaults(NS.defaults, NS.db)
end

----------------------------------------------------------------
-- Rangos
----------------------------------------------------------------
-- Devuelve: nombreRango, nombreSiguiente|nil, puntosQueFaltan|nil
function NS.GetRank(points)
    local ranks = NS.C.RANKS
    local idx = 1
    for i, r in ipairs(ranks) do
        if points >= r[1] then idx = i else break end
    end
    local cur, nxt = ranks[idx], ranks[idx + 1]
    return cur[2], nxt and nxt[2] or nil, nxt and (nxt[1] - points) or nil
end
