--[[
    La Legión del Asado - Config.lua
    Constantes de la guild, valores por defecto y SavedVariables.
    ESTE ES EL ARCHIVO QUE TENÉS QUE EDITAR para personalizar el addon.
]]
local ADDON, NS = ...

----------------------------------------------------------------
-- Constantes de la guild (editá libremente)
----------------------------------------------------------------
NS.C = {
    GUILD_NAME  = "La Legión del Asado",
    SHORT_NAME  = "Legión del Asado",

    WEB_URL     = "https://lalegiondelasado.com/",
    DISCORD_URL = "https://discord.com/invite/RsEyM5frhT",

    -- Prefijo de AddonMessage (máx. 16 caracteres). Si cambiás el protocolo, subí el número.
    PREFIX      = "LDA1",

    -- Quién puede dar puntos: rankIndex del roster de la guild (0 = GM, 1 = segundo rango, etc.)
    OFFICER_MAX_RANK_INDEX = 1,

    -- Máximo de eventos de puntos que se mandan a un compañero que recién se conecta
    SYNC_MAX_EVENTS = 40,

    -- Rangos propios: { puntos_necesarios, nombre }  (orden ascendente)
    RANKS = {
        {   0, "Pinche" },
        {  20, "Carbonero" },
        {  60, "Parrillero" },
        { 120, "Asador" },
        { 250, "Maestro Asador" },
        { 500, "Leyenda del Quincho" },
    },

    -- Logo de la guild (Media/logo.tga: 256x256, 32 bits, transparente)
    LOGO = "Interface\\AddOns\\LaLegionDelAsado\\Media\\logo.tga",
    FLAG = "Interface\\AddOns\\LaLegionDelAsado\\Media\\bandera.tga",   -- bandera argentina (128x64)

    -- Colores de la bandera (celeste, blanco, sol) para los detalles de la interfaz
    CELESTE = { 0.455, 0.675, 0.875 },
    SOL     = { 0.965, 0.706, 0.055 },

    -- Himno Nacional: lo pone el GM o un oficial; lo escuchan todos los que tengan el addon
    HIMNO_SECONDS   = 242,   -- duración del himno.ogg en segundos (el completo dura 4:00; ajustalo si cambiás el archivo)
    HIMNO_COUNTDOWN = 3,     -- segundos entre el aviso "¡De pie, Legión!" y el comienzo
    HIMNO_COOLDOWN  = 300,   -- segundos mínimos entre un himno y el siguiente

    -- Himno automático (todos los días, como las radios). Hora ARGENTINA fija: UTC-3, sin horario de verano.
    -- Se calcula con el reloj absoluto del servidor, así que es igual para todos sin importar la hora de su PC ni la del reino.
    HIMNO_UTC_OFFSET = -3 * 3600,
    HIMNO_AUTO_HOUR  = 0,        -- 0 = medianoche
    HIMNO_AVISOS     = { 5 },    -- avisos previos, en minutos (por ejemplo { 10, 5 } para avisar dos veces)

    -- Alertas PvP (/asado sos y /asado reunion)
    SOS_COOLDOWN     = 20,    -- segundos que espera un jugador entre un SOS y el siguiente
    REUNION_COOLDOWN = 60,    -- ídem para las zonas de reunión
    SOS_EXPIRE       = 180,   -- cuánto dura el SOS en el mapa (segundos)
    REUNION_EXPIRE   = 600,   -- cuánto dura la zona de reunión en el mapa (segundos)
    ALERT_MSG_MAX    = 60,    -- largo máximo del mensaje
    RESPOND_RADIUS   = 60,    -- yardas: a partir de acá se considera que llegaste a un SOS o a una reunión

    -- Subí este número cuando agregues logros nuevos: los que ya cumplís al actualizar se registran en silencio
    ACH_VERSION = 2,

    -- LOGROS DE LA LEGIÓN (se editan acá: nombre, descripción, metas y puntos)
    --   pts    = puntos de reconocimiento que suma (cuentan para el Asador del Mes y para los rangos)
    --   manual = true: lo da un oficial o el GM con /asado darlogro (eventos presenciales, etc.)
    -- kind numérico (se desbloquea solo al llegar a "value"):
    --   level · profession · kills · deaths · trades · bosses · wipes · epics · points · achievements
    -- kind "event": lo dispara una acción del juego (ver Logros.lua) o, si es manual, un oficial.
    ACHIEVEMENTS = {
        -- NIVEL Y PROGRESIÓN
        { id = "nivel_10",   cat = "nivel", name = "Primeros pasos",           desc = "Llegá a nivel 10.",  kind = "level", value = 10, pts = 1 },
        { id = "nivel_20",   cat = "nivel", name = "Ya caminás",               desc = "Llegá a nivel 20.",  kind = "level", value = 20, pts = 2 },
        { id = "nivel_30",   cat = "nivel", name = "Tamo a mitad de camino",   desc = "Llegá a nivel 30.",  kind = "level", value = 30, pts = 3 },
        { id = "nivel_40",   cat = "nivel", name = "Pasado el ecuador",        desc = "Llegá a nivel 40.",  kind = "level", value = 40, pts = 4 },
        { id = "nivel_50",   cat = "nivel", name = "A las puertas de la gloria", desc = "Llegá a nivel 50.", kind = "level", value = 50, pts = 5 },
        { id = "nivel_60",   cat = "nivel", name = "Leyenda del Quincho",      desc = "Llegá al nivel máximo.", kind = "level", value = 60, pts = 10 },
        { id = "primero",    cat = "nivel", name = "El primero de la Legión",  desc = "Sé el primero de la guild en llegar a un nivel importante.", kind = "event", pts = 5 },

        -- OFICIOS
        { id = "oficio_75",    cat = "oficio", name = "Aprendiz del coso",      desc = "Llegá a 75 en una profesión.",  kind = "profession", value = 75,  pts = 1 },
        { id = "oficio_150",   cat = "oficio", name = "Manos de artesano",      desc = "Llegá a 150 en una profesión.", kind = "profession", value = 150, pts = 2 },
        { id = "oficio_225",   cat = "oficio", name = "Oficial matriculado",    desc = "Llegá a 225 en una profesión.", kind = "profession", value = 225, pts = 3 },
        { id = "oficio_300",   cat = "oficio", name = "Maestro de oficios",     desc = "Llegá a 300 en una profesión.", kind = "profession", value = 300, pts = 5 },
        { id = "pescador_150", cat = "oficio", name = "Paciencia de asador",    desc = "Llegá a 150 en Pesca.",   kind = "profession", value = 150, pts = 2, skill = { line = 356, names = { "Pesca", "Fishing" } } },
        { id = "cocina_300",   cat = "oficio", name = "Chef del Quincho",       desc = "Llegá a 300 en Cocina.",  kind = "profession", value = 300, pts = 3, skill = { line = 185, names = { "Cocina", "Cooking" } } },

        -- PVP
        { id = "pvp_1",    cat = "pvp", name = "Primera sangre",         desc = "Conseguí tu primera baja honorable.", kind = "kills", value = 1,   pts = 1 },
        { id = "pvp_10",   cat = "pvp", name = "Afilando el cuchi",      desc = "Conseguí 10 bajas honorables.",       kind = "kills", value = 10,  pts = 2 },
        { id = "pvp_50",   cat = "pvp", name = "Cazador de gordas",      desc = "Conseguí 50 bajas honorables.",       kind = "kills", value = 50,  pts = 3 },
        { id = "pvp_100",  cat = "pvp", name = "Carnicero de la Legión", desc = "Conseguí 100 bajas honorables.",      kind = "kills", value = 100, pts = 5 },
        { id = "pvp_250",  cat = "pvp", name = "Dador de bija",          desc = "Conseguí 250 bajas honorables.",      kind = "kills", value = 250, pts = 8 },
        { id = "bg_primero",       cat = "pvp", name = "Bajo la bandera",        desc = "Entrá a un campo de batalla.",                             kind = "event", pts = 2 },
        { id = "sos_pedir",        cat = "pvp", name = "¡Auxilio!",              desc = "Pedí ayuda a la guild con /asado sos.",                    kind = "event", pts = 1 },
        { id = "sos_responde",     cat = "pvp", name = "Ahí voy amiguito",       desc = "Llegá hasta un compañero que pidió ayuda con un SOS.",     kind = "event", pts = 3 },
        { id = "reunion",          cat = "pvp", name = "Llamado a las armas",    desc = "Armá una zona de reunión PvP para la guild.",              kind = "event", pts = 2 },
        { id = "reunion_responde", cat = "pvp", name = "Presente en la juntada", desc = "Llegá a una zona de reunión PvP armada por un compañero.", kind = "event", pts = 2 },

        -- AVENTURA
        { id = "epico_1",          cat = "aventura", name = "Brilla en la oscuridad",   desc = "Conseguí tu primer ítem épico.",                      kind = "epics",  value = 1,  pts = 2 },
        { id = "jefe_10",          cat = "aventura", name = "Rompe-jefes",              desc = "Derrotá 10 jefes de mazmorra o raid.",                kind = "bosses", value = 10, pts = 3 },
        { id = "mazmorra_legion",  cat = "aventura", name = "Mazmorreros de la Legión", desc = "Estar en una mazmorra con 3 o más miembros de la guild.", kind = "event", pts = 3 },
        { id = "raid_legion",      cat = "aventura", name = "La Legión en armas",      desc = "Estar en una raid con 10 o más miembros de la guild.", kind = "event", pts = 5 },

        -- SOCIAL
        { id = "comercio_1",  cat = "social", name = "Perfecto, perfecto, caballero", desc = "Completá tu primer comercio con otro jugador.",     kind = "trades", value = 1,  pts = 1 },
        { id = "comercio_10", cat = "social", name = "Negociante matriculado",        desc = "Completá 10 comercios con otros jugadores.",       kind = "trades", value = 10, pts = 2 },
        { id = "comercio_50", cat = "social", name = "Mercader del asado",            desc = "Completá 50 comercios con otros jugadores.",       kind = "trades", value = 50, pts = 5 },
        { id = "ruleta",      cat = "social", name = "Suertudo del asado",   desc = "Ganá un sorteo de la Ruleta del Fernet.",                  kind = "event", pts = 2 },
        { id = "himno",       cat = "social", name = "De pie, Legión",       desc = "Escuchá el Himno Nacional junto a la guild.",              kind = "event", pts = 1 },
        { id = "himno_00",    cat = "social", name = "Patriota de medianoche", desc = "Escuchá el himno automático de las 00:00.",             kind = "event", pts = 2 },
        { id = "himno_lider", cat = "social", name = "Director de orquesta", desc = "Iniciá la reproducción del Himno Nacional para la guild.", kind = "event", pts = 2 },
        { id = "asistencia",  cat = "social", name = "Siempre presente",     desc = "Que un oficial te sume puntos por asistir a un evento.",   kind = "event", pts = 3 },
        { id = "juntada",     cat = "social", name = "Juntada espontánea",   desc = "Tené a 3 compañeros de la guild cerca tuyo a la vez.",     kind = "event", pts = 2 },
        { id = "asador_mes",  cat = "social", name = "Asador del Mes",       desc = "Ganá el ranking del Asador del Mes.",                      kind = "event", pts = 10 },
        { id = "puntos_50",   cat = "social", name = "Parrillero de oro",    desc = "Acumulá 50 puntos de reconocimiento.",                     kind = "points", value = 50, pts = 3 },
        { id = "logros_10",   cat = "social", name = "Coleccionista de la Legión", desc = "Desbloqueá 10 logros.",                              kind = "achievements", value = 10, pts = 5 },

        -- HUMOR
        { id = "muerte_1",  cat = "humor", name = "Bautismo de fuego",           desc = "Morite por primera vez con el addon.",                 kind = "deaths", value = 1,  pts = 1 },
        { id = "muerte_5",  cat = "humor", name = "Recién empezamos (a morir)",  desc = "Morite 5 veces. El jardín te lo agradece.",            kind = "deaths", value = 5,  pts = 1 },
        { id = "pollo_10",  cat = "humor", name = "Pollo oficial",               desc = "Morite 10 veces. Sin drama, que el asado espera.",     kind = "deaths", value = 10, pts = 2 },
        { id = "pollo_25",  cat = "humor", name = "Quiere bija",                 desc = "Morite 25 veces. El título de Pollo del Mes te llama.", kind = "deaths", value = 25, pts = 3 },
        { id = "fantasma",  cat = "humor", name = "Fantasmón",                   desc = "Morite 50 veces acumuladas con el addon.",             kind = "deaths", value = 50, pts = 5 },
        { id = "pollo_mes", cat = "humor", name = "Pollo del Mes",               desc = "Ganá el ranking del Pollo del Mes. Todo un honor.",    kind = "event", pts = 3 },
        { id = "wipe_5",    cat = "humor", name = "Aprendiendo de los errores",  desc = "Participá de 5 wipes.",                                kind = "wipes",  value = 5,  pts = 2 },

        -- EVENTOS (los da un oficial o el GM con /asado darlogro)
        { id = "guild_lan",      cat = "evento", name = "Gorditos Laneros",       desc = "Participá de un evento o juntada especial de la guild.", kind = "event", manual = true, pts = 5 },
        { id = "evento_raid",    cat = "evento", name = "Raid de la hermandad",   desc = "Participá de una raid organizada por la guild.",         kind = "event", manual = true, pts = 5 },
        { id = "evento_pvp",     cat = "evento", name = "Guerra de la Legión",    desc = "Participá de un evento PvP organizado por la guild.",    kind = "event", manual = true, pts = 5 },
        { id = "mvp_evento",     cat = "evento", name = "Jugador del evento",     desc = "Que los oficiales te elijan jugador destacado de un evento.", kind = "event", manual = true, pts = 8 },
        { id = "alma_solidaria", cat = "evento", name = "Alma solidaria",         desc = "Ayudá a un jugador nuevo de la guild.",                  kind = "event", manual = true, pts = 5 },
        { id = "reclutador",     cat = "evento", name = "Reclutador",             desc = "Traé a un amigo a la Legión.",                           kind = "event", manual = true, pts = 5 },
        { id = "fundador",       cat = "evento", name = "Fundador de la Legión",  desc = "Estuviste desde el principio de la hermandad.",          kind = "event", manual = true, pts = 10 },
        { id = "suicidio",       cat = "evento", name = "Ta duro el piso che?",   desc = "Morite cayéndote de un lugar alto por andar distraído.", kind = "event", manual = true, pts = 2 },
    },

    -- Categorías de logros, en el orden en que se muestran
    ACH_CATS = {
        { key = "nivel",    name = "Nivel",   color = { 0.45, 0.68, 0.88 } },
        { key = "oficio",   name = "Oficios", color = { 0.85, 0.65, 0.30 } },
        { key = "pvp",      name = "PvP",     color = { 0.95, 0.30, 0.25 } },
        { key = "aventura", name = "Aventura", color = { 0.65, 0.50, 0.90 } },
        { key = "social",   name = "Social",  color = { 0.40, 0.85, 0.50 } },
        { key = "humor",    name = "Humor",   color = { 0.90, 0.80, 0.30 } },
        { key = "evento",   name = "Eventos", color = { 0.95, 0.60, 0.20 } },
    },

    -- Exportación de rankings para la web (/asado exportar)
    EXPORT_TOP = 20,     -- cuántos entran en cada ranking del archivo
    ARCHIVE_TOP = 10,    -- cuántos se guardan en el archivo de cada mes

    -- Dónde bajar el addon (para los mensajes sugeridos a los que no lo tienen o lo tienen viejo)
    ADDON_PAGE = "lalegiondelasado.com/pages/addon.html",

    -- Cierres para los avisos de muerte de compañeros
    DEATH_SUFFIX = {
        "¡Que traiga el fernet!",
        "Pasen el chorizo, que se nos fue.",
        "F en el chat.",
        "Otro voto para el Pollo del Mes.",
        "Sin drama, que el asado espera.",
    },

    -- PvP (neutral a la facción: se habla de "enemigos")
    DEATH_SUFFIX_PVP = {
        "¡Que no quede sin respuesta!",
        "La guild lo vengará.",
        "Hay que cobrar revancha.",
        "Así es el PvP, che.",
    },
    PVP_MILESTONES = { 10, 25, 50, 100, 250, 500, 1000 },
    PVP_FRASES = {
        "¡%s ya lleva %d bajas este mes!",
        "%s suma %d bajas en el mes. ¡A la parrilla con ellos!",
        "Se está haciendo un festín: %s con %d bajas este mes.",
    },

    -- Dragón del retrato: nombres de atlas de Blizzard (se prueban en orden, usa el primero que exista)
    DRAGON_ATLAS = {
        gold   = { "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Gold",   "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Gold-Winged" },
        silver = { "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Rare-Silver", "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Silver", "UI-HUD-UnitFrame-Target-PortraitOn-Boss-Silver-Winged" },
    },

    -- Ubicación de compañeros (opt-in)
    NEAR_RADIUS   = 300,   -- yardas: "está cerca"
    LOC_INTERVAL  = 8,     -- segundos entre envíos de mi posición (solo si me muevo)
    LOC_EXPIRE    = 40,    -- segundos sin noticias y el compañero desaparece de la lista
    NEAR_COOLDOWN = 600,   -- segundos antes de volver a avisar que el mismo compañero está cerca

    -- Niveles que disparan aviso a la guild (además del nivel máximo, que se detecta solo)
    LEVEL_MILESTONES = { 10, 20, 30, 40, 50, 55, 60 },

    -- Frases de nivel: (nombre, nivel)
    LEVEL_FRASES_PRIMERO = {
        "¡%s llegó a nivel %d y es el PRIMERO de la guild!",
        "¡Primero en la parrilla! %s ya está en nivel %d.",
        "¡%s llegó a nivel %d antes que todos! Que alguien le pase el chorizo.",
    },
    LEVEL_FRASES_NORMAL = {
        "%s llegó a nivel %d. ¡Salud!",
        "%s ya es nivel %d. La carne se cocina sola.",
        "%s subió a nivel %d. ¡Que no falte el fernet!",
    },

    -- Ruleta del Fernet: segundos que tiene que esperar cada jugador entre una tirada y la siguiente (contra el spam)
    RULETA_COOLDOWN = 300,

    -- Frases de la ruleta (título, ganador)
    RULETA_FRASES = {
        "[Ruleta del Asado] %s: ¡le tocó a %s! Sin chistar, che.",
        "[Ruleta del Asado] %s: ¡salió %s! Que no se diga que no hay justicia.",
        "[Ruleta del Asado] %s: %s, es tu momento, loco.",
    },
}

----------------------------------------------------------------
-- Opciones por defecto (se completan sobre LegionDelAsadoDB)
----------------------------------------------------------------
NS.defaults = {
    debug = false,
    officerMaxRank = NS.C.OFFICER_MAX_RANK_INDEX,
    broadcastDeaths = true,   -- avisar a la guild cuando YO me muero
    deathChat = true,         -- línea en el chat cuando muere alguien de la guild

    minimap = { angle = 200, hide = false },

    sounds = {
        enabled = true,
        muteInEncounter = true,   -- "no molestar" durante pelea de jefe
        guildDeaths = true,       -- sonido cuando muere un compañero
        trade = true,             -- sonido al completar un comercio
    },

    toasts = {
        enabled = true,
        deaths = true,   -- aviso en pantalla cuando muere un compañero
        levels = true,
        pvp = true,
    },

    ruleta = { title = "Fernet", names = "", lastSpin = 0 },

    dragon = { style = "off", scale = 1, x = 0, y = 0, flip = false },   -- off | gold | silver (apagado de fábrica)
    welcomed = false,
    -- Ubicación de compañeros. share: compartir MI ubicación (activado de fábrica) · near: aviso en pantalla
    -- cuando alguien está cerca · indicator: pastillita junto al minimapa · map: marcas en el mapa del mundo
    location = { share = true, near = false, indicator = true, map = true },   -- share: viene ACTIVADO (se apaga con /asado ubicacion off)
    himno = { enabled = true, auto = true, lastAuto = 0, noAudio = false, checkedVersion = "" },   -- enabled: escuchar el himno del GM/oficiales · auto: el de las 00:00
    pvpAlerts = { enabled = true, sound = true },   -- recibir las alertas de ayuda / reunión PvP y su sonido
    achievements = {},   -- achievements[id] = momento en que se desbloqueó
    stats = { deaths = 0, kills = 0, trades = 0, bosses = 0, wipes = 0, epics = 0 },   -- contadores para los logros
    achLog = {},    -- quién desbloqueó qué (de toda la guild): { who, id, ts, by } · de acá salen los puntos de los logros
    archive = {},   -- archive[ "2026-10" ] = resumen del mes con sus ganadores (se guarda al terminar el mes)
    export = {},    -- último archivo de rankings generado con /asado exportar
    achOpts = { announce = true, hear = true },      -- avisar mis logros a la guild · ver los de los demás en el chat
    achInit = 0,
    members = {},   -- members[nombre] = { v = versión del addon, f = interfaz del cliente, t = última vez visto }
    resets = { muertes = 0, historial = 0, pvp = 0, niveles = 0 },  -- momento del último reinicio de cada contador
    resetBy = {},        -- quién lo reinició
    testNames = {},      -- nombres usados en /asado test (para poder limpiarlos)
    syncOnZone = true,   -- sincronizar con la guild en cada pantalla de carga (cada 60 s como máximo)
    deathLog = {},       -- historial de muertes de la guild: { name, class, lvl, zone, sub, coords, pvp, ts }
    pvp = {},           -- pvp[ "2026-10" ][ "Nombre" ] = bajas honorables del mes
    pvpLifetime = false, -- bajas honorables totales vistas por última vez (para detectar las nuevas)

    ledger = {},    -- historial de puntos (lista de eventos)
    deaths = {},    -- deaths[ "2026-10" ][ "Nombre" ] = cantidad
    myDeaths = {},  -- myDeaths[ "2026-10" ] = cantidad
    levels = {},    -- levels[ "Nombre" ] = { l = nivel, ts = momento en que lo alcanzó }
    listas = {},    -- pases de lista ya hechos (evita duplicados el mismo día)
    lastMonthShown = "",
    firsts = {},    -- firsts[ nivel ] = { name = "Nombre", ts = momento }  (primero de la guild)
}

----------------------------------------------------------------
-- Manejo de la base de datos
----------------------------------------------------------------
local function MergeDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            MergeDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

function NS.InitDB()
    LegionDelAsadoDB = LegionDelAsadoDB or {}
    NS.db = LegionDelAsadoDB
    MergeDefaults(NS.defaults, NS.db)
end

----------------------------------------------------------------
-- Rangos
----------------------------------------------------------------
-- Devuelve: nombreRango, nombreSiguiente|nil, puntosQueFaltan|nil
function NS.GetRank(points)
    local ranks = NS.C.RANKS
    local idx = 1
    for i, r in ipairs(ranks) do
        if points >= r[1] then idx = i else break end
    end
    local cur, nxt = ranks[idx], ranks[idx + 1]
    return cur[2], nxt and nxt[2] or nil, nxt and (nxt[1] - points) or nil
end
