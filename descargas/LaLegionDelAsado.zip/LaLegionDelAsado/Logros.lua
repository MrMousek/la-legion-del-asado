--[[
    La Legión del Asado - Logros.lua
    Logros personales de la guild. La lista, los nombres, las metas y los PUNTOS de cada logro están
    en Config.lua > ACHIEVEMENTS.

    Hay tres clases de logros:
      * Numéricos: se desbloquean solos al llegar a la meta (nivel, profesión, bajas PvP, muertes, comercios,
        jefes, wipes, épicos, puntos de reconocimiento, cantidad de logros).
      * De evento: los dispara una acción del juego (ganar la ruleta, escuchar el himno, llegar a un SOS...).
        Los otros módulos avisan con NS.Fire("GAME_EVENT", "id_del_logro").
      * Manuales (manual = true): los da un oficial o el GM con /asado darlogro (eventos presenciales, etc.).

    LOS LOGROS DAN PUNTOS. Cada logro desbloqueado suma los puntos que dice Config.lua al Asador del Mes y a
    los rangos de quien lo consiguió. Para que todos vean los mismos puntos, cada desbloqueo se anota en un
    registro compartido de la guild (db.achLog) que se sincroniza como los puntos de los oficiales.
    Lo que ya cumplías al instalar (o al sumarse logros nuevos) se registra UNA vez y en silencio, sin puntos.
]]
local ADDON, NS = ...
local C = NS.C
local Print = NS.Print

local SND = "Interface\\AddOns\\" .. ADDON .. "\\Sounds\\"
NS.Sounds.logro = { files = { SND .. "logro.ogg" }, kit = "IG_QUEST_LIST_COMPLETE", len = 1.3, prio = 2, cd = 2 }

local BY_ID = {}
for _, a in ipairs(C.ACHIEVEMENTS) do BY_ID[a.id] = a end
NS.AchById = BY_ID

function NS.AchPoints(id)
    local a = BY_ID[id]
    return a and a.pts or 0
end

----------------------------------------------------------------
-- Registro de la guild: quién desbloqueó qué
----------------------------------------------------------------
local logIndex = {}     -- "quien:id" -> true
local latestAch = 0     -- fecha del último desbloqueo conocido (para sincronizar)

local function LogKey(who, id) return who .. ":" .. id end

local function IndexLog()
    wipe(logIndex)
    latestAch = 0
    for _, e in ipairs(NS.db.achLog) do
        logIndex[LogKey(e.who, e.id)] = true
        if e.ts > latestAch then latestAch = e.ts end
    end
end

-- true si era nuevo
local function AddLogEntry(who, id, ts, by)
    local key = LogKey(who, id)
    if logIndex[key] then return false end
    logIndex[key] = true
    table.insert(NS.db.achLog, { who = who, id = id, ts = ts, by = by })
    if ts > latestAch then latestAch = ts end
    NS.totalsCache = nil           -- los puntos cambiaron: se recalculan
    NS.Fire("ACHIEVEMENTS_UPDATED")
    return true
end

function NS.LatestAchTs() return latestAch end

local function AchString(e)
    return table.concat({ "ALOG", e.who, e.id, e.ts, e.by or "" }, "^")
end

-- Para la sincronización: los desbloqueos más nuevos que ts (hasta max), de a uno por mensaje
function NS.AchLogSince(ts, max)
    local list = {}
    for _, e in ipairs(NS.db.achLog) do
        if e.ts > ts then list[#list + 1] = e end
    end
    table.sort(list, function(a, b) return a.ts < b.ts end)
    local out = {}
    for i = math.max(1, #list - max + 1), #list do out[#out + 1] = AchString(list[i]) end
    return out
end

-- ¿Alguien ya tiene este logro registrado?
function NS.HasAchievement(who, id) return logIndex[LogKey(who, id)] == true end

-- Puntos de logros de cada jugador: [nombre] = { total, month, count }   (month = puntos del mes pedido; por defecto el actual)
function NS.AchPointsByPlayer(monthKey)
    local out, mk = {}, monthKey or NS.MonthKey()
    for _, e in ipairs(NS.db.achLog) do
        local p = NS.AchPoints(e.id)
        local r = out[e.who]
        if not r then r = { total = 0, month = 0, count = 0 }; out[e.who] = r end
        r.count = r.count + 1
        r.total = r.total + p
        if (e.mk or date("%Y-%m", e.ts)) == mk then r.month = r.month + p end
    end
    return out
end

----------------------------------------------------------------
-- Progreso de los logros numéricos
----------------------------------------------------------------
-- Mayor habilidad entre tus profesiones (o en una en particular, si el logro la pide).
-- Cada API va protegida: si el cliente no la trae, queda en 0.
local function MaxProfession(skill)
    local best = 0
    pcall(function()
        local function Consider(name, rank, line)
            if not rank then return end
            if skill then
                local match = (line and skill.line and line == skill.line)
                if not match and name then
                    for _, n in ipairs(skill.names or {}) do
                        if name == n then match = true end
                    end
                end
                if not match then return end
            end
            if rank > best then best = rank end
        end
        if GetProfessions and GetProfessionInfo then
            local list = { GetProfessions() }          -- puede traer huecos (nil) entre una profesión y otra
            for i = 1, 6 do
                if list[i] then
                    local name, _, rank, _, _, _, line = GetProfessionInfo(list[i])
                    Consider(name, rank, line)
                end
            end
        elseif GetNumSkillLines and GetSkillLineInfo then
            for i = 1, GetNumSkillLines() do
                local name, header, _, rank, _, _, _, abandonable = GetSkillLineInfo(i)
                if not header and (skill or abandonable) then Consider(name, rank, nil) end
            end
        end
    end)
    return best
end

local function CountUnlocked()
    local n = 0
    for _ in pairs(NS.db.achievements) do n = n + 1 end
    return n
end

-- Valor actual de un logro numérico (nil si es de evento)
function NS.AchievementProgress(a)
    local k, s = a.kind, NS.db.stats
    if k == "level" then return UnitLevel("player")
    elseif k == "profession" then return MaxProfession(a.skill)
    elseif k == "kills" then return NS.TotalKills()
    elseif k == "deaths" then return s.deaths or 0
    elseif k == "trades" then return s.trades or 0
    elseif k == "bosses" then return s.bosses or 0
    elseif k == "wipes" then return s.wipes or 0
    elseif k == "epics" then return s.epics or 0
    elseif k == "points" then return (NS.ComputeTotals())[NS.me] or 0
    elseif k == "achievements" then return CountUnlocked()
    end
    return nil
end

----------------------------------------------------------------
-- Desbloquear
----------------------------------------------------------------
-- silent = true: se registra solo en tu PC, sin avisos, sin puntos y sin contárselo a la guild
--                (es lo que ya cumplías al instalar o al sumarse logros nuevos).
-- by     = nombre del oficial que te lo dio (logros manuales).
function NS.UnlockAchievement(id, silent, by)
    local a = BY_ID[id]
    if not a or NS.db.achievements[id] then return false end
    local now = GetServerTime()
    NS.db.achievements[id] = now
    NS.Fire("ACHIEVEMENTS_UPDATED")
    if silent then return true end

    AddLogEntry(NS.me, id, now, by)         -- queda en el registro de la guild (y suma puntos)

    local pts = a.pts or 0
    NS.Toast(string.format("¡Logro desbloqueado!\n|cffffd100%s|r%s", a.name,
        pts > 0 and string.format("  |cff33ff33+%d pts|r", pts) or ""), 6, "logro")
    NS.PlaySound("logro")
    Print(string.format("Logro desbloqueado: |cffffd100%s|r — %s%s", a.name, a.desc,
        by and (" |cff888888(te lo dio " .. by .. ")|r") or ""))

    -- Se lo cuenta a la guild (los manuales ya los anunció el oficial al darlos)
    if not by and NS.db.achOpts.announce and IsInGuild() then
        NS.Send("GUILD", "LOGRO^" .. id .. "^" .. now, nil, true)
    end
    return true
end

-- Revisa los numéricos. Devuelve cuántos desbloqueó.
function NS.CheckAchievements(silent)
    local n = 0
    for _, a in ipairs(C.ACHIEVEMENTS) do
        if a.value and not NS.db.achievements[a.id] then
            local cur = NS.AchievementProgress(a)
            if cur and cur >= a.value and NS.UnlockAchievement(a.id, silent) then n = n + 1 end
        end
    end
    return n
end

-- Se agrupan los pedidos: si pasan muchas cosas juntas, se revisa una sola vez
local queued = false
local function ScheduleCheck()
    if queued then return end
    queued = true
    C_Timer.After(2, function()
        queued = false
        NS.CheckAchievements()
    end)
end

NS:On("PLAYER_LEVEL_UP", ScheduleCheck)
NS:On("SKILL_LINES_CHANGED", ScheduleCheck)       -- cambió una profesión
NS.RegisterCallback("STATS_UPDATED", ScheduleCheck)
NS.RegisterCallback("LEDGER_UPDATED", ScheduleCheck)   -- por si llegan puntos (logro "puntos de reconocimiento")
NS.RegisterCallback("ACHIEVEMENTS_UPDATED", ScheduleCheck)   -- por si llegás a "desbloqueá N logros"

-- Los de evento automáticos: el evento se llama igual que el logro
NS.RegisterCallback("GAME_EVENT", function(event)
    local a = BY_ID[event]
    if a and a.kind == "event" and not a.manual then NS.UnlockAchievement(event) end
end)

-- Si el que ganó la ruleta sos vos
NS.RegisterCallback("RULETA_DONE", function(d)
    if d and d.winner and NS.Short(d.winner) == NS.me then NS.UnlockAchievement("ruleta") end
end)

----------------------------------------------------------------
-- Logros que dependen de con quién jugás
----------------------------------------------------------------
local function GuildmatesInGroup()
    local n = 0
    for _, name in ipairs(NS.GetGroupNames()) do
        if NS.rosterInfo[NS.Short(name)] then n = n + 1 end
    end
    return n
end

local groupQueued = false
local function CheckGroup()
    groupQueued = false
    local inInstance, kind = IsInInstance()
    if not inInstance then return end
    if kind == "pvp" or kind == "arena" then
        NS.UnlockAchievement("bg_primero")
    elseif kind == "party" and not NS.db.achievements.mazmorra_legion then
        if GuildmatesInGroup() >= 3 then NS.UnlockAchievement("mazmorra_legion") end
    elseif kind == "raid" and not NS.db.achievements.raid_legion then
        if GuildmatesInGroup() >= 10 then NS.UnlockAchievement("raid_legion") end
    end
end

local function ScheduleGroup(delay)
    if groupQueued then return end
    groupQueued = true
    C_Timer.After(delay, CheckGroup)
end
NS:On("PLAYER_ENTERING_WORLD", function() ScheduleGroup(6) end)
NS:On("GROUP_ROSTER_UPDATE", function() ScheduleGroup(3) end)

----------------------------------------------------------------
-- Primera revisión (y cada vez que se suman logros nuevos): con calma, cuando ya cargó todo
----------------------------------------------------------------
NS.RegisterCallback("READY", function()
    IndexLog()
    C_Timer.After(15, function()
        local db = NS.db
        if db.achSet ~= C.ACH_VERSION then
            db.achSet = C.ACH_VERSION
            -- punto de partida: las muertes que ya tenías registradas cuentan
            local sum = 0
            for _, n in pairs(db.myDeaths) do sum = sum + n end
            if sum > (db.stats.deaths or 0) then db.stats.deaths = sum end
            -- En silencio (lo que ya cumplías no da puntos ni avisos). Se repite hasta que no aparezca nada nuevo,
            -- porque un logro puede depender de otros ("desbloqueá 10 logros").
            local n, got = 0, 0
            repeat
                got = NS.CheckAchievements(true)
                n = n + got
            until got == 0
            if n > 0 then
                Print(string.format("Se registraron |cffffd100%d|r logros que ya cumplías (sin puntos). Mirá todos con |cffffd100/asado logros|r.", n))
            end
        else
            NS.CheckAchievements()
        end
        -- Lo que dice el registro de la guild sobre vos: si te dio un logro un oficial mientras estabas desconectado,
        -- aparece con aviso; si son logros tuyos de antes (por ejemplo, reinstalaste), se restauran en silencio.
        for _, e in ipairs(db.achLog) do
            if e.who == NS.me and not db.achievements[e.id] and BY_ID[e.id] then
                NS.UnlockAchievement(e.id, e.by == nil, e.by)
            end
        end
    end)
end)

----------------------------------------------------------------
-- Mensajes entre miembros
--   LOGRO^id^ts            el dueño cuenta que desbloqueó uno (los manuales no se aceptan por acá)
--   GRANT^quién^id^ts^por  un oficial le da un logro manual a alguien
--   ALOG^quién^id^ts^por   sincronización: un desbloqueo que otro ya conocía
----------------------------------------------------------------
local function ValidTs(ts)
    local now = GetServerTime()
    return ts ~= nil and ts <= now + 60 and ts >= now - 500 * 86400
end

local lastSeen = {}
local function Hear(who, text)
    if not NS.db.achOpts.hear then return end
    local info = NS.rosterInfo[who]
    print(string.format("|cffffd100[Logro]|r %s %s", NS.ClassColored(who, info and info.class), text))
end

NS.Handle("LOGRO", function(sender, channel, id, ts)
    if channel ~= "GUILD" then return end
    local a = BY_ID[id]
    if not a or a.manual then return end                      -- los manuales solo los da un oficial
    local now = GetTime()
    if lastSeen[sender] and now - lastSeen[sender] < 3 then return end   -- anti-flood
    lastSeen[sender] = now
    ts = tonumber(ts)
    if not ValidTs(ts) then ts = GetServerTime() end
    if AddLogEntry(sender, id, ts) then
        Hear(sender, string.format("desbloqueó |cffffd100%s|r.", a.name))
    end
end)

NS.Handle("GRANT", function(sender, channel, who, id, ts, by)
    if channel ~= "GUILD" then return end
    local a = BY_ID[id]
    ts = tonumber(ts)
    if not (a and a.manual and who and who ~= "" and by and ValidTs(ts)) then return end
    who, by = NS.Short(who), NS.Short(by)
    if sender ~= by or who == by or not NS.IsOfficer(by) then return end   -- solo oficiales, en vivo, nunca a sí mismos
    if AddLogEntry(who, id, ts, by) then
        Hear(who, string.format("recibió |cffffd100%s|r (lo dio %s).", a.name, by))
    end
    if who == NS.me then NS.UnlockAchievement(id, false, by) end
end)

NS.Handle("ALOG", function(sender, channel, who, id, ts, by)
    local a = BY_ID[id]
    ts = tonumber(ts)
    if not (a and who and who ~= "" and ValidTs(ts)) then return end
    who = NS.Short(who)
    by = (by and by ~= "") and NS.Short(by) or nil
    if a.manual and not (by and by ~= who and NS.IsOfficer(by)) then return end
    AddLogEntry(who, id, ts, by)       -- el desbloqueo propio se aplica en la primera revisión / al llegar
    if who == NS.me and not NS.db.achievements[id] and NS.rosterReady then
        NS.UnlockAchievement(id, by == nil, by)     -- con aviso solo si te lo dio un oficial
    end
end)

----------------------------------------------------------------
-- Comandos
--   /asado logros                        abre la ventana de logros
--   /asado logros reset confirmar        borra TUS logros (solo en tu PC; los puntos ya registrados quedan)
--   /asado darlogro <id> <nombre...>     (GM y oficiales) le da un logro manual a esos jugadores
--   /asado darlogro <id> grupo           (GM y oficiales) se lo da a todos los de la guild de tu grupo
----------------------------------------------------------------
NS.commands.logros = function(rest)
    rest = (rest or ""):lower()
    if rest:match("^reset") then
        if rest == "reset confirmar" then
            wipe(NS.db.achievements)
            NS.db.achSet = 0
            NS.Fire("ACHIEVEMENTS_UPDATED")
            Print("Tus logros se borraron. Se vuelven a registrar los que ya cumplís en unos segundos (sin puntos nuevos).")
            C_Timer.After(3, function()
                local n, got = 0, 0
                repeat
                    got = NS.CheckAchievements(true)
                    n = n + got
                until got == 0
                NS.db.achSet = C.ACH_VERSION
                if n > 0 then Print(string.format("Se registraron %d logros que ya cumplías.", n)) end
            end)
        else
            Print("Esto borra TODOS tus logros en tu PC. Si querés seguir: |cffffd100/asado logros reset confirmar|r")
        end
        return
    end
    if NS.UI and NS.UI.Toggle then NS.UI.Toggle(9) end
end
NS.commands.logro = NS.commands.logros

local function ManualList()
    local ids = {}
    for _, a in ipairs(C.ACHIEVEMENTS) do
        if a.manual then ids[#ids + 1] = a.id end
    end
    return table.concat(ids, ", ")
end

NS.commands.darlogro = function(rest)
    if not NS.RequireOfficer("dar logros") then return end
    local id, names = (rest or ""):match("^(%S+)%s*(.*)$")
    if not id then
        Print("Uso: |cffffd100/asado darlogro <id> <nombre> [nombre...]|r  o  |cffffd100/asado darlogro <id> grupo|r")
        Print("Logros que se dan a mano: " .. ManualList())
        return
    end
    id = id:lower()
    local a = BY_ID[id]
    if not (a and a.manual) then
        Print("\"" .. id .. "\" no es un logro que se dé a mano. Los que sí: " .. ManualList())
        return
    end

    local targets, seen = {}, {}
    local function Add(name)
        name = NS.Short(name)
        if name == "" or seen[name] then return end
        seen[name] = true
        targets[#targets + 1] = name
    end
    for word in names:gmatch("%S+") do
        if word:lower() == "grupo" then
            for _, n in ipairs(NS.GetGroupNames()) do Add(n) end
        else
            Add(word)
        end
    end
    if #targets == 0 then Print("¿A quién? Escribí un nombre, o |cffffd100grupo|r para tu grupo."); return end
    if #targets > 40 then Print("Máximo 40 jugadores por vez."); return end

    local list, skipped = {}, {}
    for _, who in ipairs(targets) do
        if who == NS.me then
            skipped[#skipped + 1] = who .. " (no te lo podés dar vos)"
        elseif not NS.rosterInfo[who] then
            skipped[#skipped + 1] = who .. " (no está en la guild)"
        elseif logIndex[LogKey(who, id)] then
            skipped[#skipped + 1] = who .. " (ya lo tiene)"
        else
            list[#list + 1] = who
        end
    end
    if #skipped > 0 then Print("Salteados: " .. table.concat(skipped, ", ")) end
    if #list == 0 then return end

    -- Se manda de a uno, con una pausa, para no saturar el canal
    local i, given = 1, 0
    local function step()
        local who = list[i]
        if not who then
            Print(string.format("Listo: |cffffd100%s|r se lo diste a %d jugadores (+%d pts c/u).", a.name, given, a.pts or 0))
            return
        end
        local ts = GetServerTime()
        if not NS.Send("GUILD", table.concat({ "GRANT", who, id, ts, NS.me }, "^"), nil, true) then
            Print("No se pudo seguir enviando (¿pelea de jefe?). Faltaron: " .. table.concat(list, ", ", i))
            return
        end
        AddLogEntry(who, id, ts, NS.me)
        given = given + 1
        i = i + 1
        C_Timer.After(0.4, step)
    end
    step()
end
NS.commands.otorgarlogro = NS.commands.darlogro
