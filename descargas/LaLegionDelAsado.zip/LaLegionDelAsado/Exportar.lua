--[[
    La Legión del Asado - Exportar.lua
    Arma el archivo de RANKINGS para la web y guarda el ARCHIVO MENSUAL con los ganadores.

      /asado exportar          (GM y oficiales) genera el archivo con todos los rankings de hoy
      /asado exportar copiar   (GM y oficiales) además abre una ventana con el texto para copiarlo (Ctrl+C)
      /asado exportar reload   (GM y oficiales) genera el archivo y recarga la interfaz para guardarlo ya
      /asado archivo           (cualquiera) muestra en el chat los ganadores de los últimos meses

    IMPORTANTE: un addon de WoW no puede escribir archivos sueltos ni subir nada a internet. Lo que sí hace
    el juego es guardar los datos del addon en un archivo (SavedVariables) cuando cerrás sesión o hacés /reload.
    El addon deja el JSON listo ahí adentro:

        World of Warcraft\<carpeta del juego>\WTF\Account\<TU CUENTA>\SavedVariables\LaLegionDelAsado.lua

    Después, la herramienta herramientas/exportar_rankings.py lo saca de ese archivo y genera rankings.json,
    que es lo que lee la página de rankings de la web.

    ARCHIVO MENSUAL: al terminar cada mes se guarda un resumen (db.archive) con los primeros puestos de cada
    ranking y sus ganadores. Ese resumen ya no cambia, y viaja dentro del archivo de la web.
]]
local ADDON, NS = ...
local C = NS.C
local Print = NS.Print

----------------------------------------------------------------
-- JSON (solo ASCII: los acentos van como \uXXXX, así el archivo se lee igual en cualquier parte)
----------------------------------------------------------------
local function JsonStr(s)
    s = tostring(s)
    local out, i, n = {}, 1, #s
    while i <= n do
        local b = s:byte(i)
        if b < 0x80 then
            local ch = string.char(b)
            if ch == '"' then out[#out + 1] = '\\"'
            elseif ch == "\\" then out[#out + 1] = "\\\\"
            elseif b < 0x20 then out[#out + 1] = string.format("\\u%04x", b)
            else out[#out + 1] = ch end
            i = i + 1
        else
            local cp, len
            if b >= 0xF0 then cp, len = b % 8, 4
            elseif b >= 0xE0 then cp, len = b % 16, 3
            elseif b >= 0xC0 then cp, len = b % 32, 2
            else cp, len = 0xFFFD, 1 end                        -- byte suelto inválido
            if len > 1 then
                for k = 1, len - 1 do
                    local c = s:byte(i + k)
                    if not c or c < 0x80 or c > 0xBF then cp, len = 0xFFFD, 1; break end
                    cp = cp * 64 + (c % 64)
                end
            end
            if cp >= 0x10000 then                               -- fuera del plano básico: par sustituto
                cp = cp - 0x10000
                out[#out + 1] = string.format("\\u%04x\\u%04x", 0xD800 + math.floor(cp / 1024), 0xDC00 + cp % 1024)
            else
                out[#out + 1] = string.format("\\u%04x", cp)
            end
            i = i + len
        end
    end
    return '"' .. table.concat(out) .. '"'
end

local function IsArray(t)
    local n = 0
    for k in pairs(t) do
        if type(k) ~= "number" then return false end
        n = n + 1
    end
    return n == #t        -- una tabla vacía cuenta como lista
end

local function ToJSON(v)
    local t = type(v)
    if t == "table" then
        if IsArray(v) then
            local parts = {}
            for i = 1, #v do parts[i] = ToJSON(v[i]) end
            return "[" .. table.concat(parts, ",") .. "]"
        end
        local keys = {}
        for k in pairs(v) do keys[#keys + 1] = k end
        table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
        local parts = {}
        for _, k in ipairs(keys) do parts[#parts + 1] = JsonStr(k) .. ":" .. ToJSON(v[k]) end
        return "{" .. table.concat(parts, ",") .. "}"
    elseif t == "number" then
        if v ~= v or v == math.huge or v == -math.huge then return "null" end
        if v == math.floor(v) then return string.format("%d", v) end
        return string.format("%.3f", v)
    elseif t == "boolean" then
        return v and "true" or "false"
    elseif t == "nil" then
        return "null"
    end
    return JsonStr(v)
end
NS.ToJSON = ToJSON

----------------------------------------------------------------
-- Archivo mensual
----------------------------------------------------------------
-- Guarda el resumen de un mes ("2026-10") con sus primeros puestos. Devuelve true si guardó uno nuevo.
function NS.ArchiveMonth(pk, force)
    local db = NS.db
    if db.archive[pk] and not force then return false end
    local top = C.ARCHIVE_TOP

    local function Rank(t, field)
        local out = {}
        for i, e in ipairs(NS.TopN(t, top)) do
            out[i] = { name = e.name }
            out[i][field] = e.v
        end
        return out
    end

    local ach = {}
    for name, r in pairs(NS.AchPointsByPlayer(pk)) do
        if r.month > 0 then ach[name] = r.month end
    end
    local entry = {
        month = pk,
        asador = Rank(NS.PointsForMonth(pk), "points"),
        pollo = Rank(db.deaths[pk] or {}, "deaths"),
        carnicero = Rank(db.pvp[pk] or {}, "kills"),
        logros = Rank(ach, "points"),
        archivedAt = GetServerTime(),
    }
    if #entry.asador + #entry.pollo + #entry.carnicero + #entry.logros == 0 then return false end   -- mes sin datos
    db.archive[pk] = entry
    NS.Fire("ARCHIVE_UPDATED")
    return true
end

-- Archiva los meses anteriores que tengan datos y todavía no estén guardados. Devuelve cuántos.
function NS.ArchiveMissingMonths()
    local db, cur = NS.db, NS.MonthKey()
    local months = {}
    for mk in pairs(db.deaths) do months[mk] = true end
    for mk in pairs(db.pvp) do months[mk] = true end
    for _, e in ipairs(db.ledger) do months[e.mk or date("%Y-%m", e.ts)] = true end
    for _, e in ipairs(db.achLog) do months[e.mk or date("%Y-%m", e.ts)] = true end
    local n = 0
    for mk in pairs(months) do
        if mk < cur and not db.archive[mk] and NS.ArchiveMonth(mk) then n = n + 1 end
    end
    return n
end

-- Meses archivados, el más nuevo primero
function NS.GetArchiveList()
    local list = {}
    for _, a in pairs(NS.db.archive) do list[#list + 1] = a end
    table.sort(list, function(a, b) return a.month > b.month end)
    return list
end

----------------------------------------------------------------
-- Armar el archivo de la web
----------------------------------------------------------------
function NS.BuildExport()
    local db = NS.db
    local top = C.EXPORT_TOP
    local mk = NS.MonthKey()
    local all, month = NS.ComputeTotals()

    local function ClassOf(name)
        local i = NS.rosterInfo[name]
        return i and i.class or ""
    end
    local function List(t, field, n, extra)
        local out = {}
        for i, e in ipairs(NS.TopN(t, n)) do
            local row = { name = e.name, class = ClassOf(e.name) }
            row[field] = e.v
            if extra then extra(row) end
            out[i] = row
        end
        return out
    end

    local levels = {}
    for i, e in ipairs(NS.LevelRanking(top)) do
        levels[i] = { name = e.name, class = ClassOf(e.name), level = e.l }
    end

    local ach = {}
    for name, r in pairs(NS.AchPointsByPlayer()) do
        ach[#ach + 1] = { name = name, class = ClassOf(name), count = r.count, points = r.total, month = r.month }
    end
    table.sort(ach, function(a, b)
        if a.count ~= b.count then return a.count > b.count end
        if a.points ~= b.points then return a.points > b.points end
        return a.name < b.name
    end)
    while #ach > top do table.remove(ach) end

    local firsts = {}
    for _, lvl in ipairs(C.LEVEL_MILESTONES) do
        local f = db.firsts[lvl]
        if f then firsts[#firsts + 1] = { level = lvl, name = f.name, class = ClassOf(f.name), ts = f.ts } end
    end

    local deaths, log = {}, db.deathLog
    for i = #log, math.max(1, #log - 14), -1 do
        local e = log[i]
        deaths[#deaths + 1] = { name = e.name, class = e.class or "", level = e.lvl or 0, zone = e.zone or "",
            sub = e.sub or "", pvp = e.pvp and true or false, ts = e.ts }
    end

    NS.ArchiveMissingMonths()

    return {
        schema = 1,
        guild = C.GUILD_NAME,
        generated = GetServerTime(),
        generatedBy = NS.me,
        addonVersion = NS.version,
        month = mk,
        rankings = {
            asador = List(month, "points", top),
            rangos = List(all, "points", top, function(row) row.rank = (NS.GetRank(row.points)) end),
            pollo = List(db.deaths[mk] or {}, "deaths", top),
            carnicero = List(db.pvp[mk] or {}, "kills", top),
            niveles = levels,
            logros = ach,
        },
        primeros = firsts,
        ultimasMuertes = deaths,
        archivo = NS.GetArchiveList(),
    }
end

----------------------------------------------------------------
-- Ventana para copiar el texto (Ctrl+C)
----------------------------------------------------------------
local win

local function ShowCopyWindow(text)
    local ok = pcall(function()
        if not win then
            win = CreateFrame("Frame", "LegionAsadoExport", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
            win:SetSize(540, 320)
            win:SetPoint("CENTER")
            win:SetFrameStrata("DIALOG")
            win:SetBackdrop({
                bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                tile = true, tileSize = 16, edgeSize = 16,
                insets = { left = 4, right = 4, top = 4, bottom = 4 },
            })
            win:SetBackdropColor(0.12, 0.07, 0.04, 0.97)
            win:SetBackdropBorderColor(C.CELESTE[1], C.CELESTE[2], C.CELESTE[3], 1)
            win:SetMovable(true)
            win:EnableMouse(true)
            win:RegisterForDrag("LeftButton")
            win:SetScript("OnDragStart", win.StartMoving)
            win:SetScript("OnDragStop", win.StopMovingOrSizing)
            table.insert(UISpecialFrames, "LegionAsadoExport")

            local title = win:CreateFontString(nil, "ARTWORK", "GameFontNormal")
            title:SetPoint("TOPLEFT", 16, -14)
            title:SetText("Rankings para la web  |cff888888(el texto ya está seleccionado: Ctrl+C)|r")
            local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
            close:SetPoint("TOPRIGHT", -2, -2)

            local sf = CreateFrame("ScrollFrame", "LegionAsadoExportScroll", win, "UIPanelScrollFrameTemplate")
            sf:SetPoint("TOPLEFT", 16, -40)
            sf:SetPoint("BOTTOMRIGHT", -34, 16)
            local eb = CreateFrame("EditBox", nil, sf)
            eb:SetMultiLine(true)
            eb:SetFontObject(ChatFontNormal)
            eb:SetWidth(480)
            eb:SetAutoFocus(false)
            eb:SetScript("OnEscapePressed", function(self) self:ClearFocus(); win:Hide() end)
            sf:SetScrollChild(eb)
            win.eb = eb
        end
        win.eb:SetText(text)
        win.eb:HighlightText()
        win:Show()
        win.eb:SetFocus()
    end)
    if not ok then Print("No pude abrir la ventana de copia en este cliente. Usá /reload y el archivo SavedVariables.") end
end

----------------------------------------------------------------
-- Comandos
----------------------------------------------------------------
NS.commands.exportar = function(rest)
    if not NS.RequireOfficer("exportar los rankings") then return end
    rest = (rest or ""):lower()

    local json = ToJSON(NS.BuildExport())
    NS.db.export = { json = json, generated = GetServerTime(), by = NS.me, bytes = #json }
    NS.Fire("ARCHIVE_UPDATED")
    Print(string.format("Archivo de rankings generado (|cffffd100%.1f KB|r) con los datos que tu addon conoce ahora.", #json / 1024))

    if rest == "copiar" then
        ShowCopyWindow(json)
    elseif rest == "reload" then
        Print("Recargando para guardarlo en el disco...")
        C_Timer.After(0.5, function() ReloadUI() end)
    else
        Print("Se guarda en el disco al cerrar sesión o con |cffffd100/reload|r. Después corré |cffffd100herramientas/exportar_rankings.py|r " ..
            "y subí el rankings.json a la web. Tip: |cffffd100/asado sync|r antes de exportar, para tener todo al día.")
    end
end

local function Winner(list, field)
    local e = list and list[1]
    return e and string.format("%s (%d)", e.name, e[field] or 0) or "-"
end

NS.commands.archivo = function()
    NS.ArchiveMissingMonths()
    local list = NS.GetArchiveList()
    if #list == 0 then Print("Todavía no hay meses archivados."); return end
    Print("Ganadores de los últimos meses:")
    for i = 1, math.min(6, #list) do
        local a = list[i]
        print(string.format("  |cffffd100%s|r  Asador: %s  ·  Pollo: %s  ·  Carnicero: %s",
            a.month, Winner(a.asador, "points"), Winner(a.pollo, "deaths"), Winner(a.carnicero, "kills")))
    end
end
