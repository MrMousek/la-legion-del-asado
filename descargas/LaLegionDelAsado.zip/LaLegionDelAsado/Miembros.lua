--[[
    La Legión del Asado - Miembros.lua
    "¿Quién tiene el addon y con qué versión?" Cada jugador avisa su versión por el canal de la guild
    (junto con la sincronización de siempre) y cualquiera puede ver la lista en la pestaña "Addon".

    Sirve para decirle a alguien "che, actualizá, estás con una versión vieja" o "bajate el addon, no lo tenés".
    El addon NUNCA manda nada solo: al hacer click en un nombre se abre el susurro con un mensaje sugerido
    y vos decidís si lo enviás.
]]
local ADDON, NS = ...
local C = NS.C

local TOC = tonumber((select(4, GetBuildInfo()))) or 0

----------------------------------------------------------------
-- Versiones
----------------------------------------------------------------
-- "0.9.2" o "0.9.2-beta1" -> { 0, 9, 2 }   (el sufijo -beta se ignora)
local function Parse(v)
    local a, b, c = tostring(v or ""):match("^(%d+)%.(%d+)%.?(%d*)")
    if not a then return nil end
    return { tonumber(a), tonumber(b), tonumber(c) or 0 }
end

-- -1 si a < b · 0 si son iguales · 1 si a > b · nil si alguna no se entiende
function NS.CompareVersions(a, b)
    local pa, pb = Parse(a), Parse(b)
    if not (pa and pb) then return nil end
    for i = 1, 3 do
        if pa[i] ~= pb[i] then return pa[i] < pb[i] and -1 or 1 end
    end
    return 0
end

-- La versión más nueva que se vio en la guild (incluida la mía)
function NS.LatestVersion()
    local best = NS.version
    for _, m in pairs(NS.db.members) do
        if m.v and (NS.CompareVersions(m.v, best) or 0) > 0 then best = m.v end
    end
    return best
end

-- Forever o Retail, según el número de interfaz del cliente de cada uno
function NS.FlavorOf(toc)
    toc = tonumber(toc) or 0
    if toc >= 16000 and toc < 17000 then return "Forever" end
    if toc >= 100000 then return "Retail" end
    return nil
end

----------------------------------------------------------------
-- Comunicación
----------------------------------------------------------------
local lastSent, lastAsked = -1000, -1000

-- "Estoy usando la versión X". Como mucho una vez cada 20 segundos.
function NS.SendVersion()
    if not IsInGuild() then return end
    local now = GetTime()
    if now - lastSent < 20 then return end
    lastSent = now
    NS.Send("GUILD", table.concat({ "VER", NS.version or "?", TOC }, "^"), nil, true)
end

-- "¿Qué versión tienen todos?" Como mucho una vez cada 30 segundos.
function NS.RequestVersions()
    if not IsInGuild() then return end
    local now = GetTime()
    if now - lastAsked < 30 then return end
    lastAsked = now
    NS.Send("GUILD", "VERQ", nil, true)
    NS.SendVersion()
end

NS.Handle("VER", function(sender, channel, ver, toc)
    if channel ~= "GUILD" then return end
    if type(ver) ~= "string" or #ver > 24 or not ver:match("^[%w%.%-]+$") then return end
    NS.db.members[sender] = { v = ver, f = tonumber(toc) or 0, t = GetServerTime() }
    NS.Fire("MEMBERS_UPDATED")
end)

-- Alguien pregunta: cada uno responde en un momento al azar para no mandar todos juntos
NS.Handle("VERQ", function()
    C_Timer.After(1 + math.random() * 7, NS.SendVersion)
end)

----------------------------------------------------------------
-- Lista para la pestaña "Addon"
----------------------------------------------------------------
-- filter: "all" | "old" | "none" · onlineOnly: solo los conectados
-- Devuelve: filas, estadísticas, última versión vista
function NS.GetMemberList(filter, onlineOnly)
    local latest = NS.LatestVersion()
    local rows = {}
    local stats = { addon = 0, old = 0, none = 0, noneOnline = 0 }

    for name, info in pairs(NS.rosterInfo) do
        local rec = (name == NS.me) and { v = NS.version, f = TOC, t = GetServerTime() } or NS.db.members[name]
        local status
        if not rec then
            status = "none"
            stats.none = stats.none + 1
            if info.online then stats.noneOnline = stats.noneOnline + 1 end
        else
            stats.addon = stats.addon + 1
            if (NS.CompareVersions(rec.v, latest) or 0) < 0 then
                status = "old"
                stats.old = stats.old + 1
            else
                status = "ok"
            end
        end
        if (not onlineOnly or info.online) and (filter == "all" or filter == status) then
            rows[#rows + 1] = { name = name, class = info.class, online = info.online, status = status,
                ver = rec and rec.v, toc = rec and rec.f, seen = rec and rec.t }
        end
    end

    -- Primero los conectados; entre ellos, los que hay que avisar (vieja, sin addon) antes que los que están al día
    local prio = { old = 1, none = 2, ok = 3 }
    table.sort(rows, function(a, b)
        if a.online ~= b.online then return a.online end
        if a.status ~= b.status then return prio[a.status] < prio[b.status] end
        return a.name < b.name
    end)
    return rows, stats, latest
end

-- Abre el susurro con un mensaje sugerido (no se envía solo: apretás Enter si querés)
function NS.SuggestWhisper(row)
    if not row or row.name == NS.me then return end
    local text = ""
    if row.status == "old" then
        text = string.format("Che, actualizá el addon de la guild: tenés la %s y ya está la %s. Bajala en %s",
            row.ver or "?", NS.LatestVersion(), C.ADDON_PAGE)
    elseif row.status == "none" then
        text = string.format("Che, bajate el addon de la guild (rankings, avisos, ruleta y más): %s", C.ADDON_PAGE)
    end
    if ChatFrame_OpenChat then
        ChatFrame_OpenChat("/w " .. row.name .. " " .. text)
    end
end

-- /asado quien · /asado versiones -> abre la pestaña
local function Open() if NS.UI and NS.UI.Toggle then NS.UI.Toggle(7) end end
NS.commands.quien = Open
NS.commands.versiones = Open
