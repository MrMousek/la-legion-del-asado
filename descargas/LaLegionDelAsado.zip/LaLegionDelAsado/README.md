# 🔥 La Legión del Asado — Addon oficial

El addon de la guild **La Legión del Asado**, comunidad argentina de World of Warcraft.
Parrilla de guild, ruleta del fernet, puntos y rangos propios, avisos de muertes, niveles y PvP,
compañeros cerca en el mapa, el Himno Nacional y mucha mística de barrio. 🇦🇷

- 🌐 Web: https://lalegiondelasado.com/
- 💬 Discord: https://discord.gg/RsEyM5frhT

**Versión 0.11.1** · Hecho para **WoW: Forever (1.60.1)** · También funciona en Retail

---

## 📥 Instalación

1. Descargá el ZIP y descomprimilo.
2. Copiá la carpeta **`LaLegionDelAsado`** dentro de la carpeta de addons de tu juego:

   | Cliente | Ruta |
   |---|---|
   | **WoW: Forever** | `World of Warcraft\_classic_beta_\Interface\AddOns\` (puede cambiar al lanzamiento) |
   | Retail | `World of Warcraft\_retail_\Interface\AddOns\` |

   > Si no encontrás la carpeta, abrí el juego desde Battle.net y usá **Opciones → Mostrar en el explorador**.

3. Verificá que quede así (sin carpetas dobles):

   ```
   AddOns\
   └── LaLegionDelAsado\
       ├── LaLegionDelAsado.toc
       ├── Config.lua · Core.lua · Ubicacion.lua · AlertasPvP.lua · Himno.lua · Miembros.lua
       ├── UI.lua · Indicador.lua · MapaPins.lua
       ├── Media\   (logo y bandera)
       └── Sounds\
   ```

4. **Cerrá el juego por completo** y volvé a abrirlo (con `/reload` no alcanza para addons nuevos).
5. En el juego escribí **`/asado`** o hacé click en el botón del minimapa. 🔥

**Para actualizar:** reemplazá la carpeta `LaLegionDelAsado` por la nueva. Tus datos y opciones se conservan.

---

## 🥩 Qué trae

| | |
|---|---|
| **La Parrilla** | Mensaje del día de la guild, links a la web y al Discord (click, Ctrl+C), tu rango y los compañeros cerca. |
| **Ranking** | *El Asador del Mes* (puntos que dan los oficiales **más los de tus logros**, que se ganan solos) y *El Pollo del Mes* (el que más se murió). Se reinician cada mes y cada mes queda **archivado con sus ganadores**. |
| **Ruleta del Fernet** | Sorteo animado para repartir lo que haga falta. Cada jugador puede usarla una vez cada 5 minutos. Todos los de tu grupo que tengan el addon ven el mismo resultado. |
| **Niveles** | *La Carrera* de niveles de la guild y *Los Primeros* en llegar a cada hito: "¡Pepito llegó a nivel 30 y es el primero de la guild!". |
| **PvP** | *El Carnicero del Mes* (bajas honorables), primera sangre del mes e hitos. Neutral a la facción. |
| **Pedir ayuda en PvP** | Para los servidores JcJ: con `/asado sos` avisás a toda la guild que te están gankeando (aviso con alarma, tu ubicación y una **marca roja en el mapa**), y con `/asado reunion` armás una **zona de reunión** en mundo abierto (marca dorada). Con `/asado ir` marcás el lugar en tu mapa. También hay botones en la pestaña PvP. |
| **Compañeros cerca** | *Viene activado en las instalaciones nuevas y lo apagás cuando quieras (`/asado ubicacion off`).* Los que comparten su ubicación aparecen **en el mapa del mundo**, en la Parrilla y en un **indicador chiquito** junto al minimapa (una banderita con un número) que solo se ve cuando hay alguien cerca. |
| **Himno Nacional** | **Suena solo todos los días a las 00:00, hora argentina**, como en las radios, con un aviso 5 minutos antes. Además, el GM o un oficial puede ponerlo cuando quiera con `/asado himno`. Suena por encima de cualquier otro sonido y se corta con un botón o con `/asado himno stop`. 🇦🇷 |
| **Logros** | 54 logros personales de la Legión, agrupados por categoría (nivel, oficios, PvP, aventura, social, humor y eventos): "Perfecto, perfecto, caballero", "Pollo oficial", "Fundador de la Legión"... Muestran tu progreso, avisan cuando los conseguís, **suman puntos** para el Asador del Mes y se pueden contar a la guild. |
| **Quién tiene el addon** | Sección **Herramientas > Addon**: la lista de la guild con quién lo tiene, qué versión usa y quién todavía no lo bajó. Con un click en un nombre se abre un susurro con un mensaje sugerido ("che, actualizá..."). La puede ver cualquiera. |
| **Avisos de la guild** | Muertes (quién, nivel, dónde y cuántas veces en el mes), niveles, puntos y PvP. En pantalla y en el chat. |
| **Historial de muertes** | Las últimas 300 muertes de la guild: quién, nivel, dónde y cuándo. Se sincroniza entre los que tienen el addon. |
| **Locutor del Barrio** | Sonidos para muertes, wipes, bosses, loot épico, subir de nivel y **comerciar** (¡perfecto, caballero!). Varios eventos tienen **variantes** que suenan al azar. Se pueden reemplazar por los tuyos. |
| **Dragón del retrato** | *Opcional, viene apagado.* Dorado (élite) o plateado (raro) alrededor de tu retrato. Se activa con `/asado dragon oro` o `plata`. |

Todo lo que te avisa se puede **apagar desde la pestaña Opciones y desde la Parrilla**.

### Cómo está organizada la ventana (`/asado`)

| Pestaña | Qué hay |
|---|---|
| **Inicio** | La Parrilla: mensaje del día, links, tu rango y los compañeros cerca. |
| **Rankings** | Del mes (Asador y Pollo) · Niveles · PvP (con el pedido de ayuda) · Muertes · Historial (ganadores de cada mes). |
| **Logros** | Un resumen y una sección por categoría, con todos los logros y tu progreso. |
| **Herramientas** | Ruleta · Addon (quién lo tiene y con qué versión). |
| **Opciones** | Todo lo que se puede prender y apagar. |

---

## ⌨️ Comandos

| Comando | Qué hace |
|---|---|
| `/asado` | Abre la Parrilla |
| `/asado ranking` · `niveles` · `pvp` · `muertes` · `ruleta` · `cerca` · `logros` | Abre esa sección de la ventana |
| `/asado ubicacion on` · `off` | Compartir (o dejar de compartir) tu ubicación con la guild |
| `/asado cerca reset` | Devuelve el indicador de cercanía a su lugar (se mueve con Shift + arrastrar) |
| `/asado sos [mensaje]` | Pide ayuda a la guild (aviso, alarma y marca roja en el mapa). Espera 20 s entre un aviso y otro |
| `/asado reunion [mensaje]` | Avisa una zona de reunión PvP en mundo abierto (marca dorada durante 10 minutos) |
| `/asado ir` | Marca en tu mapa la última alerta de ayuda o reunión |
| `/asado himno stop` | Corta el himno (solo para vos). También está el botón "Detener himno" mientras suena |
| `/asado himno hora` | Muestra la hora argentina, la del reino y la de tu PC, y cuánto falta para el próximo himno |
| `/asado quien` | Abre la lista de quién tiene el addon y con qué versión |
| `/asado logros reset confirmar` | Borra TUS logros en tu PC (los puntos ya registrados quedan) |
| `/asado archivo` | Muestra los ganadores de los últimos meses |
| `/asado mapa` | Datos para diagnosticar las marcas del mapa del mundo |
| `/asado dragon oro` · `plata` · `off` | Cambia el dragón del retrato |
| `/asado dragon escala N` · `x N` · `y N` · `invertir` · `reset` | Ajusta posición y tamaño del dragón |
| `/asado sonido <nombre> [variante]` · `todos` | Prueba un sonido, una variante puntual o todos (lo puede usar cualquiera) |
| `/asado sync` | Sincroniza con la guild ahora mismo |
| `/asado diag` | Muestra qué funciones soporta tu cliente (útil para reportar errores) |
| `/asado perf` | Mide cuánta memoria y CPU usa el addon |
| `/asado ayuda` | Lista de comandos |

**Solo GM y oficiales**

| Comando | Qué hace |
|---|---|
| `/asado himno` | Reproduce el Himno Nacional para toda la guild (cuenta regresiva de 3 segundos) |
| `/asado puntos <nombre> <n> [motivo]` | Da (o quita) puntos, de -100 a 100 |
| `/asado lista [puntos] [motivo]` | Pase de lista: suma puntos (5 por defecto) a todos los de la guild que estén en tu grupo |
| `/asado darlogro <id> <nombre...>` | Da un logro **de evento** (los que dice "oficial") a esos jugadores. Con `grupo` se lo da a todos los de la guild que estén en tu grupo |
| `/asado exportar` · `copiar` · `reload` | Genera el archivo de rankings para la web (ver abajo) |
| `/asado reset muertes` · `historial` · `pvp` · `niveles` | Reinicia un contador para **toda la guild** (pide confirmar con `confirmar`) |
| `/asado test ...` | Pruebas locales (simulan compañeros, muertes y ubicaciones); `test limpiar` las borra |

---

## 🛡️ Para oficiales

- Quién puede dar puntos, reiniciar contadores y poner el himno lo define `OFFICER_MAX_RANK_INDEX` en `Config.lua` (0 = GM, 1 = rango siguiente, etc.). `/asado diag` te muestra tu rango.
- Los puntos son **solo reconocimiento**. *Asador* y *Pollo* se reinician cada mes; los rangos usan el acumulado histórico:
  Pinche → Carbonero → Parrillero → Asador → Maestro Asador → Leyenda del Quincho.
- Conviene que pase lista **un solo oficial** por evento para no duplicar puntos.
- El himno manual tiene un enfriamiento de 5 minutos y se acepta solo si lo manda, en vivo, el GM o un oficial.
- El himno de las 00:00 no depende de nadie: cada addon lo calcula solo con el reloj del servidor pasado a hora argentina (UTC-3 fija, sin horario de verano). Cada uno puede apagarlo en Opciones.

---

## 🔊 Sonidos

Los sonidos de la guild **vienen incluidos** en el addon (con varias variantes por evento, el sonido de comercio y el himno completo).
Si tenés una versión vieja que no los traía, bajá el **pack de sonidos** de
https://lalegiondelasado.com/pages/addon.html y descomprimilo dentro de `AddOns\` (se funde con la carpeta del addon).

- Los nombres y las variantes están en `Sounds\LEEME.txt` (`muerte.ogg`, `muerte_2.ogg`, `muerte_3.ogg`...). Para cambiar uno, reemplazá el archivo por otro `.ogg` con el mismo nombre y reiniciá el juego. Si falta una variante, el addon usa las otras.
- **El himno** es `Sounds\himno.ogg` (la versión completa, de 4 minutos). Si cambiás el archivo y dura distinto, ajustá `HIMNO_SECONDS` en `Config.lua`.
- Para que no molesten: no suenan en peleas de jefe (se cambia en Opciones), un sonido no pisa a otro que está sonando
  salvo que sea más importante, y las muertes de compañeros suenan como máximo una vez cada 8 segundos.

---

## 🏆 Logros y puntos

- Cada logro vale puntos de reconocimiento (están en `Config.lua`, `ACHIEVEMENTS`, y se pueden ajustar). Se ganan **solos** y suman al **Asador del Mes** y a tu rango, junto con los que dan los oficiales con `/asado puntos`.
- Los logros **de evento** (Gorditos Laneros, Fundador de la Legión, Jugador del evento...) los da el GM o un oficial con `/asado darlogro`. Nadie se los puede dar a sí mismo.
- Lo que ya cumplías al instalar (o cuando se suman logros nuevos) se registra **una sola vez y en silencio, sin puntos**, para que no haya ventaja por llegar tarde ni una lluvia de avisos.
- Los logros se anotan en un registro compartido que se sincroniza entre los que tienen el addon, como los puntos de los oficiales. Es un sistema de confianza: está pensado para una guild entre amigos.

## 🌐 Rankings en la web

Un addon de WoW no puede subir archivos a internet, pero sí dejar los datos listos. El GM o un oficial hace, **una vez por día**:

1. En el juego: `/asado sync` y después `/asado exportar reload`.
2. En su PC: `python herramientas/exportar_rankings.py` (genera `rankings.json`).
3. Sube ese `rankings.json` a la carpeta `data/` de la web. La página **Rankings** lo muestra: Asador, Pollo, Carnicero, niveles, logros, rangos, Los Primeros, últimas muertes y el historial de cada mes.

El archivo refleja lo que el addon del que exporta conoce en ese momento, por eso conviene hacer `/asado sync` antes.

## 🔒 Qué se comparte

El addon **no se conecta a internet**. Entre los miembros de la guild que lo tengan instalado se comparte,
por el canal interno del juego: nivel, muertes (con la zona), bajas PvP y puntos. Nada más.
Solo cuenta lo que pasa **con el addon instalado**.

**Ubicación:** en las instalaciones nuevas viene **activada**, y la apagás cuando quieras con `/asado ubicacion off` (o desde la Parrilla).
Si ya usabas el addon y la tenías apagada, sigue apagada. La ven únicamente los de tu guild que tengan el addon,
vive en la memoria del juego (nunca se guarda en el disco), no se envía dentro de instancias y desaparece de la lista a los 40 segundos
de no actualizarse.

**Sincronización:** los datos se actualizan solos cuando te conectás y en cada pantalla de carga
(cambio de zona, instancias), como máximo una vez por minuto. Si no querés, se apaga en Opciones.

---

## ❓ Preguntas frecuentes

**No me aparece en la lista de addons.**
Revisá la ruta (¡la carpeta correcta para tu juego!), que no haya una carpeta doble y que hayas reiniciado el juego. Tildá "Cargar addons desactualizados" si hace falta.

**No veo el logo o la bandera, o veo un cuadrado.**
Reiniciá el juego por completo: las imágenes nuevas no se cargan con `/reload`.

**No veo a nadie en el mapa.**
Tienen que haber activado "Compartir mi ubicación" y estar en la misma zona que estás mirando. Probá con `/asado test ubicacion` (oficiales) para ver cómo se ve.

**¿A qué hora suena el himno automático?**
Todos los días a las 00:00 hora argentina, sin importar la hora de tu PC ni la del reino. Con `/asado himno hora` ves qué hora calcula el addon. Si estás en una pelea de jefe, se saltea.

**No se escucha el himno.**
Revisá que tengas los sonidos y el himno activados en Opciones, que no estés en una pelea de jefe, y que exista `Sounds\himno.ogg`.

**No me aparece el dragón plateado.**
Corré `/asado dragon atlas` y pasanos lo que te muestre por el Discord.

**¿Por qué no dice quién me mató?**
Porque en estos clientes el registro de combate está cerrado a los addons.

**Me tira un error.**
Activá los errores con `/console scriptErrors 1`, repetí lo que hacías y pasanos el mensaje por el Discord. Si tenés BugSack, mejor.

---

## 🧩 Estructura del código

| Archivo | Qué hace |
|---|---|
| `Config.lua` | Constantes de la guild (links, rangos, frases, radios) y opciones por defecto. **Es el que se edita.** |
| `Core.lua` | Eventos, comunicación entre miembros, puntos, muertes, niveles, PvP, sonidos y comandos. |
| `Ubicacion.lua` | Compartir y recibir ubicaciones, distancias y aviso de cercanía. |
| `AlertasPvP.lua` | Pedidos de ayuda y zonas de reunión para el PvP en mundo abierto. |
| `Himno.lua` | El Himno Nacional: a mano (`/asado himno`) y automático a las 00:00. |
| `Miembros.lua` | Quién tiene el addon y con qué versión (Herramientas > Addon). |
| `Logros.lua` | Los logros: progreso, desbloqueo, puntos, `/asado darlogro` y registro compartido de la guild. |
| `Exportar.lua` | El archivo de rankings para la web y el archivo mensual con los ganadores. |
| `UI.lua` | Ventana principal (5 pestañas con secciones), minimapa, avisos y ruleta. |
| `Indicador.lua` | La pastillita de proximidad junto al minimapa. |
| `MapaPins.lua` | Las marcas de los compañeros en el mapa del mundo. |

Los módulos nuevos se enganchan con `NS.Handle` (mensajes), `NS.RegisterCallback` (cambios internos) y `NS.commands` (comandos).

---

## 📝 Cambios

- **0.11.1** — La Ruleta del Fernet tiene un tiempo de espera de 5 minutos por jugador (contra el spam).
- **0.11.0** — **54 logros** agrupados por categoría que **dan puntos** para el Asador del Mes y los rangos; `/asado darlogro` para que el GM y los oficiales den los logros de evento; **archivo mensual** con los ganadores de cada ranking (pestaña Rankings > Historial); `/asado exportar` genera el archivo de rankings para la web y una herramienta lo convierte en `rankings.json`.
- **0.10.0** — Sistema de **logros** (15 logros de la Legión) y ventana rediseñada: de 8 pestañas a 5 (Inicio, Rankings, Logros, Herramientas y Opciones), con secciones adentro, encabezado con logo y pestañas con los colores de la bandera. Toda la información sigue estando.
- **0.9.5** — Alertas PvP: `/asado sos` para pedir ayuda a la guild y `/asado reunion` para armar una zona de reunión en mundo abierto, con aviso, sonido y marcas en el mapa. `/asado ir` marca el lugar en tu mapa. Botones y opciones en la pestaña PvP.
- **0.9.4** — El dragón del retrato ahora viene apagado (se activa a mano). Compartir la ubicación viene activado en las instalaciones nuevas. Sonidos nuevos (variantes, comercio y el himno completo de 4 minutos), todos nivelados al mismo volumen. Aviso de bienvenida más claro sobre la ubicación.
- **0.9.3** — Himno automático todos los días a las 00:00 (hora argentina) con aviso previo y botón para detenerlo. Nueva pestaña **Addon**: quién tiene el addon y con qué versión, con susurro sugerido. Arreglo de las marcas del mapa, que caían fuera de la zona. Arreglo de la muerte doble del hunter. Variantes de sonido y sonido de comercio.
- **0.9.2** — Arreglo: la muerte de un hunter ya no cuenta doble. Variantes de sonido para muertes, wipes, bosses, loot épico y niveles. Nuevo sonido al completar un comercio.
- **0.9.1** — Arreglo importante para WoW: Forever: los nombres de jugador ahora se leen igual en todos los formatos del cliente. Se acabaron los mensajes duplicados de tu propia muerte, y los puntos de los oficiales y el himno se aceptan correctamente. Los datos guardados con nombres duplicados se unifican solos.
- **0.9.0 (beta)** — Pensada para WoW: Forever. Marcas de compañeros en el mapa del mundo, indicador de proximidad junto al minimapa, Himno Nacional (`/asado himno`, solo GM y oficiales), bandera y colores de Argentina en la interfaz, código separado en módulos.
- **0.8.0 (beta)** — Compañeros cerca: ubicación opcional entre los de la guild y aviso de cercanía. El diagnóstico muestra cómo se ven los nombres en el cliente.
- **0.7.2** — Los sonidos ya no se pisan entre sí ni se repiten sin parar; nuevo `/asado perf`; pack de sonidos aparte.
- **0.7.1** — Reinicios de contadores solo para GM y oficiales, con confirmación; limpieza automática de datos viejos.
- **0.7.0** — Sonidos de la guild, normalizados.
- **0.6.0** — Sincronización en cada pantalla de carga, historial de muertes.
- **0.5.1** — El dragón plateado se descubre solo en cualquier cliente; diagnóstico más legible.
- **0.5.0** — Pestaña PvP, dragón del retrato, avisos de muerte idénticos en pantalla y chat, links oficiales, bienvenida.
- **0.4.0** — Logo de la guild, avisos de muerte con clase, nivel y lugar.
- **0.3.0** — Pase de lista y anuncio de los ganadores del mes.
- **0.2.0** — Niveles, "Los Primeros" y compatibilidad con Retail.
- **0.1.0** — Parrilla, ruleta, puntos y sonidos.

---

*World of Warcraft y sus imágenes son propiedad de Blizzard Entertainment. Este addon no está afiliado ni respaldado por Blizzard
y no incluye arte de Blizzard: el dragón usa texturas que ya trae el juego. Hecho con cariño (y fernet) por La Legión del Asado.*
