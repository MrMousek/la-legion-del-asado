--[[
    La Legión del Asado - MapaPins.lua
    Marcas de los compañeros (que compartieron su ubicación) sobre el MAPA DEL MUNDO.
    Solo se dibujan los que están en el mismo mapa que estás mirando.

    Cada marca es un puntito del color de su clase con un aro celeste. Al pasar el mouse
    muestra el nombre y la distancia. No hace nada mientras el mapa está cerrado.
    Todo lo que toca el mapa va protegido (pcall): si algo cambia en el cliente, simplemente no se dibuja.
]]
local ADDON, NS = ...
local C = NS.C

local pins = {}
local hooked, scheduled, mapTicker = false, false, nil
local CIRCLE = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local WHITE = "Interface\\Buttons\\WHITE8X8"

local function ShowTooltip(pin)
    local al = pin.alert
    if al then   -- alerta de ayuda o reunión
        GameTooltip:SetOwner(pin, "ANCHOR_RIGHT")
        GameTooltip:AddLine(al.kind == "sos" and "|cffff4040¡Pide ayuda!|r" or "|cff74acdfZona de reunión PvP|r")
        GameTooltip:AddLine(NS.ClassColored(al.name, al.class))
        if al.msg and al.msg ~= "" then GameTooltip:AddLine('"' .. al.msg .. '"', 1, 1, 1, true) end
        local mapID, mx, my = NS.MyPosition()
        if mapID and mapID == al.mapID then
            local dist, dir = NS.DistanceAndBearing(mapID, mx, my, al.x, al.y)
            if dist then GameTooltip:AddLine(string.format("%d yd al %s", math.floor(dist + 0.5), dir), 1, 0.82, 0) end
        end
        GameTooltip:AddLine("Escribí /asado ir para marcarlo", 0.6, 0.6, 0.6)
        GameTooltip:Show()
        return
    end
    local e = pin.entry
    if not e then return end
    GameTooltip:SetOwner(pin, "ANCHOR_RIGHT")
    GameTooltip:AddLine(NS.ClassColored(pin.name, e.class))
    local mapID, mx, my = NS.MyPosition()
    if mapID and mapID == e.mapID then
        local dist, dir = NS.DistanceAndBearing(mapID, mx, my, e.x, e.y)
        if dist then
            GameTooltip:AddLine(string.format("%d yd al %s", math.floor(dist + 0.5), dir), 1, 0.82, 0)
        end
    end
    GameTooltip:AddLine("La Legión del Asado", C.CELESTE[1], C.CELESTE[2], C.CELESTE[3])
    GameTooltip:Show()
end

local function GetPin(i, canvas)
    local pin = pins[i]
    if not pin then
        pin = CreateFrame("Button", nil, canvas)
        pin:SetSize(14, 14)
        pin.ring = pin:CreateTexture(nil, "ARTWORK", nil, 1)
        pin.ring:SetAllPoints()
        pin.ring:SetTexture(WHITE)
        pin.ring:SetVertexColor(C.CELESTE[1], C.CELESTE[2], C.CELESTE[3], 1)
        pin.dot = pin:CreateTexture(nil, "ARTWORK", nil, 2)
        pin.dot:SetPoint("CENTER")
        pin.dot:SetSize(10, 10)
        pin.dot:SetTexture(WHITE)
        pcall(pin.ring.SetMask, pin.ring, CIRCLE)   -- si no hay máscara, quedan cuadraditos (se ve igual)
        pcall(pin.dot.SetMask, pin.dot, CIRCLE)
        pin:SetScript("OnEnter", ShowTooltip)
        pin:SetScript("OnLeave", function() GameTooltip:Hide() end)
        pins[i] = pin
    end
    if pin:GetParent() ~= canvas then pin:SetParent(canvas) end
    pin:SetFrameLevel(canvas:GetFrameLevel() + 60)   -- por encima del fondo del mapa
    return pin
end

local function HideAll()
    for _, pin in ipairs(pins) do pin:Hide() end
end

local function UpdatePins()
    local L = NS.db and NS.db.location
    local map = _G.WorldMapFrame
    local showMembers = L and L.map
    local showAlerts = NS.db and NS.db.pvpAlerts and NS.db.pvpAlerts.enabled
    if not (showMembers or showAlerts) or not map or not map:IsShown() then HideAll(); return end

    local ok, err = pcall(function()
        local canvas = map:GetCanvas()
        local mapID = map:GetMapID()
        if not (canvas and mapID) then HideAll(); return end
        local w, h = canvas:GetWidth(), canvas:GetHeight()
        -- Escala del lienzo del mapa (zoom). La marca se achica en la misma proporción para no agrandarse...
        local canvasScale = canvas:GetScale()
        if not canvasScale or canvasScale <= 0 then canvasScale = 1 end
        local pinScale = 1 / canvasScale

        local n, now = 0, GetTime()
        for name, e in pairs(showMembers and NS.locations or {}) do
            if e.mapID == mapID and now - e.t <= C.LOC_EXPIRE then
                n = n + 1
                local pin = GetPin(n, canvas)
                pin.name, pin.entry, pin.alert = name, e, nil
                pin:SetSize(14, 14)
                pin.dot:SetSize(10, 10)
                pin.ring:SetVertexColor(C.CELESTE[1], C.CELESTE[2], C.CELESTE[3], 1)
                local col = e.class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[e.class]
                if col then pin.dot:SetVertexColor(col.r, col.g, col.b, 1) else pin.dot:SetVertexColor(1, 1, 1, 1) end
                pin:SetScale(pinScale)
                pin:ClearAllPoints()
                -- ...y, como en WoW el desplazamiento de un elemento se multiplica por SU PROPIA escala,
                -- hay que dividirlo por pinScale (es la misma cuenta que hacen las marcas de Blizzard).
                -- Sin esta división la marca caía fuera de la zona.
                pin:SetPoint("CENTER", canvas, "TOPLEFT", e.x * w / pinScale, -e.y * h / pinScale)
                pin:Show()
            end
        end

        -- Alertas: SOS (rojo) y zonas de reunión (dorado), más grandes que las de los compañeros
        for _, a in ipairs(showAlerts and NS.ActiveAlerts() or {}) do
            if a.mapID > 0 and a.mapID == mapID then
                n = n + 1
                local pin = GetPin(n, canvas)
                pin.name, pin.entry, pin.alert = a.name, nil, a
                pin:SetSize(22, 22)
                pin.dot:SetSize(15, 15)
                if a.kind == "sos" then
                    pin.ring:SetVertexColor(1, 1, 1, 1)
                    pin.dot:SetVertexColor(0.95, 0.12, 0.10, 1)
                else
                    pin.ring:SetVertexColor(C.CELESTE[1], C.CELESTE[2], C.CELESTE[3], 1)
                    pin.dot:SetVertexColor(C.SOL[1], C.SOL[2], C.SOL[3], 1)
                end
                pin:SetScale(pinScale)
                pin:ClearAllPoints()
                pin:SetPoint("CENTER", canvas, "TOPLEFT", a.x * w / pinScale, -a.y * h / pinScale)
                pin:Show()
            end
        end
        for i = n + 1, #pins do pins[i]:Hide() end
    end)
    if not ok and NS.db.debug then NS.Print("Mapa: " .. tostring(err)) end
end

-- Agrupa pedidos de actualización (el mapa dispara muchos eventos seguidos)
local function Schedule()
    if scheduled then return end
    scheduled = true
    C_Timer.After(0.1, function()
        scheduled = false
        UpdatePins()
    end)
end

local function Hook()
    local map = _G.WorldMapFrame
    if hooked or not map then return end
    hooked = true
    pcall(function()
        map:HookScript("OnShow", function()
            Schedule()
            if not mapTicker then   -- mientras el mapa está abierto, se refresca cada 5 s (las posiciones vencen)
                mapTicker = C_Timer.NewTicker(5, function(t)
                    if map:IsShown() then UpdatePins() else t:Cancel(); mapTicker = nil end
                end)
            end
        end)
        map:HookScript("OnHide", HideAll)
        if map.OnMapChanged then hooksecurefunc(map, "OnMapChanged", Schedule) end
        if map.OnCanvasScaleChanged then hooksecurefunc(map, "OnCanvasScaleChanged", Schedule) end
    end)
end

-- /asado mapa: datos para diagnosticar las marcas
NS.commands.mapa = function()
    local map = _G.WorldMapFrame
    if not map then NS.Print("No encuentro WorldMapFrame en este cliente."); return end
    local ok, err = pcall(function()
        local canvas = map:GetCanvas()
        NS.Print(string.format("Mapa que estás mirando: %s | abierto: %s | lienzo: %.0f x %.0f | escala del lienzo: %.2f",
            tostring(map:GetMapID()), tostring(map:IsShown()), canvas:GetWidth(), canvas:GetHeight(), canvas:GetScale()))
        local shown, total = 0, 0
        for _, p in ipairs(pins) do if p:IsShown() then shown = shown + 1 end end
        for _ in pairs(NS.locations) do total = total + 1 end
        NS.Print(string.format("Marcas dibujadas: %d | compañeros que compartieron su ubicación: %d", shown, total))
        NS.Print("Tu mapa según el juego (GetBestMapForUnit): " .. tostring((NS.MyPosition())))
    end)
    if not ok then NS.Print("Error al leer el mapa: " .. tostring(err)) end
end

NS.RegisterCallback("ALERTS_UPDATED", function()
    Hook()
    if _G.WorldMapFrame and _G.WorldMapFrame:IsShown() then Schedule() end
end)

NS.RegisterCallback("LOCATIONS_UPDATED", function()
    Hook()
    if _G.WorldMapFrame and _G.WorldMapFrame:IsShown() then Schedule() end
end)

NS.RegisterCallback("READY", Hook)
NS:On("ADDON_LOADED", function(name)
    if name == "Blizzard_WorldMap" then Hook() end
end)
