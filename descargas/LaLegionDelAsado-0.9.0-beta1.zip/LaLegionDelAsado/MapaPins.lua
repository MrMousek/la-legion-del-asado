--[[
    La Legión del Asado - MapaPins.lua
    Marcas de los compañeros (que compartieron su ubicación) sobre el MAPA DEL MUNDO.
    Solo se dibujan los que están en el mismo mapa que estás mirando.

    Cada marca es un puntito del color de su clase con un aro celeste. Al pasar el mouse
    muestra el nombre y la distancia. No hace nada mientras el mapa está cerrado.
    Todo lo que toca el mapa va protegido (pcall): si algo cambia en el cliente, simplemente no se dibuja.
]]
local ADDON, NS = ...
local C = NS.C

local pins = {}
local hooked, scheduled, mapTicker = false, false, nil
local CIRCLE = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local WHITE = "Interface\\Buttons\\WHITE8X8"

local function ShowTooltip(pin)
    local e = pin.entry
    if not e then return end
    GameTooltip:SetOwner(pin, "ANCHOR_RIGHT")
    GameTooltip:AddLine(NS.ClassColored(pin.name, e.class))
    local mapID, mx, my = NS.MyPosition()
    if mapID and mapID == e.mapID then
        local dist, dir = NS.DistanceAndBearing(mapID, mx, my, e.x, e.y)
        if dist then
            GameTooltip:AddLine(string.format("%d yd al %s", math.floor(dist + 0.5), dir), 1, 0.82, 0)
        end
    end
    GameTooltip:AddLine("La Legión del Asado", C.CELESTE[1], C.CELESTE[2], C.CELESTE[3])
    GameTooltip:Show()
end

local function GetPin(i, canvas)
    local pin = pins[i]
    if not pin then
        pin = CreateFrame("Button", nil, canvas)
        pin:SetSize(14, 14)
        pin.ring = pin:CreateTexture(nil, "ARTWORK", nil, 1)
        pin.ring:SetAllPoints()
        pin.ring:SetTexture(WHITE)
        pin.ring:SetVertexColor(C.CELESTE[1], C.CELESTE[2], C.CELESTE[3], 1)
        pin.dot = pin:CreateTexture(nil, "ARTWORK", nil, 2)
        pin.dot:SetPoint("CENTER")
        pin.dot:SetSize(10, 10)
        pin.dot:SetTexture(WHITE)
        pcall(pin.ring.SetMask, pin.ring, CIRCLE)   -- si no hay máscara, quedan cuadraditos (se ve igual)
        pcall(pin.dot.SetMask, pin.dot, CIRCLE)
        pin:SetScript("OnEnter", ShowTooltip)
        pin:SetScript("OnLeave", function() GameTooltip:Hide() end)
        pins[i] = pin
    end
    if pin:GetParent() ~= canvas then pin:SetParent(canvas) end
    pin:SetFrameLevel(canvas:GetFrameLevel() + 60)   -- por encima del fondo del mapa
    return pin
end

local function HideAll()
    for _, pin in ipairs(pins) do pin:Hide() end
end

local function UpdatePins()
    local L = NS.db and NS.db.location
    local map = _G.WorldMapFrame
    if not (L and L.map) or not map or not map:IsShown() then HideAll(); return end

    local ok, err = pcall(function()
        local canvas = map:GetCanvas()
        local mapID = map:GetMapID()
        if not (canvas and mapID) then HideAll(); return end
        local w, h = canvas:GetWidth(), canvas:GetHeight()
        local scale = (map.GetCanvasScale and map:GetCanvasScale()) or 1
        if scale <= 0 then scale = 1 end

        local n, now = 0, GetTime()
        for name, e in pairs(NS.locations) do
            if e.mapID == mapID and now - e.t <= C.LOC_EXPIRE then
                n = n + 1
                local pin = GetPin(n, canvas)
                pin.name, pin.entry = name, e
                local col = e.class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[e.class]
                if col then pin.dot:SetVertexColor(col.r, col.g, col.b, 1) else pin.dot:SetVertexColor(1, 1, 1, 1) end
                pin:SetScale(1 / scale)   -- que no se agranden con el zoom del mapa
                pin:ClearAllPoints()
                pin:SetPoint("CENTER", canvas, "TOPLEFT", e.x * w, -e.y * h)
                pin:Show()
            end
        end
        for i = n + 1, #pins do pins[i]:Hide() end
    end)
    if not ok and NS.db.debug then NS.Print("Mapa: " .. tostring(err)) end
end

-- Agrupa pedidos de actualización (el mapa dispara muchos eventos seguidos)
local function Schedule()
    if scheduled then return end
    scheduled = true
    C_Timer.After(0.1, function()
        scheduled = false
        UpdatePins()
    end)
end

local function Hook()
    local map = _G.WorldMapFrame
    if hooked or not map then return end
    hooked = true
    pcall(function()
        map:HookScript("OnShow", function()
            Schedule()
            if not mapTicker then   -- mientras el mapa está abierto, se refresca cada 5 s (las posiciones vencen)
                mapTicker = C_Timer.NewTicker(5, function(t)
                    if map:IsShown() then UpdatePins() else t:Cancel(); mapTicker = nil end
                end)
            end
        end)
        map:HookScript("OnHide", HideAll)
        if map.OnMapChanged then hooksecurefunc(map, "OnMapChanged", Schedule) end
        if map.OnCanvasScaleChanged then hooksecurefunc(map, "OnCanvasScaleChanged", Schedule) end
    end)
end

NS.RegisterCallback("LOCATIONS_UPDATED", function()
    Hook()
    if _G.WorldMapFrame and _G.WorldMapFrame:IsShown() then Schedule() end
end)

NS.RegisterCallback("READY", Hook)
NS:On("ADDON_LOADED", function(name)
    if name == "Blizzard_WorldMap" then Hook() end
end)
