--[[
    La Legión del Asado - Himno.lua
    /asado himno: el GM o un oficial reproduce el Himno Nacional Argentino
    y lo escuchan todos los que tengan el addon (y no lo hayan apagado).

    El audio NO viene incluido: copiá tu archivo como Sounds\himno.ogg
    (versión abreviada, ~1 a 2 minutos) y ajustá HIMNO_SECONDS en Config.lua.
]]
local ADDON, NS = ...
local C = NS.C
local Print = NS.Print

-- Prioridad 4: más importante que cualquier otro sonido (corta a los demás y no lo pisan)
NS.Sounds.himno = {
    file = "Interface\\AddOns\\" .. ADDON .. "\\Sounds\\himno.ogg",
    len = C.HIMNO_SECONDS, prio = 4,
}

local lastRun = -1000   -- cuándo empezó el último himno (para el enfriamiento)
local pending           -- id del himno en cuenta regresiva (para poder cortarlo antes de que arranque)

local function Begin(id)
    if pending ~= id then return end                       -- se cortó durante la cuenta regresiva
    pending = nil
    if NS.inEncounter and NS.db.sounds.muteInEncounter then return end
    if not NS.PlaySound("himno") then
        Print("No encuentro el audio del himno (tiene que estar en Sounds\\himno.ogg).")
    end
end

-- Cuenta regresiva + sonido. Se llama en todos los clientes, incluido el del que lo pone.
function NS.RunHimno(id)
    local H = NS.db.himno
    if not H.enabled or not NS.db.sounds.enabled then return end
    pending = id
    lastRun = GetTime()
    NS.Toast("¡De pie, Legión!\nHimno Nacional Argentino", C.HIMNO_COUNTDOWN + 3, "himno")
    Print("Himno Nacional Argentino. Con |cffffd100/asado himno stop|r lo cortás (solo para vos).")
    C_Timer.After(C.HIMNO_COUNTDOWN, function() Begin(id) end)
end

-- Lo ejecuta el GM u oficial: avisa a la guild y arranca el suyo
function NS.StartHimno()
    if not NS.RequireOfficer("poner el himno") then return end
    if not IsInGuild() then Print("Necesitás estar en una guild."); return end
    if GetTime() - lastRun < C.HIMNO_COOLDOWN then
        Print("El himno ya sonó hace poco. Esperá unos minutos.")
        return
    end
    local ts = GetServerTime()
    local id = NS.me .. ":" .. ts
    local msg = table.concat({ "HIMNO", id, ts, NS.me }, "^")
    if not NS.Send("GUILD", msg, nil, true) then
        Print("No se pudo avisar a la guild ahora (¿pelea de jefe?). Probá de nuevo en unos segundos.")
        return
    end
    NS.RunHimno(id)
end

-- Llega el aviso de un compañero: solo se acepta si lo mandó, en vivo, el GM o un oficial
NS.Handle("HIMNO", function(sender, channel, id, ts, by)
    if channel ~= "GUILD" or not id or not by then return end
    by = NS.Short(by)
    if sender ~= by or not NS.IsOfficer(by) then return end
    ts = tonumber(ts)
    if not ts or math.abs(GetServerTime() - ts) > 20 then return end   -- nunca reproducir un aviso viejo
    if GetTime() - lastRun < C.HIMNO_COOLDOWN then return end
    if NS.inEncounter and NS.db.sounds.muteInEncounter then return end
    NS.RunHimno(id)
end)

-- /asado himno         -> (GM / oficiales) lo pone para toda la guild
-- /asado himno stop    -> (cualquiera) lo corta solo para uno mismo
NS.commands.himno = function(rest)
    rest = (rest or ""):lower()
    if rest == "stop" or rest == "parar" then
        pending = nil
        NS.StopSound("himno")
        Print("Himno detenido (solo para vos).")
    else
        NS.StartHimno()
    end
end
